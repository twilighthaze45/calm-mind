import test from 'node:test';
import assert from 'node:assert/strict';
import {
  computeUrgency,
  formatDeadline,
  isOverdue,
  directionLabel,
  sourceIcon,
  urgencyOrder,
  createSeedData,
  snoozeCommitment,
  unsnoozeCommitment,
  toggleCommitmentComplete,
  computeSidebarStats,
} from './logic';

test('isOverdue correctly detects past deadlines', () => {
  const now = new Date('2026-10-21T12:00:00Z');
  const past = new Date('2026-10-20T12:00:00Z').toISOString();
  const future = new Date('2026-10-22T12:00:00Z').toISOString();

  assert.equal(isOverdue(past, now), true);
  assert.equal(isOverdue(future, now), false);
});

test('computeUrgency derives correct urgency levels', () => {
  const now = new Date('2026-10-21T12:00:00Z');
  const past = new Date('2026-10-20T12:00:00Z').toISOString();
  const inHalfDay = new Date('2026-10-21T20:00:00Z').toISOString();
  const in2Days = new Date('2026-10-23T12:00:00Z').toISOString();
  const in5Days = new Date('2026-10-26T12:00:00Z').toISOString();
  const in10Days = new Date('2026-10-31T12:00:00Z').toISOString();

  assert.equal(computeUrgency(past, now), 'critical');
  assert.equal(computeUrgency(inHalfDay, now), 'critical');
  assert.equal(computeUrgency(in2Days, now), 'high');
  assert.equal(computeUrgency(in5Days, now), 'medium');
  assert.equal(computeUrgency(in10Days, now), 'low');
});

test('formatDeadline returns proper human-readable strings', () => {
  const now = new Date('2026-10-21T12:00:00Z');
  const overdue3d = new Date('2026-10-18T12:00:00Z').toISOString();
  const today = new Date('2026-10-21T18:00:00Z').toISOString();
  const tomorrow = new Date('2026-10-22T12:00:00Z').toISOString();
  const in4d = new Date('2026-10-25T12:00:00Z').toISOString();

  assert.equal(formatDeadline(overdue3d, now), '3d overdue');
  assert.equal(formatDeadline(today, now), 'Due today');
  assert.equal(formatDeadline(tomorrow, now), 'Due tomorrow');
  assert.equal(formatDeadline(in4d, now), '4d left');
});

test('directionLabel maps internal direction values to display copy', () => {
  assert.equal(directionLabel('i_promised'), 'You owe');
  assert.equal(directionLabel('they_promised'), 'Owed to you');
  assert.equal(directionLabel('mutual'), 'Mutual');
});

test('sourceIcon returns required symbols', () => {
  assert.equal(sourceIcon('email'), '✉');
  assert.equal(sourceIcon('document'), '◻');
  assert.equal(sourceIcon('meeting'), '◷');
  assert.equal(sourceIcon('slack'), '#');
  assert.equal(sourceIcon('manual'), '✎');
});

test('urgencyOrder returns sort numbers 0 (critical) through 3 (low)', () => {
  assert.equal(urgencyOrder('critical'), 0);
  assert.equal(urgencyOrder('high'), 1);
  assert.equal(urgencyOrder('medium'), 2);
  assert.equal(urgencyOrder('low'), 3);
});

test('createSeedData returns exactly 9 valid commitment objects', () => {
  const seed = createSeedData();
  assert.equal(seed.length, 9);
  assert.equal(seed[0].person, 'Priya Mehta');
});

test('snoozeCommitment extends deadline by 3 days and sets status to snoozed', () => {
  const now = new Date('2026-10-21T12:00:00Z');
  const cmt = createSeedData(now)[0];
  const snoozed = snoozeCommitment(cmt, now, 3);

  assert.equal(snoozed.status, 'snoozed');
  const deadlineDiff = new Date(snoozed.deadline).getTime() - now.getTime();
  assert.ok(deadlineDiff >= 3 * 24 * 60 * 60 * 1000);
});

test('toggleCommitmentComplete switches status cleanly', () => {
  const now = new Date('2026-10-21T12:00:00Z');
  const cmt = createSeedData(now)[0];
  const done = toggleCommitmentComplete(cmt, now);
  assert.equal(done.status, 'completed');

  const reopened = toggleCommitmentComplete(done, now);
  assert.equal(reopened.status, 'pending');
});

test('computeSidebarStats calculates open counts and direction percentages', () => {
  const now = new Date('2026-10-21T12:00:00Z');
  const seed = createSeedData(now);
  const stats = computeSidebarStats(seed);

  assert.equal(stats.totalOpen, 9);
  assert.ok(stats.directionPercentages.i_promised > 0);
  assert.ok(stats.topDomains.length <= 5);
});
