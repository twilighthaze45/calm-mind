export interface Commitment {
  id: string;
  text: string;
  person: string;
  direction: 'i_promised' | 'they_promised' | 'mutual';
  source: 'email' | 'document' | 'meeting' | 'manual' | 'slack';
  deadline: string; // ISO date string
  status: 'pending' | 'completed' | 'overdue' | 'snoozed';
  urgency: 'low' | 'medium' | 'high' | 'critical';
  domain: string;
  contextSnippet: string;
  createdAt: string; // ISO date string
}

export function isOverdue(isoDate: string, now: Date = new Date()): boolean {
  return new Date(isoDate).getTime() < now.getTime();
}

export function computeUrgency(
  deadlineISO: string,
  now: Date = new Date()
): 'critical' | 'high' | 'medium' | 'low' {
  const deadlineTime = new Date(deadlineISO).getTime();
  const nowTime = now.getTime();
  const diffDays = (deadlineTime - nowTime) / (1000 * 60 * 60 * 24);

  if (diffDays <= 1) {
    return 'critical';
  }
  if (diffDays <= 3) {
    return 'high';
  }
  if (diffDays <= 7) {
    return 'medium';
  }
  return 'low';
}

export function formatDeadline(isoDate: string, now: Date = new Date()): string {
  const deadline = new Date(isoDate);
  const nowMidnight = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const deadlineMidnight = new Date(deadline.getFullYear(), deadline.getMonth(), deadline.getDate());
  const diffDays = Math.round((deadlineMidnight.getTime() - nowMidnight.getTime()) / (1000 * 60 * 60 * 24));

  if (deadline.getTime() < now.getTime() && diffDays < 0) {
    const overdueDays = Math.abs(diffDays);
    return overdueDays === 0 ? 'Due today' : `${overdueDays}d overdue`;
  }

  if (diffDays === 0) return 'Due today';
  if (diffDays === 1) return 'Due tomorrow';
  if (diffDays > 1) return `${diffDays}d left`;
  return 'Due today';
}

export function directionLabel(direction: string): string {
  if (direction === 'i_promised') return 'You owe';
  if (direction === 'they_promised') return 'Owed to you';
  if (direction === 'mutual') return 'Mutual';
  return direction;
}

export function sourceIcon(source: string): string {
  switch (source) {
    case 'email':
      return '✉';
    case 'document':
      return '◻';
    case 'meeting':
      return '◷';
    case 'slack':
      return '#';
    case 'manual':
      return '✎';
    default:
      return '•';
  }
}

export function urgencyOrder(urgency: string): number {
  switch (urgency) {
    case 'critical':
      return 0;
    case 'high':
      return 1;
    case 'medium':
      return 2;
    case 'low':
      return 3;
    default:
      return 4;
  }
}

export function snoozeCommitment(
  commitment: Commitment,
  now: Date = new Date(),
  snoozeDays: number = 3
): Commitment {
  const currentDeadline = new Date(commitment.deadline).getTime();
  const baseTime = Math.max(now.getTime(), currentDeadline);
  const newDeadline = new Date(baseTime + snoozeDays * 24 * 60 * 60 * 1000).toISOString();

  return {
    ...commitment,
    deadline: newDeadline,
    status: 'snoozed',
    urgency: computeUrgency(newDeadline, now),
  };
}

export function unsnoozeCommitment(
  commitment: Commitment,
  now: Date = new Date()
): Commitment {
  const overdue = isOverdue(commitment.deadline, now);
  const status = overdue ? 'overdue' : 'pending';
  const urgency = overdue ? 'critical' : computeUrgency(commitment.deadline, now);

  return {
    ...commitment,
    status,
    urgency,
  };
}

export function toggleCommitmentComplete(
  commitment: Commitment,
  now: Date = new Date()
): Commitment {
  if (commitment.status === 'completed') {
    const overdue = isOverdue(commitment.deadline, now);
    return {
      ...commitment,
      status: overdue ? 'overdue' : 'pending',
      urgency: overdue ? 'critical' : computeUrgency(commitment.deadline, now),
    };
  }

  return {
    ...commitment,
    status: 'completed',
  };
}

export function computeSidebarStats(commitments: Commitment[]) {
  const openCommitments = commitments.filter((c) => c.status !== 'completed');
  const totalOpen = openCommitments.length;

  const urgencyCounts = { critical: 0, high: 0, medium: 0, low: 0 };
  openCommitments.forEach((c) => {
    urgencyCounts[c.urgency] = (urgencyCounts[c.urgency] || 0) + 1;
  });

  const directionCounts = { i_promised: 0, they_promised: 0, mutual: 0 };
  openCommitments.forEach((c) => {
    directionCounts[c.direction] = (directionCounts[c.direction] || 0) + 1;
  });

  const directionPercentages = {
    i_promised: totalOpen > 0 ? Math.round((directionCounts.i_promised / totalOpen) * 100) : 0,
    they_promised: totalOpen > 0 ? Math.round((directionCounts.they_promised / totalOpen) * 100) : 0,
    mutual: totalOpen > 0 ? Math.round((directionCounts.mutual / totalOpen) * 100) : 0,
  };

  const domainMap: Record<string, number> = {};
  openCommitments.forEach((c) => {
    if (c.domain) {
      domainMap[c.domain] = (domainMap[c.domain] || 0) + 1;
    }
  });

  const topDomains = Object.entries(domainMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([domain, count]) => ({ domain, count }));

  return {
    totalOpen,
    urgencyCounts,
    directionCounts,
    directionPercentages,
    topDomains,
  };
}

export function createSeedData(refDate: Date = new Date()): Commitment[] {
  const day = 24 * 60 * 60 * 1000;
  const t = refDate.getTime();

  return [
    {
      id: 'cmt-1',
      text: 'Send revised enterprise Q4 proposal and SLA addendum',
      person: 'Priya Mehta',
      direction: 'i_promised',
      source: 'email',
      deadline: new Date(t + 1 * day).toISOString(),
      status: 'pending',
      urgency: 'critical',
      domain: 'Sales',
      contextSnippet: "Priya: 'Could you share the finalized pricing tables and revised SLA before our client sync?'",
      createdAt: new Date(t - 2 * day).toISOString(),
    },
    {
      id: 'cmt-2',
      text: 'Sign off on mobile app v2.4 engineering spec document',
      person: 'Arjun Singh',
      direction: 'they_promised',
      source: 'document',
      deadline: new Date(t + 2 * day).toISOString(),
      status: 'pending',
      urgency: 'high',
      domain: 'Product',
      contextSnippet: "Arjun left a note in Notion: 'Reviewing API contracts; will complete sign-off by Thursday.'",
      createdAt: new Date(t - 1 * day).toISOString(),
    },
    {
      id: 'cmt-3',
      text: 'Schedule executive onboarding kickoff call for client account',
      person: 'Neha Kapoor',
      direction: 'i_promised',
      source: 'meeting',
      deadline: new Date(t + 4 * day).toISOString(),
      status: 'pending',
      urgency: 'medium',
      domain: 'Client Success',
      contextSnippet: "Action item from retro: 'I will coordinate calendar invites with their VP of Technology.'",
      createdAt: new Date(t - 3 * day).toISOString(),
    },
    {
      id: 'cmt-4',
      text: 'Send executed partnership agreement draft and indemnity terms',
      person: 'Aditya Kumar',
      direction: 'i_promised',
      source: 'email',
      deadline: new Date(t - 3 * day).toISOString(),
      status: 'overdue',
      urgency: 'critical',
      domain: 'Legal',
      contextSnippet: "Aditya: 'Awaiting the amended clause 9.2 draft from your side to present to board.'",
      createdAt: new Date(t - 6 * day).toISOString(),
    },
    {
      id: 'cmt-5',
      text: 'Release wire transfer payment on vendor invoice #2847',
      person: 'Finance Dept',
      direction: 'they_promised',
      source: 'email',
      deadline: new Date(t - 1 * day).toISOString(),
      status: 'overdue',
      urgency: 'critical',
      domain: 'Finance',
      contextSnippet: "'Invoice 2847 approved in SAP portal. Accounts payable batch set to process today.'",
      createdAt: new Date(t - 4 * day).toISOString(),
    },
    {
      id: 'cmt-6',
      text: 'Deploy hotfix for distributed caching latency spike in cluster',
      person: 'Vikram Malhotra',
      direction: 'mutual',
      source: 'slack',
      deadline: new Date(t + 0.8 * day).toISOString(),
      status: 'pending',
      urgency: 'critical',
      domain: 'Engineering',
      contextSnippet: "Vikram on #infra-war-room: 'Let us pair-debug the Redis eviction buffer together this evening.'",
      createdAt: new Date(t - 0.5 * day).toISOString(),
    },
    {
      id: 'cmt-7',
      text: 'Deliver competitor benchmark analysis on generative workflow tools',
      person: 'Ananya Sharma',
      direction: 'they_promised',
      source: 'document',
      deadline: new Date(t + 6 * day).toISOString(),
      status: 'pending',
      urgency: 'medium',
      domain: 'Strategy',
      contextSnippet: "'Ananya to aggregate feature matrices across the top 5 APAC competitors.'",
      createdAt: new Date(t - 2 * day).toISOString(),
    },
    {
      id: 'cmt-8',
      text: 'Finalize data center lease renewal terms with Bengaluru facility',
      person: 'Rajesh Varma',
      direction: 'mutual',
      source: 'meeting',
      deadline: new Date(t + 12 * day).toISOString(),
      status: 'pending',
      urgency: 'low',
      domain: 'Operations',
      contextSnippet: "Minutes: 'Rajesh & team to conduct site survey and renegotiate power unit rates.'",
      createdAt: new Date(t - 5 * day).toISOString(),
    },
    {
      id: 'cmt-9',
      text: 'Conduct code audit and security vulnerability scan on payment service',
      person: 'Divya Nair',
      direction: 'i_promised',
      source: 'manual',
      deadline: new Date(t + 16 * day).toISOString(),
      status: 'pending',
      urgency: 'low',
      domain: 'Engineering',
      contextSnippet: "Personal task: 'Need to run Snyk scan and verify PCI-DSS tokenization compliance.'",
      createdAt: new Date(t - 1 * day).toISOString(),
    },
  ];
}

