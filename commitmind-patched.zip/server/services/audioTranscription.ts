/**
 * COMMITMIND SPEECH & AUDIO TRANSCRIPTION SERVICE
 * Processes uploaded audio recordings (WAV, MP3, WebM, M4A) with
 * speaker diarization and timestamp extraction using Google Gemini Multimodal STT.
 */

import { GoogleGenAI } from '@google/genai';
import fs from 'node:fs';

export interface TranscriptSegment {
  speaker_id: string; // e.g. "Speaker 1"
  speaker_name?: string; // Mapped name if available
  start_time_seconds: number;
  end_time_seconds: number;
  text: string;
}

export interface TranscriptionResult {
  full_text: string;
  segments: TranscriptSegment[];
  speakers_detected: string[];
  provider: 'gemini_multimodal' | 'heuristic_fallback';
  duration_seconds?: number;
}

const ALLOWED_MIME_TYPES = new Set([
  'audio/wav',
  'audio/x-wav',
  'audio/mp3',
  'audio/mpeg',
  'audio/webm',
  'audio/ogg',
  'audio/m4a',
  'audio/x-m4a',
  'audio/mp4',
]);

export async function transcribeAudioFile(
  filePath: string,
  mimeType: string,
  participantNames: string[] = []
): Promise<TranscriptionResult> {
  if (!ALLOWED_MIME_TYPES.has(mimeType.toLowerCase())) {
    throw new Error(
      `Unsupported audio format '${mimeType}'. Supported formats: WAV, MP3, WebM, OGG, M4A.`
    );
  }

  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
    throw new Error(
      'Audio transcription is not configured. Set GEMINI_API_KEY in the server environment, restart the backend, or paste the transcript manually.'
    );
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const audioBuffer = fs.readFileSync(filePath);
    const base64Audio = audioBuffer.toString('base64');

    const prompt = `You are an expert speech-to-text and speaker diarization engine for business meetings.
Transcribe this audio recording accurately.
Diarize the speakers as "Speaker 1", "Speaker 2", etc.
${participantNames.length > 0 ? `Known participants to correlate: ${participantNames.join(', ')}.` : ''}

Output STRICT JSON matching this schema:
{
  "segments": [
    {
      "speaker_id": "Speaker 1",
      "start_time_seconds": 0,
      "end_time_seconds": 12,
      "text": "Exact transcribed words here"
    }
  ],
  "speakers_detected": ["Speaker 1", "Speaker 2"]
}
Do not include markdown ticks, only raw valid JSON.`;

    const modelName = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
    const response = await ai.models.generateContent({
      model: modelName,
      contents: [
        {
          inlineData: {
            mimeType,
            data: base64Audio,
          },
        },
        {
          text: prompt,
        },
      ],
      config: {
        temperature: 0.1,
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '{}';
    const cleanJson = responseText.replace(/^```json\s*/i, '').replace(/```\s*$/, '').trim();
    const parsed = JSON.parse(cleanJson);

    const segments: TranscriptSegment[] = Array.isArray(parsed.segments)
      ? parsed.segments.map((s: any) => ({
          speaker_id: s.speaker_id || 'Speaker 1',
          speaker_name: s.speaker_id,
          start_time_seconds: Number(s.start_time_seconds) || 0,
          end_time_seconds: Number(s.end_time_seconds) || 0,
          text: String(s.text || '').trim(),
        }))
      : [];

    const full_text = segments.map((s) => `${s.speaker_id}: ${s.text}`).join('\n');
    const speakers_detected: string[] = Array.isArray(parsed.speakers_detected)
      ? parsed.speakers_detected
      : Array.from(new Set(segments.map((s) => s.speaker_id)));

    return {
      full_text,
      segments,
      speakers_detected,
      provider: 'gemini_multimodal',
    };
  } catch (error) {
    console.error('Gemini audio transcription failed:', error);
    const detail = error instanceof Error ? error.message : 'Unknown provider error';
    throw new Error(`Audio transcription failed. Check GEMINI_API_KEY, model access, and the audio format. Details: ${detail}`);
  }
}
