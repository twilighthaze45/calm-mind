/**
 * COMMITMIND AUDIT LOGGER
 * Implements an immutable audit trail for commitment lifecycle events:
 * creation, confirmation, edits, rescheduling, rejection, completion,
 * deletion, and reminder dispatches.
 */

export interface AuditEvent {
  id: string;
  commitment_id?: string | null;
  meeting_id?: string | null;
  user_id?: string;
  actor: string;
  action_type: 
    | 'commitment_extracted'
    | 'commitment_confirmed'
    | 'commitment_rejected'
    | 'commitment_edited'
    | 'commitment_rescheduled'
    | 'commitment_completed'
    | 'speaker_attribution_corrected'
    | 'reminder_scheduled'
    | 'reminder_sent'
    | 'reminder_failed'
    | 'reminder_cancelled'
    | 'calendar_event_created'
    | 'calendar_event_updated'
    | 'stop_and_delete_executed';
  previous_state?: Record<string, unknown> | null;
  new_state?: Record<string, unknown> | null;
  timestamp: string; // ISO 8601
  metadata?: Record<string, unknown>;
}

class AuditLogger {
  private inMemoryEvents: AuditEvent[] = [];

  /**
   * Log an audit event
   */
  public log(event: Omit<AuditEvent, 'id' | 'timestamp'>): AuditEvent {
    const fullEvent: AuditEvent = {
      id: `audit_${Date.now()}_${Math.random().toString(36).substring(2, 9)}`,
      timestamp: new Date().toISOString(),
      ...event,
    };

    this.inMemoryEvents.push(fullEvent);

    // Keep memory bounded to last 2000 events in active buffer
    if (this.inMemoryEvents.length > 2000) {
      this.inMemoryEvents.shift();
    }

    return fullEvent;
  }

  /**
   * Get events for a specific commitment
   */
  public getEventsForCommitment(commitmentId: string): AuditEvent[] {
    return this.inMemoryEvents.filter((e) => e.commitment_id === commitmentId);
  }

  /**
   * Get all events
   */
  public getAllEvents(limit = 100): AuditEvent[] {
    return [...this.inMemoryEvents].slice(-limit).reverse();
  }

  /**
   * Clear events matching meeting or commitment (e.g. for Stop & Delete)
   */
  public purgeEvents(query: { meeting_id?: string; commitment_id?: string }): number {
    const initialCount = this.inMemoryEvents.length;
    this.inMemoryEvents = this.inMemoryEvents.filter((e) => {
      if (query.meeting_id && e.meeting_id === query.meeting_id) return false;
      if (query.commitment_id && e.commitment_id === query.commitment_id) return false;
      return true;
    });
    return initialCount - this.inMemoryEvents.length;
  }
}

export const auditLogger = new AuditLogger();
