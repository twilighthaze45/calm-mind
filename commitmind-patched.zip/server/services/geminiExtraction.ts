/**
 * COMMITMIND SERVER-SIDE GEMINI & HEURISTIC COMMITMENT EXTRACTION SERVICE
 * Uses @google/genai SDK with strict structured JSON schema validation.
 * Extracts commitments, resolves historical deadlines, identifies speaker attributions,
 * and handles conversational retractions.
 */

import { GoogleGenAI, Type } from '@google/genai';
import { z } from 'zod';
import { resolveDeadline, DeadlineResolutionResult } from './deadlineResolver';

export interface ExtractedCommitmentItem {
  id: string;
  meeting_id: string;
  speaker_id: string;
  responsible_person: string;
  action: string;
  commitment_type: 'promise' | 'request' | 'milestone_dependency' | 'clarification_needed';
  deadline_phrase: string;
  deadline_timestamp: string | null;
  deadline_type: 'datetime' | 'date_only' | 'undated';
  timezone: string;
  source_evidence: string;
  confidence: number;
  is_flagged_uncertain: boolean;
  ambiguity_reason?: string;
  deduplication_hash: string;
  // Aliases for compatibility
  title?: string;
  action_description?: string;
  owner_name?: string;
  owner_speaker_label?: string;
  transcript_excerpt?: string;
  deadline_at?: string | null;
  confidence_score?: number;
}

export interface GeminiExtractionResult {
  commitments: ExtractedCommitmentItem[];
  retractions_detected: string[];
  provider: 'gemini_llm' | 'heuristic_engine';
}

// Schema for raw LLM extraction
export const CommitmentExtractionSchema = z.object({
  title: z.string().min(1),
  action_description: z.string().min(1),
  speaker_label: z.string().default('Speaker 1'),
  speaker_name: z.string().default('Self'),
  transcript_excerpt: z.string().min(1),
  deadline_phrase: z.string().optional().nullable(),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).default('medium'),
  confidence_score: z.number().min(0).max(1).default(0.85),
  is_commitment: z.boolean(),
  is_flagged_uncertain: z.boolean().default(false),
  ambiguity_reason: z.string().optional().nullable(),
});

/**
 * Computes deterministic FNV-1a 32-bit hash
 */
export function computeHash(str: string): string {
  let hash = 2166136261;
  for (let i = 0; i < str.length; i++) {
    hash ^= str.charCodeAt(i);
    hash += (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
  }
  return (hash >>> 0).toString(16).padStart(8, '0');
}

/**
 * Sanitizes transcript input against prompt injection attempts.
 */
function sanitizeTranscript(input: string): string {
  return input
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, '')
    .replace(/ignore\s+(all\s+)?previous\s+instructions/gi, '[filtered command]')
    .replace(/reveal\s+(system\s+)?prompt/gi, '[filtered command]')
    .replace(/you\s+are\s+now\s+in\s+developer\s+mode/gi, '[filtered command]');
}

/**
 * Normalizes participant argument into standard { label, name } pairs
 */
function normalizeParticipants(
  rawList: (string | { label?: string; name?: string })[]
): { label: string; name: string }[] {
  if (!Array.isArray(rawList)) return [];
  return rawList.map((item, idx) => {
    if (typeof item === 'string') {
      return { label: `Speaker ${idx + 1}`, name: item.trim() };
    }
    const label = item.label || `Speaker ${idx + 1}`;
    const name = item.name || label;
    return { label, name };
  });
}

/**
 * Deterministic linguistic commitment extractor
 */
export function extractCommitmentsHeuristic(
  transcript: string,
  meetingAnchor: string | Date = new Date(),
  timezone = 'UTC',
  rawParticipants: (string | { label?: string; name?: string })[] = [],
  meetingId = 'mtg_heuristic'
): GeminiExtractionResult {
  const sanitized = sanitizeTranscript(transcript);
  const lines = sanitized.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const participants = normalizeParticipants(rawParticipants);
  const commitments: ExtractedCommitmentItem[] = [];
  const retractions_detected: string[] = [];

  // Patterns indicating non-binding / suggestions / hypotheticals
  const nonCommitmentPatterns = [
    /\bmaybe\s+(?:I|we)\s+can\b/i,
    /\bmaybe\s+we\s+could\b/i,
    /\bwe\s+should\s+consider\b/i,
    /\bwhat\s+if\s+we\b/i,
    /\bwe\s+might\s+want\b/i,
    /\bit\s+would\s+be\s+nice\s+if\b/i,
    /\bI\s+won't\s+be\s+able\s+to\b/i,
    /\bif\s+we\s+have\s+time\b/i,
  ];

  // Pattern library
  const patterns = [
    // Direct personal commitment: "I'll update the design tomorrow"
    {
      regex: /\b(?:I\s+will|I'll|I\s+promise\s+to|I\s+commit\s+to)\s+([^\.]+?)(?:\s+(?:by|before|until|at|tomorrow|next\s+\w+|in\s+\d+\s+\w+)\s+([^\.]+))?(?:\.|$)/i,
      isRequest: false,
    },
    // General promise pattern: "I'll change the design tomorrow"
    {
      regex: /\b(?:I'll|I\s+will)\s+([\w\s]+?)\s+(tomorrow|next\s+\w+|by\s+\w+|before\s+[^\.]+)(?:\.|$)/i,
      isRequest: false,
    },
    // Team commitment
    {
      regex: /\b(?:We\s+will|We'll|We\s+promise\s+to)\s+([^\.]+?)(?:\s+(?:by|before|until|at)\s+([^\.]+))?(?:\.|$)/i,
      isRequest: false,
    },
    // Request to someone else: "Can you send the design by Thursday?"
    {
      regex: /\b(?:Can\s+you|Could\s+you|Would\s+you)\s+([^\.]+?)(?:\s+(?:by|before|until|at)\s+([^\.\?]+))?(?:\?|$)/i,
      isRequest: true,
    },
    // Task delegation: "Please complete the review by Friday"
    {
      regex: /\b(?:Please\s+complete|Please\s+send|Please\s+review|Please\s+finish)\s+([^\.]+?)(?:\s+(?:by|before|until|at)\s+([^\.]+))?(?:\.|$)/i,
      isRequest: true,
    },
  ];

  let lastCommitmentIndex = -1;

  for (let idx = 0; idx < lines.length; idx++) {
    const line = lines[idx];

    // Check for conversational correction on previous promise: "Actually, make that Monday instead of Friday"
    const correctionMatch = line.match(
      /\b(?:actually|instead),\s*(?:make\s+that|let's\s+do)\s+([^\.]+?)(?:\s+instead\s+of\s+[^\.]+)?(?:\.|$)/i
    );
    if (correctionMatch && lastCommitmentIndex >= 0) {
      const newPhrase = correctionMatch[1].trim();
      const resolved = resolveDeadline(newPhrase, meetingAnchor, timezone);
      commitments[lastCommitmentIndex].deadline_timestamp = resolved.resolved_at;
      commitments[lastCommitmentIndex].deadline_type = resolved.deadline_type;
      commitments[lastCommitmentIndex].deadline_phrase = newPhrase;
      commitments[lastCommitmentIndex].source_evidence += ` [Updated in: "${line}"]`;
      commitments[lastCommitmentIndex].deadline_at = resolved.resolved_at;
      retractions_detected.push(line);
      continue;
    }

    // Check if statement is hypothetical or uncertain
    const isHypothetical = nonCommitmentPatterns.some((p) => p.test(line));

    // Parse speaker
    let speakerLabel = 'Speaker 1';
    let speakerName = 'Self';
    let text = line;

    const speakerMatch = line.match(/^(Speaker\s+\d+|[A-Za-z0-9\s]+)(?:\s*\(([^)]+)\))?\s*:\s*(.+)$/i);
    if (speakerMatch) {
      speakerLabel = speakerMatch[1].trim();
      speakerName = speakerMatch[2] ? speakerMatch[2].trim() : speakerLabel;
      text = speakerMatch[3].trim();
    }

    // Match participant mapping if available
    const mappedParticipant = participants.find((p) => {
      const pLabel = (p.label || '').toLowerCase();
      const pName = (p.name || '').toLowerCase();
      const matchLabel = speakerLabel.toLowerCase();
      return pLabel === matchLabel || pName === matchLabel;
    });
    if (mappedParticipant) {
      speakerName = mappedParticipant.name;
    }

    // If hypothetical, evaluate whether to surface as an uncertain clarification candidate
    if (isHypothetical) {
      commitments.push({
        id: `cmt_${meetingId}_hypo_${idx}`,
        meeting_id: meetingId,
        speaker_id: speakerLabel,
        responsible_person: speakerName,
        action: text.replace(/\b(?:maybe|if we have time|perhaps)\b/gi, '').trim(),
        commitment_type: 'clarification_needed',
        deadline_phrase: '',
        deadline_timestamp: null,
        deadline_type: 'undated',
        timezone,
        source_evidence: line,
        confidence: 0.45,
        is_flagged_uncertain: true,
        ambiguity_reason: 'Statement contains hypothetical intent or uncertainty markers ("maybe", "if we have time").',
        deduplication_hash: computeHash(`${meetingId}:${speakerName}:${text}`),
        title: text.substring(0, 50),
        action_description: text,
        owner_name: speakerName,
        owner_speaker_label: speakerLabel,
        transcript_excerpt: line,
        deadline_at: null,
        confidence_score: 0.45,
      });
      continue;
    }

    for (const pat of patterns) {
      const match = text.match(pat.regex);
      if (match) {
        let rawAction = match[1].trim();
        let rawDeadline = match[2] ? match[2].trim() : null;

        // If deadline ended up in rawAction (e.g. "change the design tomorrow")
        if (!rawDeadline) {
          const inlineDeadlineMatch = rawAction.match(
            /(.+?)\s+(tomorrow|next\s+\w+|by\s+\w+|before\s+[^\.]+)$/i
          );
          if (inlineDeadlineMatch) {
            rawAction = inlineDeadlineMatch[1].trim();
            rawDeadline = inlineDeadlineMatch[2].trim();
          }
        }

        // Deadline resolution relative to meeting anchor
        const resolved = resolveDeadline(rawDeadline, meetingAnchor, timezone);

        // Requests to someone else are flagged as pending confirmation
        const isUncertain = pat.isRequest || resolved.is_ambiguous;
        const assignedOwner = pat.isRequest ? 'Assignee (Pending Confirmation)' : speakerName;
        const commitmentType = pat.isRequest
          ? 'request'
          : resolved.is_ambiguous
          ? 'clarification_needed'
          : 'promise';

        const dedupeHash = computeHash(
          `${meetingId}:${speakerName}:${rawAction}:${resolved.resolved_at}`
        );

        const newCommitment: ExtractedCommitmentItem = {
          id: `cmt_${meetingId}_${idx}_${commitments.length}`,
          meeting_id: meetingId,
          speaker_id: speakerLabel,
          responsible_person: assignedOwner,
          action: rawAction,
          commitment_type: commitmentType,
          deadline_phrase: rawDeadline || '',
          deadline_timestamp: resolved.resolved_at,
          deadline_type: resolved.deadline_type,
          timezone,
          source_evidence: line,
          confidence: pat.isRequest ? 0.65 : resolved.is_ambiguous ? 0.7 : 0.95,
          is_flagged_uncertain: isUncertain,
          ambiguity_reason: resolved.ambiguity_reason || undefined,
          deduplication_hash: dedupeHash,
          title: rawAction.substring(0, 60),
          action_description: rawAction,
          owner_name: assignedOwner,
          owner_speaker_label: speakerLabel,
          transcript_excerpt: line,
          deadline_at: resolved.resolved_at,
          confidence_score: pat.isRequest ? 0.65 : 0.95,
        };

        commitments.push(newCommitment);
        lastCommitmentIndex = commitments.length - 1;
        break;
      }
    }
  }

  return {
    commitments,
    retractions_detected,
    provider: 'heuristic_engine',
  };
}

/**
 * Server-side Gemini LLM Commitment Extraction with schema validation
 * Accepts either:
 * - (transcript, meetingAnchor, timezone, participants, meetingId)
 * - or (transcript, meetingId, meetingAnchor, participants, timezone)
 */
export async function extractCommitmentsWithGemini(
  transcript: string,
  arg2?: string | Date,
  arg3?: string | Date,
  arg4?: any,
  arg5?: any
): Promise<GeminiExtractionResult> {
  // Disambiguate arguments
  let meetingAnchor: Date = new Date();
  let timezone = 'UTC';
  let participants: (string | { label?: string; name?: string })[] = [];
  let meetingId = 'mtg_default';

  if (arg2 instanceof Date || (typeof arg2 === 'string' && !isNaN(Date.parse(arg2)) && arg2.includes('-'))) {
    meetingAnchor = new Date(arg2);
    timezone = typeof arg3 === 'string' ? arg3 : 'UTC';
    participants = Array.isArray(arg4) ? arg4 : [];
    meetingId = typeof arg5 === 'string' ? arg5 : 'mtg_default';
  } else {
    meetingId = typeof arg2 === 'string' ? arg2 : 'mtg_default';
    meetingAnchor = arg3 ? new Date(arg3) : new Date();
    participants = Array.isArray(arg4) ? arg4 : [];
    timezone = typeof arg5 === 'string' ? arg5 : 'UTC';
  }

  const apiKey = process.env.GEMINI_API_KEY;

  // Fallback immediately to heuristic extraction if key is missing
  if (!apiKey || apiKey.trim() === '' || apiKey === 'YOUR_GEMINI_API_KEY_HERE') {
    return extractCommitmentsHeuristic(transcript, meetingAnchor, timezone, participants, meetingId);
  }

  try {
    const ai = new GoogleGenAI({ apiKey });
    const sanitized = sanitizeTranscript(transcript);

    const prompt = `You are CommitMind's AI Commitment Extraction Engine.
Analyze the following meeting transcript to identify genuine commitments.

CRITICAL RULES:
1. ONLY extract genuine commitments where a speaker promises an action (e.g. "I'll update the design", "I will finish the backend").
2. DO NOT extract suggestions ("Maybe we could"), hypotheticals ("What if we"), or statements of inability ("I won't be able to deliver it").
3. DO NOT treat requests to another person ("Can you send the design by Thursday?") as the recipient's promise. Mark them with is_commitment=false or is_flagged_uncertain=true.
4. Extract the exact sentence as transcript_excerpt.
5. Capture any mentioned deadline phrase.
6. Handle corrections (e.g. "Actually make that Monday instead of Friday").
7. Map speakers accurately based on the transcript labels.

Known Participants:
${JSON.stringify(participants, null, 2)}

Meeting Anchor Timestamp: ${meetingAnchor.toISOString()}
User Timezone: ${timezone}

Transcript:
"""
${sanitized}
"""`;

    const response = await ai.models.generateContent({
      model: process.env.GEMINI_MODEL || 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              action_description: { type: Type.STRING },
              speaker_label: { type: Type.STRING },
              speaker_name: { type: Type.STRING },
              transcript_excerpt: { type: Type.STRING },
              deadline_phrase: { type: Type.STRING },
              priority: { type: Type.STRING, enum: ['low', 'medium', 'high', 'urgent'] },
              confidence_score: { type: Type.NUMBER },
              is_commitment: { type: Type.BOOLEAN },
              is_flagged_uncertain: { type: Type.BOOLEAN },
              ambiguity_reason: { type: Type.STRING },
            },
            required: ['title', 'action_description', 'transcript_excerpt', 'is_commitment'],
          },
        },
      },
    });

    const parsedJson = JSON.parse(response.text || '[]');
    const commitments: ExtractedCommitmentItem[] = [];

    for (let i = 0; i < parsedJson.length; i++) {
      const raw = CommitmentExtractionSchema.safeParse(parsedJson[i]);
      if (!raw.success || !raw.data.is_commitment) continue;

      const data = raw.data;
      const resolved = resolveDeadline(data.deadline_phrase, meetingAnchor, timezone);
      const isUncertain = data.is_flagged_uncertain || resolved.is_ambiguous;
      const dedupeHash = computeHash(
        `${meetingId}:${data.speaker_label}:${data.title}:${resolved.resolved_at}`
      );

      commitments.push({
        id: `cmt-ai-${Date.now()}-${i}-${Math.random().toString(36).substring(2, 6)}`,
        meeting_id: meetingId,
        speaker_id: data.speaker_label,
        responsible_person: data.speaker_name || data.speaker_label,
        action: data.action_description,
        commitment_type: isUncertain ? 'clarification_needed' : 'promise',
        deadline_phrase: data.deadline_phrase || '',
        deadline_timestamp: resolved.resolved_at,
        deadline_type: resolved.deadline_type,
        timezone,
        source_evidence: data.transcript_excerpt,
        confidence: parseFloat(data.confidence_score.toFixed(2)),
        is_flagged_uncertain: isUncertain,
        ambiguity_reason: resolved.ambiguity_reason || data.ambiguity_reason || undefined,
        deduplication_hash: dedupeHash,
        title: data.title,
        action_description: data.action_description,
        owner_name: data.speaker_name || data.speaker_label,
        owner_speaker_label: data.speaker_label,
        transcript_excerpt: data.transcript_excerpt,
        deadline_at: resolved.resolved_at,
        confidence_score: parseFloat(data.confidence_score.toFixed(2)),
      });
    }

    if (commitments.length > 0) {
      return {
        commitments,
        retractions_detected: [],
        provider: 'gemini_llm',
      };
    }

    return extractCommitmentsHeuristic(
      transcript,
      meetingAnchor,
      timezone,
      participants,
      meetingId
    );
  } catch (err) {
    console.warn(
      '[CommitMind AI] Gemini extraction error, falling back to deterministic heuristic:',
      err
    );
    return extractCommitmentsHeuristic(
      transcript,
      meetingAnchor,
      timezone,
      participants,
      meetingId
    );
  }
}
