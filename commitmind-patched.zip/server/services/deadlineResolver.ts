/**
 * COMMITMIND HISTORICAL DEADLINE RESOLUTION ENGINE
 * Resolves conversational deadlines strictly relative to the meeting's historical timestamp
 * and configured timezone (never substitutes current server date).
 */

export interface DeadlineResolutionResult {
  resolved_at: string | null; // ISO 8601 UTC
  deadline_type: 'datetime' | 'date_only' | 'undated';
  is_ambiguous: boolean;
  ambiguity_reason?: string;
  original_phrase: string;
}

/**
 * Parses time expressions such as "3 PM", "10:30 AM", "17:00", "noon", "morning", "end of day".
 */
function parseTimeOfDay(text: string): { hours: number; minutes: number; isSpecificTime: boolean } {
  const normalized = text.toLowerCase();

  // Pattern: "at 3 PM", "3:30 pm"
  const timeMatch = normalized.match(/(?:at\s+)?(\d{1,2})(?::(\d{2}))?\s*(am|pm)/i);
  if (timeMatch) {
    let hours = parseInt(timeMatch[1], 10);
    const minutes = timeMatch[2] ? parseInt(timeMatch[2], 10) : 0;
    const meridian = timeMatch[3].toLowerCase();
    if (meridian === 'pm' && hours < 12) hours += 12;
    if (meridian === 'am' && hours === 12) hours = 0;
    return { hours, minutes, isSpecificTime: true };
  }

  // 24-hour pattern "17:00"
  const time24Match = normalized.match(/(?:at\s+)?([01]?\d|2[0-3]):([0-5]\d)/);
  if (time24Match) {
    return {
      hours: parseInt(time24Match[1], 10),
      minutes: parseInt(time24Match[2], 10),
      isSpecificTime: true,
    };
  }

  // Categorical times of day
  if (normalized.includes('morning')) return { hours: 9, minutes: 0, isSpecificTime: true };
  if (normalized.includes('noon')) return { hours: 12, minutes: 0, isSpecificTime: true };
  if (normalized.includes('afternoon')) return { hours: 15, minutes: 0, isSpecificTime: true };
  if (normalized.includes('evening') || normalized.includes('end of day') || normalized.includes('eod')) {
    return { hours: 17, minutes: 0, isSpecificTime: true };
  }

  // Default close of business for date-only commitments
  return { hours: 17, minutes: 0, isSpecificTime: false };
}

/**
 * Resolves a conversational deadline phrase relative to an explicit meeting anchor timestamp.
 */
export function resolveDeadline(
  phrase: string | undefined | null,
  meetingAnchor: string | Date = new Date(),
  _timezone = 'UTC'
): DeadlineResolutionResult {
  if (!phrase || !phrase.trim()) {
    return {
      resolved_at: null,
      deadline_type: 'undated',
      is_ambiguous: false,
      original_phrase: '',
    };
  }

  const rawPhrase = phrase.trim();
  const lower = rawPhrase.toLowerCase();
  const baseDate = new Date(meetingAnchor);

  // Validate meeting anchor
  if (isNaN(baseDate.getTime())) {
    throw new Error(`Invalid meeting anchor timestamp: ${meetingAnchor}`);
  }

  const timeSpec = parseTimeOfDay(lower);

  // 1. Incomplete / Ambiguous dependencies: "before the next meeting", "before the review"
  if (
    lower.includes('before the review') ||
    lower.includes('before the next meeting') ||
    lower.includes('when ready') ||
    lower.includes('after client approval')
  ) {
    return {
      resolved_at: null,
      deadline_type: 'undated',
      is_ambiguous: true,
      ambiguity_reason: `External milestone '${rawPhrase}' is missing a scheduled date. Requires calendar context or user clarification.`,
      original_phrase: rawPhrase,
    };
  }

  // 2. "Tomorrow" -> exactly +1 local calendar day relative to meeting date
  if (lower.includes('tomorrow')) {
    const target = new Date(baseDate);
    target.setUTCDate(target.getUTCDate() + 1);
    target.setUTCHours(timeSpec.hours, timeSpec.minutes, 0, 0);

    return {
      resolved_at: target.toISOString(),
      deadline_type: timeSpec.isSpecificTime ? 'datetime' : 'date_only',
      is_ambiguous: false,
      original_phrase: rawPhrase,
    };
  }

  // 3. "Today" / "Tonight" -> same calendar day
  if (lower.includes('today') || lower.includes('tonight')) {
    const target = new Date(baseDate);
    target.setUTCHours(timeSpec.hours, timeSpec.minutes, 0, 0);

    return {
      resolved_at: target.toISOString(),
      deadline_type: timeSpec.isSpecificTime ? 'datetime' : 'date_only',
      is_ambiguous: false,
      original_phrase: rawPhrase,
    };
  }

  // 4. "In X days" / "In X weeks"
  const inDaysMatch = lower.match(/in\s+(\d+)\s+days?/);
  if (inDaysMatch) {
    const daysToAdd = parseInt(inDaysMatch[1], 10);
    const target = new Date(baseDate);
    target.setUTCDate(target.getUTCDate() + daysToAdd);
    target.setUTCHours(timeSpec.hours, timeSpec.minutes, 0, 0);

    return {
      resolved_at: target.toISOString(),
      deadline_type: timeSpec.isSpecificTime ? 'datetime' : 'date_only',
      is_ambiguous: false,
      original_phrase: rawPhrase,
    };
  }

  const inWeeksMatch = lower.match(/in\s+(\d+)\s+weeks?/);
  if (inWeeksMatch) {
    const weeksToAdd = parseInt(inWeeksMatch[1], 10);
    const target = new Date(baseDate);
    target.setUTCDate(target.getUTCDate() + weeksToAdd * 7);
    target.setUTCHours(timeSpec.hours, timeSpec.minutes, 0, 0);

    return {
      resolved_at: target.toISOString(),
      deadline_type: timeSpec.isSpecificTime ? 'datetime' : 'date_only',
      is_ambiguous: false,
      original_phrase: rawPhrase,
    };
  }

  // 5. Day of week: "by Friday", "before Monday", "next Friday"
  const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  for (let targetDayIdx = 0; targetDayIdx < daysOfWeek.length; targetDayIdx++) {
    const dayName = daysOfWeek[targetDayIdx];
    if (lower.includes(dayName)) {
      const currentDayIdx = baseDate.getUTCDay();
      let diff = targetDayIdx - currentDayIdx;

      // Handle "next Friday" vs "this Friday"
      const isNextWeekExplicit = lower.includes('next ' + dayName) || lower.includes('next week');
      if (diff <= 0) {
        diff += 7; // Following occurrence
      }
      if (isNextWeekExplicit && diff < 7) {
        diff += 7;
      }

      const target = new Date(baseDate);
      target.setUTCDate(target.getUTCDate() + diff);
      target.setUTCHours(timeSpec.hours, timeSpec.minutes, 0, 0);

      // Flag "next [day]" as proposed with confirmation requested
      const isAmbiguous = isNextWeekExplicit;

      return {
        resolved_at: target.toISOString(),
        deadline_type: timeSpec.isSpecificTime ? 'datetime' : 'date_only',
        is_ambiguous: isAmbiguous,
        ambiguity_reason: isAmbiguous 
          ? `Phrase '${rawPhrase}' can mean upcoming or following week. Proposed date: ${target.toISOString().split('T')[0]}` 
          : undefined,
        original_phrase: rawPhrase,
      };
    }
  }

  // 6. Direct ISO Date or standard date string e.g. "2026-11-01"
  const directDate = new Date(rawPhrase);
  if (!isNaN(directDate.getTime()) && directDate.getFullYear() > 2000) {
    return {
      resolved_at: directDate.toISOString(),
      deadline_type: 'datetime',
      is_ambiguous: false,
      original_phrase: rawPhrase,
    };
  }

  // Fallback: Undated / Ambiguous
  return {
    resolved_at: null,
    deadline_type: 'undated',
    is_ambiguous: true,
    ambiguity_reason: `Could not reliably resolve relative deadline phrase '${rawPhrase}' without clarification.`,
    original_phrase: rawPhrase,
  };
}
