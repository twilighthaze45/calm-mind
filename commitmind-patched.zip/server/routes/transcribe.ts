/**
 * POST /api/transcribe
 * Accepts WAV, MP3, WebM audio files, runs Gemini STT with diarization,
 * and returns structured segments and transcript text.
 */

import { Router, Request, Response } from 'express';
import multer from 'multer';
import path from 'node:path';
import fs from 'node:fs';
import { transcribeAudioFile } from '../services/audioTranscription';

export const transcribeRouter = Router();

const UPLOADS_DIR = path.resolve(process.cwd(), 'scratch_uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname) || '.webm';
    cb(null, `audio_${Date.now()}_${Math.random().toString(36).substring(2, 7)}${ext}`);
  },
});

const upload = multer({
  storage,
  limits: {
    fileSize: 30 * 1024 * 1024, // 30 MB
  },
});

transcribeRouter.post(
  '/',
  upload.single('audio'),
  async (req: Request, res: Response): Promise<void> => {
    let tempPath: string | null = null;
    try {
      if (!req.file) {
        res.status(400).json({ error: 'No audio file provided in request.' });
        return;
      }

      tempPath = req.file.path;
      const mimeType = req.file.mimetype || 'audio/webm';
      let participantNames: string[] = [];

      if (req.body.participant_names) {
        try {
          participantNames = JSON.parse(req.body.participant_names);
        } catch {
          if (typeof req.body.participant_names === 'string') {
            participantNames = req.body.participant_names.split(',').map((s: string) => s.trim());
          }
        }
      }

      const result = await transcribeAudioFile(tempPath, mimeType, participantNames);

      res.json({
        success: true,
        ...result,
        file_size_bytes: req.file.size,
        file_name: req.file.originalname,
      });
    } catch (error: any) {
      console.error('Transcription API error:', error);
      res.status(500).json({ error: error.message || 'Audio transcription failed' });
    } finally {
      // Clean up temporary audio file
      if (tempPath && fs.existsSync(tempPath)) {
        try {
          fs.unlinkSync(tempPath);
        } catch {
          // Ignore unlink errors
        }
      }
    }
  }
);
