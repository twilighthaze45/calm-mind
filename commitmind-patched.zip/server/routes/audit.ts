/**
 * AUDIT API ROUTER
 * Exposes immutable commitment history and lifecycle audit trail.
 */

import { Router, Request, Response } from 'express';
import { auditLogger } from '../services/auditLogger';

export const auditRouter = Router();

// GET /api/audit/logs
auditRouter.get('/logs', (req: Request, res: Response) => {
  const { commitment_id, limit } = req.query;

  if (commitment_id && typeof commitment_id === 'string') {
    const events = auditLogger.getEventsForCommitment(commitment_id);
    res.json({ success: true, count: events.length, events });
    return;
  }

  const limitNum = limit ? parseInt(String(limit), 10) : 100;
  const events = auditLogger.getAllEvents(limitNum);
  res.json({ success: true, count: events.length, events });
});
