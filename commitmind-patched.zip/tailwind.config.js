/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        warm: {
          50: '#FAF8F5',
          100: '#F5F2EB',
          200: '#ECE7DE',
          300: '#DFD8CC',
          400: '#BDB3A1',
          500: '#8F8471',
          600: '#6E6453',
          700: '#524B3E',
          800: '#39342B',
          900: '#221F1A',
        },
        sage: {
          50: '#F3F7F5',
          100: '#E4EFE8',
          200: '#CADCD2',
          300: '#A4C3B2',
          400: '#84A98C',
          500: '#52796F',
          600: '#3F635A',
          700: '#354F52',
          800: '#283B3D',
          900: '#1C292B',
        },
        sand: {
          50: '#FAF6F0',
          100: '#F2EAE0',
          200: '#E4D5C3',
          500: '#C5A880',
        },
      },
      fontFamily: {
        sans: [
          'Plus Jakarta Sans',
          'Inter',
          '-apple-system',
          'BlinkMacSystemFont',
          'Segoe UI',
          'Roboto',
          'sans-serif',
        ],
        serif: [
          'Fraunces',
          'Merriweather',
          'serif',
        ],
      },
      animation: {
        'breathe-in-out': 'breathe 16s ease-in-out infinite',
        'subtle-pulse': 'subtlePulse 4s ease-in-out infinite',
        'float-slow': 'float 6s ease-in-out infinite',
      },
      keyframes: {
        breathe: {
          '0%, 100%': { transform: 'scale(1)', opacity: '0.85' },
          '25%': { transform: 'scale(1.35)', opacity: '1' },
          '50%': { transform: 'scale(1.35)', opacity: '1' },
          '75%': { transform: 'scale(1)', opacity: '0.85' },
        },
        subtlePulse: {
          '0%, 100%': { opacity: '0.9', transform: 'scale(1)' },
          '50%': { opacity: '1', transform: 'scale(1.02)' },
        },
        float: {
          '0%, 100%': { transform: 'translateY(0px)' },
          '50%': { transform: 'translateY(-6px)' },
        },
      },
      boxShadow: {
        'warm-sm': '0 1px 3px 0 rgba(82, 75, 62, 0.05)',
        'warm-md': '0 4px 16px -2px rgba(82, 75, 62, 0.08), 0 2px 6px -2px rgba(82, 75, 62, 0.04)',
        'warm-lg': '0 12px 28px -4px rgba(82, 75, 62, 0.1), 0 4px 12px -2px rgba(82, 75, 62, 0.05)',
        'sage-glow': '0 0 25px -4px rgba(82, 121, 111, 0.25)',
      },
    },
  },
  plugins: [],
};
