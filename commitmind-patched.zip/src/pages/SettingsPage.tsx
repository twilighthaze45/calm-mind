import { Settings, Database, Shield, Download, Trash2, Key, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useMindfulness } from '../context/MindfulnessContext';
import { getSupabaseConfig } from '../services/supabase';
import { transcriptionManager } from '../services/transcription';

export const SettingsPage: React.FC = () => {
  const { isSupabaseReady, showToast, moods, journals, stats } = useMindfulness();
  const config = getSupabaseConfig();
  const activeProvider = transcriptionManager.getActiveProvider();

  const handleExportData = () => {
    const data = {
      export_date: new Date().toISOString(),
      stats,
      moods,
      journals,
    };
    const jsonString = `data:text/json;charset=utf-8,${encodeURIComponent(JSON.stringify(data, null, 2))}`;
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', jsonString);
    downloadAnchor.setAttribute('download', `calmmind-backup-${new Date().toISOString().split('T')[0]}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Mindful data exported successfully 💾', 'success');
  };

  const handleClearData = () => {
    if (window.confirm('Reset all demo reflections and moods back to original settings?')) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <Settings className="w-4 h-4" />
            <span>Preferences & Sync</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-800">
            Settings & Connectivity
          </h2>
          <p className="text-sm text-stone-600 mt-1">
            Manage your Supabase database sync, data privacy, and speech preferences.
          </p>
        </div>
      </div>

      {/* Supabase Connection Card */}
      <div className="calm-card p-6 sm:p-8">
        <div className="flex items-start justify-between gap-4 mb-4">
          <div className="flex items-center gap-3">
            <div className={`p-3 rounded-2xl ${isSupabaseReady ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700'}`}>
              <Database className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-stone-800">
                Supabase Backend & PostgreSQL Sync
              </h3>
              <p className="text-xs text-stone-600">
                Row Level Security (RLS) encrypted persistence
              </p>
            </div>
          </div>

          <div className={`px-3 py-1 rounded-full text-xs font-bold flex items-center gap-1.5 ${
            isSupabaseReady 
              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' 
              : 'bg-amber-100 text-amber-800 border border-amber-200'
          }`}>
            {isSupabaseReady ? (
              <>
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                <span>Connected</span>
              </>
            ) : (
              <>
                <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                <span>Local Cache Mode</span>
              </>
            )}
          </div>
        </div>

        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed mb-4">
          {isSupabaseReady
            ? `CalmMind is connected to your Supabase project at: ${config.url}. All your reflections and moods sync securely under PostgreSQL Row Level Security.`
            : `Currently running in private Local Cache mode. To sync with your existing Supabase project, specify your project credentials in .env.`}
        </p>

        {/* Security Checklist Notice */}
        <div className="p-4 rounded-2xl bg-warm-50 border border-warm-200/80 space-y-2 text-xs text-stone-700 mb-6">
          <div className="flex items-center gap-2 font-bold text-stone-800">
            <Shield className="w-4 h-4 text-sage-600" />
            <span>Frontend Security Guarantee</span>
          </div>
          <p>
            • Only <code className="px-1.5 py-0.5 rounded bg-warm-200 text-stone-800">VITE_SUPABASE_URL</code> and <code className="px-1.5 py-0.5 rounded bg-warm-200 text-stone-800">VITE_SUPABASE_PUBLISHABLE_KEY</code> are accessed in the client.
          </p>
          <p>
            • Secret service role keys are <strong>never</strong> requested or bundled in frontend client builds.
          </p>
          <p>
            • Complete SQL schema with user-level isolation policies is located in <code className="px-1.5 py-0.5 rounded bg-warm-200 text-stone-800">supabase/schema.sql</code>.
          </p>
        </div>

        {/* Environment Variable Setup Instructions */}
        <div className="space-y-2">
          <label className="block text-xs font-bold uppercase tracking-wider text-stone-600">
            Environment Configuration (.env)
          </label>
          <div className="p-3.5 rounded-xl bg-warm-900 text-stone-100 font-mono text-xs overflow-x-auto select-all">
            VITE_SUPABASE_URL=https://your-project.supabase.co<br />
            VITE_SUPABASE_PUBLISHABLE_KEY=eyJhbGciOi...
          </div>
        </div>
      </div>

      {/* Voice Journaling Provider Settings */}
      <div className="calm-card p-6 sm:p-8">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-3 rounded-2xl bg-sage-100 text-sage-700">
            <Key className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-serif font-bold text-lg text-stone-800">
              Voice Transcription Engine
            </h3>
            <p className="text-xs text-stone-600">Provider-independent voice architecture</p>
          </div>
        </div>

        <div className="p-4 rounded-2xl bg-warm-50 border border-warm-200 text-xs text-stone-700 space-y-2">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-stone-800">Active Provider:</span>
            <span className="px-2.5 py-1 rounded-full bg-sage-200/80 text-sage-800 font-bold">
              {activeProvider.name}
            </span>
          </div>
          <p className="text-stone-600">
            Voice journaling utilizes browser speech recognition with immediate offline fallbacks. Pluggable provider interface supports expanding to Cloud Whisper endpoints.
          </p>
        </div>
      </div>

      {/* Data Management Card */}
      <div className="calm-card p-6 sm:p-8">
        <h3 className="font-serif font-bold text-lg text-stone-800 mb-2">
          Your Mindful Data Ownership
        </h3>
        <p className="text-xs sm:text-sm text-stone-600 mb-6">
          Your reflections belong strictly to you. Download or reset your data at any time.
        </p>

        <div className="flex flex-wrap items-center gap-4">
          <button
            onClick={handleExportData}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm transition-all"
          >
            <Download className="w-4 h-4" />
            <span>Export Backup (JSON)</span>
          </button>

          <button
            onClick={handleClearData}
            className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-rose-200 text-rose-700 hover:bg-rose-50 text-xs font-semibold transition-all"
          >
            <Trash2 className="w-4 h-4" />
            <span>Reset Demo Data</span>
          </button>
        </div>
      </div>
    </div>
  );
};
