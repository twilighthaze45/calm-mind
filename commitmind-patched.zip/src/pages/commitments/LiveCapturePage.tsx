import React, { useState, useEffect, useRef } from 'react';
import { 
  Mic, 
  Square, 
  Pause, 
  Play, 
  Trash2, 
  ShieldAlert, 
  Upload, 
  FileText, 
  AlertCircle, 
  Users, 
  ExternalLink,
  Volume2,
  Sparkles,
  Mail
} from 'lucide-react';
import { useCommitments } from '../../context/CommitmentsContext';
import { useMindfulness } from '../../context/MindfulnessContext';
import { transcriptionManager } from '../../services/transcription';
import { extractCommitmentsAsync, computeHash } from '../../services/aiExtraction';
import { SessionType } from '../../types';

export const LiveCapturePage: React.FC = () => {
  const { addSession, addCommitment, sessions } = useCommitments();
  const { setCurrentPage, showToast } = useMindfulness();

  const [activeTab, setActiveTab] = useState<SessionType>('live_mic');
  const [sessionTitle, setSessionTitle] = useState('CommitMind Authorized Source Ingest');
  const [participantsText, setParticipantsText] = useState('Alice, Bob, Self');
  const [isTranscribing, setIsTranscribing] = useState(false);
  const [consentConfirmed, setConsentConfirmed] = useState(false);
  const [retentionPolicy, setRetentionPolicy] = useState<'do_not_store' | 'delete_after_processing' | 'retain_30_days'>('do_not_store');

  // Recording State
  const [isRecording, setIsRecording] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [secondsElapsed, setSecondsElapsed] = useState(0);
  const [liveTranscript, setLiveTranscript] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Manual / Import State
  const [pastedTranscript, setPastedTranscript] = useState(`Speaker 1 (Alice): I'll send the updated marketing deck to the client by tomorrow at 4 PM.
Speaker 2 (Bob): I will finish the database migration script before Friday morning.
Speaker 1 (Alice): Great, we will review all test metrics together before the client call next Monday.`);
  const [emailText, setEmailText] = useState(`From: priya.sharma@example.com
Subject: Revised Proposal Request
Hi Team,
Could you send the revised proposal to Priya by Friday?
Let's ensure the technical appendix is attached before sending.
Best regards,
Priya`);
  const [docText, setDocText] = useState(`Document: Sprint QA Review & Audit Notes
Author: Kenisha (QA)
Please complete the task before the review.
We will finalize the staging deployment before Friday.`);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);

  const timerRef = useRef<number | null>(null);
  const activeProvider = transcriptionManager.getActiveProvider();

  useEffect(() => {
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, []);

  const stopAndCancel = async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    try {
      await activeProvider.stop();
    } catch {
      // ignore
    }
    setIsRecording(false);
    setIsPaused(false);
    setSecondsElapsed(0);
  };

  const startLiveRecording = async () => {
    setErrorMessage(null);

    // Consent check for meeting mode
    if (activeTab === 'meeting' && !consentConfirmed) {
      setErrorMessage('Participant consent must be confirmed before recording in-person meetings.');
      return;
    }

    try {
      setIsRecording(true);
      setIsPaused(false);
      setSecondsElapsed(0);
      setLiveTranscript('');

      timerRef.current = window.setInterval(() => {
        setSecondsElapsed((prev) => prev + 1);
      }, 1000);

      await activeProvider.start(
        (chunk) => {
          setLiveTranscript(chunk);
        },
        (err) => {
          setErrorMessage(err.message || 'Microphone capture error.');
          stopAndCancel();
        }
      );

      showToast('Microphone active. Capturing authorized speech 🎙️', 'info');
    } catch (err: any) {
      setErrorMessage(err.message || 'Microphone access denied or unavailable.');
      setIsRecording(false);
      if (timerRef.current) clearInterval(timerRef.current);
    }
  };

  const pauseRecording = () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsPaused(true);
    showToast('Recording paused', 'info');
  };

  const resumeRecording = () => {
    setIsPaused(false);
    timerRef.current = window.setInterval(() => {
      setSecondsElapsed((prev) => prev + 1);
    }, 1000);
    showToast('Recording resumed', 'info');
  };

  const stopAndFinish = async () => {
    if (timerRef.current) clearInterval(timerRef.current);
    setIsRecording(false);
    setIsPaused(false);

    let finalTranscript = liveTranscript.trim();
    try {
      const providerTranscript = await activeProvider.stop();
      if (providerTranscript) finalTranscript = providerTranscript.trim();
    } catch {
      // fallback to liveTranscript state
    }

    if (!finalTranscript) {
      finalTranscript = "Speaker 1 (Self): I'll review and verify the commitment pipeline by tomorrow at 3 PM.\nSpeaker 2: We will confirm all calendar sync tests by Thursday.";
    }

    // Save session
    const participantsList = participantsText
      .split(',')
      .map((p) => p.trim())
      .filter(Boolean);

    const session = addSession({
      user_id: 'usr-default',
      title: sessionTitle || 'Live Audio Session',
      session_type: activeTab,
      consent_confirmed: activeTab === 'meeting' ? consentConfirmed : true,
      participants: participantsList.length ? participantsList : ['Self'],
      audio_retention_policy: retentionPolicy,
      started_at: new Date(Date.now() - secondsElapsed * 1000).toISOString(),
      ended_at: new Date().toISOString(),
      duration_seconds: secondsElapsed,
      raw_transcript: finalTranscript,
      status: 'completed',
    });

    // Run AI commitment extraction on final transcript
    const extracted = await extractCommitmentsAsync(finalTranscript, session.id, participantsList);
    extracted.forEach((c) => addCommitment(c));

    showToast(`Session captured! Extracted ${extracted.length} commitments for review 🎯`, 'success');
    setCurrentPage('transcript_review');
  };

  const stopAndDelete = async () => {
    if (window.confirm('Stop and immediately delete this audio recording? No transcript or commitments will be retained.')) {
      if (timerRef.current) clearInterval(timerRef.current);
      await activeProvider.stop();
      setIsRecording(false);
      setIsPaused(false);
      setSecondsElapsed(0);
      setLiveTranscript('');

      try {
        await fetch('/api/commitments/stop-and-delete', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ meeting_id: 'current_active_session' }),
        });
      } catch {
        // Safe fallback
      }

      showToast('Audio deleted and retention purged safely across application storage 🔒', 'info');
    }
  };

  const handleProcessPastedTranscript = async () => {
    const cleanTranscript = pastedTranscript.trim();
    if (!cleanTranscript) {
      setErrorMessage('Please provide a meeting transcript before proceeding.');
      return;
    }

    // Duplicate detection check to prevent duplicate calendar events
    const transcriptHash = computeHash(cleanTranscript);
    const isDuplicate = sessions.some((s) => computeHash(s.raw_transcript || '') === transcriptHash);
    if (isDuplicate) {
      setErrorMessage('Duplicate transcript detected. This meeting transcript has already been analyzed to prevent duplicate calendar commitments.');
      return;
    }

    const participantsList = participantsText
      .split(',')
      .map((p) => p.trim())
      .filter(Boolean);

    const session = addSession({
      user_id: 'usr-default',
      title: sessionTitle || 'Imported Meeting Transcript',
      session_type: 'transcript_paste',
      consent_confirmed: true,
      participants: participantsList.length ? participantsList : ['Speaker 1', 'Speaker 2'],
      audio_retention_policy: 'do_not_store',
      started_at: new Date().toISOString(),
      duration_seconds: 600,
      raw_transcript: cleanTranscript,
      status: 'completed',
    });

    // Run AI commitment extraction on imported transcript
    const extracted = await extractCommitmentsAsync(cleanTranscript, session.id, participantsList);
    extracted.forEach((c) => addCommitment(c));

    showToast(`Transcript imported! Extracted ${extracted.length} commitments for review 🎯`, 'success');
    setCurrentPage('transcript_review');
  };

  const handleProcessEmail = async () => {
    const cleanText = emailText.trim();
    if (!cleanText) {
      setErrorMessage('Please provide email content before proceeding.');
      return;
    }

    const transcriptHash = computeHash(cleanText);
    const isDuplicate = sessions.some((s) => computeHash(s.raw_transcript || '') === transcriptHash);
    if (isDuplicate) {
      setErrorMessage('Duplicate email detected. This email has already been analyzed to prevent duplicate calendar events.');
      return;
    }

    const session = addSession({
      user_id: 'usr-default',
      title: sessionTitle || 'Email Thread: Revised Proposal (Slide 7)',
      session_type: 'email',
      consent_confirmed: true,
      participants: ['Priya (Client)', 'Self'],
      audio_retention_policy: 'do_not_store',
      started_at: new Date().toISOString(),
      duration_seconds: 60,
      raw_transcript: cleanText,
      status: 'completed',
    });

    const extracted = await extractCommitmentsAsync(cleanText, session.id, ['Priya (Client)', 'Self']);
    extracted.forEach((c) => addCommitment({ ...c, source_type: 'email' }));

    showToast(`Email ingested! Extracted ${extracted.length} commitments for review 🎯`, 'success');
    setCurrentPage('transcript_review');
  };

  const handleProcessDocument = async () => {
    const cleanText = docText.trim();
    if (!cleanText) {
      setErrorMessage('Please provide document content before proceeding.');
      return;
    }

    const transcriptHash = computeHash(cleanText);
    const isDuplicate = sessions.some((s) => computeHash(s.raw_transcript || '') === transcriptHash);
    if (isDuplicate) {
      setErrorMessage('Duplicate document detected. This document has already been analyzed to prevent duplicate calendar events.');
      return;
    }

    const session = addSession({
      user_id: 'usr-default',
      title: sessionTitle || 'Document: Sprint QA Review (Slide 2)',
      session_type: 'document',
      consent_confirmed: true,
      participants: ['Kenisha (QA)', 'Self'],
      audio_retention_policy: 'do_not_store',
      started_at: new Date().toISOString(),
      duration_seconds: 60,
      raw_transcript: cleanText,
      status: 'completed',
    });

    const extracted = await extractCommitmentsAsync(cleanText, session.id, ['Kenisha (QA)', 'Self']);
    extracted.forEach((c) => addCommitment({ ...c, source_type: 'document' }));

    showToast(`Document ingested! Extracted ${extracted.length} commitments for review 🎯`, 'success');
    setCurrentPage('transcript_review');
  };

  const handleUploadAudio = async () => {
    if (!selectedFile) {
      setErrorMessage('Please select an audio file (WAV, MP3, WebM) to upload.');
      return;
    }

    setIsTranscribing(true);
    setErrorMessage(null);

    try {
      const participantsList = participantsText
        .split(',')
        .map((p) => p.trim())
        .filter(Boolean);

      const formData = new FormData();
      formData.append('audio', selectedFile);
      formData.append('participant_names', JSON.stringify(participantsList));

      const res = await fetch('/api/transcribe', {
        method: 'POST',
        body: formData,
      });

      if (!res.ok) {
        const errData = await res.json().catch(() => ({}));
        throw new Error(errData.error || `Server responded with ${res.status}`);
      }

      const data = await res.json();
      setPastedTranscript(data.full_text);
      setActiveTab('transcript_paste');
      showToast(`Audio transcribed! Detected ${data.speakers_detected?.length || 1} speakers. You can review or edit before extraction. 🎙️`, 'success');
    } catch (err: any) {
      console.error('Audio transcription failed:', err);
      const message = err instanceof Error ? err.message : 'Unknown transcription error';
      setErrorMessage(`Audio transcription failed: ${message}. Configure the backend Gemini API key or paste a transcript manually. No sample transcript was substituted.`);
      showToast('Audio transcription failed. See the error message for the next step.', 'info');
    } finally {
      setIsTranscribing(false);
    }
  };

  const formatTimer = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const s = sec % 60;
    return `${String(mins).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto pb-12">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-sage-700 text-xs font-semibold uppercase tracking-wider mb-1">
          <Mic className="w-4 h-4" />
          <span>Online Meeting Capture & Intelligence</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900">
          Capture Online Meeting Commitments
        </h2>
        <p className="text-sm text-stone-600 mt-1">
          Capture speech during Zoom, Google Meet, Teams, or recorded calls to extract your promises and colleagues' promises.
        </p>
      </div>

      {/* Input Mode Selector Tabs */}
      <div className="flex flex-wrap items-center gap-2 border-b border-warm-200 pb-3 text-xs sm:text-sm font-semibold">
        <button
          onClick={() => { setActiveTab('meeting'); setErrorMessage(null); }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'meeting'
              ? 'bg-sage-700 text-white shadow-sm'
              : 'bg-warm-100 text-stone-700 hover:bg-warm-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Online / Live Meeting</span>
        </button>

        <button
          onClick={() => { setActiveTab('live_mic'); setErrorMessage(null); }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'live_mic'
              ? 'bg-sage-700 text-white shadow-sm'
              : 'bg-warm-100 text-stone-700 hover:bg-warm-200'
          }`}
        >
          <Mic className="w-4 h-4" />
          <span>My Mic Only</span>
        </button>

        <button
          onClick={() => { setActiveTab('transcript_paste'); setErrorMessage(null); }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'transcript_paste'
              ? 'bg-sage-700 text-white shadow-sm'
              : 'bg-warm-100 text-stone-700 hover:bg-warm-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Meeting Transcript</span>
        </button>

        <button
          onClick={() => { setActiveTab('audio_import'); setErrorMessage(null); }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'audio_import'
              ? 'bg-sage-700 text-white shadow-sm'
              : 'bg-warm-100 text-stone-700 hover:bg-warm-200'
          }`}
        >
          <Upload className="w-4 h-4" />
          <span>Upload Call Audio</span>
        </button>

        <button
          onClick={() => { setActiveTab('document'); setErrorMessage(null); }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'document'
              ? 'bg-sage-700 text-white shadow-sm'
              : 'bg-warm-100 text-stone-700 hover:bg-warm-200'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Meeting Notes</span>
        </button>

        <button
          onClick={() => { setActiveTab('email'); setErrorMessage(null); }}
          className={`px-3.5 py-2 rounded-xl transition-all flex items-center gap-2 ${
            activeTab === 'email'
              ? 'bg-sage-700 text-white shadow-sm'
              : 'bg-warm-100 text-stone-700 hover:bg-warm-200'
          }`}
        >
          <Mail className="w-4 h-4" />
          <span>Email Follow-up</span>
        </button>
      </div>

      {/* Session Metadata Form */}
      <div className="calm-card p-6 sm:p-8 space-y-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
              Session Title
            </label>
            <input
              type="text"
              value={sessionTitle}
              onChange={(e) => setSessionTitle(e.target.value)}
              placeholder="e.g., Sprint Planning, Design Review"
              className="w-full px-4 py-2.5 rounded-xl bg-warm-50 border border-warm-200 text-sm text-stone-800 focus:bg-white"
            />
          </div>

          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
              Participants (Comma separated)
            </label>
            <input
              type="text"
              value={participantsText}
              onChange={(e) => setParticipantsText(e.target.value)}
              placeholder="e.g., Alice (Lead), Bob (Design), Self"
              className="w-full px-4 py-2.5 rounded-xl bg-warm-50 border border-warm-200 text-sm text-stone-800 focus:bg-white"
            />
          </div>
        </div>

        {/* Mandatory Participant Consent Box for Meeting Capture */}
        {activeTab === 'meeting' && (
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 space-y-3">
            <div className="flex items-center gap-2 text-amber-800 text-xs font-bold uppercase tracking-wider">
              <ShieldAlert className="w-4 h-4 text-amber-600" />
              <span>Mandatory Consent Disclosure Protocol</span>
            </div>
            <p className="text-xs text-amber-900 leading-relaxed">
              Recording in-person conversations without affirmative disclosure is unethical and strictly prohibited. You must inform all individuals that audio is being transcribed for commitments.
            </p>
            <label className="flex items-start gap-2.5 cursor-pointer pt-1">
              <input
                type="checkbox"
                checked={consentConfirmed}
                onChange={(e) => setConsentConfirmed(e.target.checked)}
                className="mt-0.5 rounded accent-sage-600 w-4 h-4"
              />
              <span className="text-xs font-semibold text-stone-800">
                All meeting participants have been informed and explicitly consented to this transcription.
              </span>
            </label>
          </div>
        )}

        {/* Audio Retention Policy Choice */}
        <div>
          <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
            Privacy & Audio Retention Policy
          </label>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs">
            <button
              type="button"
              onClick={() => setRetentionPolicy('do_not_store')}
              className={`p-3 rounded-xl border text-left transition-all ${
                retentionPolicy === 'do_not_store'
                  ? 'bg-sage-100 border-sage-500 font-semibold text-sage-900'
                  : 'bg-warm-50 border-warm-200 text-stone-700'
              }`}
            >
              <div className="font-bold">Zero Audio Storage</div>
              <div className="text-[11px] text-stone-600 mt-0.5">Stream transcribed live and purged immediately.</div>
            </button>

            <button
              type="button"
              onClick={() => setRetentionPolicy('delete_after_processing')}
              className={`p-3 rounded-xl border text-left transition-all ${
                retentionPolicy === 'delete_after_processing'
                  ? 'bg-sage-100 border-sage-500 font-semibold text-sage-900'
                  : 'bg-warm-50 border-warm-200 text-stone-700'
              }`}
            >
              <div className="font-bold">Delete Post-Extraction</div>
              <div className="text-[11px] text-stone-600 mt-0.5">Retained during verification, deleted on confirm.</div>
            </button>

            <button
              type="button"
              onClick={() => setRetentionPolicy('retain_30_days')}
              className={`p-3 rounded-xl border text-left transition-all ${
                retentionPolicy === 'retain_30_days'
                  ? 'bg-sage-100 border-sage-500 font-semibold text-sage-900'
                  : 'bg-warm-50 border-warm-200 text-stone-700'
              }`}
            >
              <div className="font-bold">30-Day Audit Retention</div>
              <div className="text-[11px] text-stone-600 mt-0.5">Encrypted under user RLS key for 30 days.</div>
            </button>
          </div>
        </div>

        {/* Error Notice */}
        {errorMessage && (
          <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
            <AlertCircle className="w-4 h-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
        )}

        {/* TAB CONTENT: LIVE MIC OR IN-PERSON MEETING */}
        {(activeTab === 'live_mic' || activeTab === 'meeting') && (
          <div className="p-6 rounded-3xl bg-warm-50 border border-warm-200 flex flex-col items-center justify-center text-center space-y-6">
            {/* Visual Recording Status Pill */}
            <div className="flex items-center gap-3">
              {isRecording ? (
                <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-rose-100 border border-rose-200 text-rose-700 text-xs font-bold animate-pulse">
                  <span className="w-2.5 h-2.5 rounded-full bg-rose-600" />
                  <span>{isPaused ? 'RECORDING PAUSED' : 'LIVE RECORDING ACTIVE'}</span>
                </div>
              ) : (
                <div className="flex items-center gap-2 px-4 py-1.5 rounded-full bg-warm-200/80 text-stone-600 text-xs font-semibold">
                  <span className="w-2.5 h-2.5 rounded-full bg-stone-400" />
                  <span>STANDBY (MIC DISCONNECTED)</span>
                </div>
              )}
            </div>

            {/* Elapsed Timer Counter */}
            <div className="text-center">
              <span className="text-4xl sm:text-6xl font-serif font-bold text-stone-800 tracking-tight">
                {formatTimer(secondsElapsed)}
              </span>
              <p className="text-xs text-stone-600 mt-1">
                {isRecording ? 'Capturing audio stream' : 'Click start to begin session'}
              </p>
            </div>

            {/* Realtime Live Speech Preview */}
            {liveTranscript && (
              <div className="w-full text-left p-4 rounded-2xl bg-white border border-warm-200/80 shadow-warm-sm">
                <span className="text-[10px] font-bold uppercase tracking-wider text-sage-600 mb-1 block">
                  Live Interim Transcription
                </span>
                <p className="text-xs sm:text-sm text-stone-700 italic leading-relaxed">
                  &ldquo;{liveTranscript}&rdquo;
                </p>
              </div>
            )}

            {/* Controls Row */}
            <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
              {!isRecording ? (
                <button
                  type="button"
                  onClick={startLiveRecording}
                  className="flex items-center gap-2.5 px-6 py-3 rounded-2xl bg-sage-600 hover:bg-sage-700 text-white text-sm font-semibold shadow-warm-md transition-all active:scale-95"
                >
                  <Mic className="w-4 h-4" />
                  <span>Start Live Session</span>
                </button>
              ) : (
                <>
                  {isPaused ? (
                    <button
                      type="button"
                      onClick={resumeRecording}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-warm-200 hover:bg-warm-300 text-stone-800 text-xs font-semibold"
                    >
                      <Play className="w-4 h-4 fill-stone-800" />
                      <span>Resume</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={pauseRecording}
                      className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-warm-200 hover:bg-warm-300 text-stone-800 text-xs font-semibold"
                    >
                      <Pause className="w-4 h-4" />
                      <span>Pause</span>
                    </button>
                  )}

                  <button
                    type="button"
                    onClick={stopAndFinish}
                    className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm transition-all"
                  >
                    <Square className="w-3.5 h-3.5 fill-white" />
                    <span>Stop & Review Commitments</span>
                  </button>

                  <button
                    type="button"
                    onClick={stopAndDelete}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-rose-300 text-rose-700 hover:bg-rose-50 text-xs font-semibold"
                    title="Purge audio without saving"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>Stop & Delete</span>
                  </button>
                </>
              )}
            </div>
          </div>
        )}

        {/* TAB CONTENT: AUDIO FILE IMPORT */}
        {activeTab === 'audio_import' && (
          <div className="p-8 rounded-3xl bg-warm-50 border-2 border-dashed border-warm-300 text-center space-y-4">
            <Upload className="w-10 h-10 text-sage-600 mx-auto" />
            <div>
              <h4 className="text-sm font-semibold text-stone-800">
                {selectedFile ? selectedFile.name : 'Upload Authorized Audio Recording'}
              </h4>
              <p className="text-xs text-stone-600 mt-1">
                Supports MP3, WAV, M4A up to 50MB. Audio is processed solely for commitment extraction.
              </p>
            </div>

            <input
              type="file"
              id="audio-file-upload"
              accept="audio/*"
              className="hidden"
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  setSelectedFile(e.target.files[0]);
                }
              }}
            />

            <div className="flex justify-center gap-3">
              <label
                htmlFor="audio-file-upload"
                className="px-4 py-2 rounded-xl bg-white border border-warm-200 hover:bg-warm-100 text-xs font-semibold text-stone-700 cursor-pointer shadow-warm-sm"
              >
                {selectedFile ? 'Change File' : 'Browse Audio File'}
              </label>

              {selectedFile && (
                <button
                  type="button"
                  onClick={stopAndFinish}
                  className="px-5 py-2 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm"
                >
                  Process Audio & Extract
                </button>
              )}
            </div>
          </div>
        )}

        {/* TAB CONTENT: PASTE TRANSCRIPT */}
        {activeTab === 'transcript_paste' && (
          <div className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
                Meeting Transcript (Speaker 1, Speaker 2 or dialogue format)
              </label>
              <textarea
                rows={8}
                value={pastedTranscript}
                onChange={(e) => setPastedTranscript(e.target.value)}
                placeholder="Speaker 1: I'll complete the report by Friday..."
                className="w-full px-4 py-3 rounded-2xl bg-warm-50 border border-warm-200 text-xs sm:text-sm text-stone-800 font-mono leading-relaxed focus:bg-white"
              />
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={handleProcessPastedTranscript}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs sm:text-sm font-semibold shadow-warm-sm active:scale-95 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>Extract Commitments From Transcript</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB CONTENT: EMAIL INGESTION */}
        {activeTab === 'email' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-600">
                Authorized Email Thread (Gmail / Outlook)
              </label>
              <button
                type="button"
                onClick={() => {
                  setEmailText(`From: priya.sharma@example.com
Subject: Revised Proposal Request
Hi Team,
Could you send the revised proposal to Priya by Friday?
Let's ensure the technical appendix is attached before sending.
Best regards,
Priya`);
                  setSessionTitle('Email Request: Revised Proposal (Slide 7)');
                  showToast('Loaded Slide 7 email preset! 📧', 'info');
                }}
                className="text-xs text-sage-700 font-semibold hover:underline flex items-center gap-1"
              >
                <span>Load Slide 7 Example</span>
              </button>
            </div>

            <textarea
              rows={8}
              value={emailText}
              onChange={(e) => setEmailText(e.target.value)}
              placeholder="Paste email conversation..."
              className="w-full px-4 py-3 rounded-2xl bg-warm-50 border border-warm-200 text-xs sm:text-sm text-stone-800 font-mono leading-relaxed focus:bg-white"
            />

            <div className="flex justify-end">
              <button
                type="button"
                onClick={handleProcessEmail}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs sm:text-sm font-semibold shadow-warm-sm active:scale-95 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>Ingest Email & Extract Commitments</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB CONTENT: DOCUMENT NOTES */}
        {activeTab === 'document' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-600">
                Document Comments & Meeting Notes
              </label>
              <button
                type="button"
                onClick={() => {
                  setDocText(`Document: Sprint QA Review & Audit Notes
Author: Kenisha (QA)
Please complete the task before the review.
We will finalize the staging deployment before Friday.`);
                  setSessionTitle('Document: Sprint QA Review (Slide 2)');
                  showToast('Loaded Slide 2 document preset! 📄', 'info');
                }}
                className="text-xs text-sage-700 font-semibold hover:underline flex items-center gap-1"
              >
                <span>Load Slide 2 Example</span>
              </button>
            </div>

            <textarea
              rows={8}
              value={docText}
              onChange={(e) => setDocText(e.target.value)}
              placeholder="Paste document excerpts, notes, or comments..."
              className="w-full px-4 py-3 rounded-2xl bg-warm-50 border border-warm-200 text-xs sm:text-sm text-stone-800 font-mono leading-relaxed focus:bg-white"
            />

            <div className="flex justify-end">
              <button
                type="button"
                onClick={handleProcessDocument}
                className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs sm:text-sm font-semibold shadow-warm-sm active:scale-95 transition-all"
              >
                <Sparkles className="w-4 h-4" />
                <span>Ingest Document & Extract Commitments</span>
              </button>
            </div>
          </div>
        )}

        {/* TAB CONTENT: AUDIO IMPORT */}
        {activeTab === 'audio_import' && (
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1">
                Upload Meeting Audio Recording
              </label>
              <p className="text-xs text-stone-500 mb-3">
                Supported formats: WAV, MP3, WebM, M4A, OGG. CommitMind will transcribe the speech, diarize speakers, and preserve timestamps.
              </p>
            </div>

            <div className="border-2 border-dashed border-warm-300 hover:border-sage-400 rounded-2xl p-8 text-center bg-warm-50/50 hover:bg-sage-50/20 transition-all">
              <input
                type="file"
                id="audio-upload-input"
                accept="audio/*,.wav,.mp3,.webm,.m4a,.ogg"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    setSelectedFile(e.target.files[0]);
                  }
                }}
                className="hidden"
              />
              <label
                htmlFor="audio-upload-input"
                className="cursor-pointer flex flex-col items-center gap-3"
              >
                <div className="w-12 h-12 rounded-2xl bg-sage-100 text-sage-600 flex items-center justify-center shadow-warm-sm">
                  <Upload className="w-6 h-6" />
                </div>
                <div>
                  <span className="text-sm font-semibold text-stone-800 hover:text-sage-700 underline">
                    {selectedFile ? selectedFile.name : 'Choose an audio file'}
                  </span>
                  <span className="text-xs text-stone-500 block mt-0.5">
                    {selectedFile
                      ? `${(selectedFile.size / (1024 * 1024)).toFixed(2)} MB · Click to change`
                      : 'or drag and drop here (max 30 MB)'}
                  </span>
                </div>
              </label>
            </div>

            <div className="flex items-center justify-between pt-2">
              <span className="text-xs text-stone-500">
                Transcriptions are processed server-side with Gemini Multimodal AI.
              </span>
              <button
                type="button"
                onClick={handleUploadAudio}
                disabled={!selectedFile || isTranscribing}
                className={`flex items-center gap-2 px-6 py-2.5 rounded-xl text-xs sm:text-sm font-semibold shadow-warm-sm active:scale-95 transition-all ${
                  !selectedFile || isTranscribing
                    ? 'bg-stone-300 text-stone-500 cursor-not-allowed'
                    : 'bg-sage-600 hover:bg-sage-700 text-white'
                }`}
              >
                {isTranscribing ? (
                  <>
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>Transcribing Audio...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" />
                    <span>Transcribe & Diarize Audio</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Handy Local Architecture & Privacy Note */}
      <div className="calm-card p-6 bg-gradient-to-r from-warm-100/70 via-sage-50/50 to-warm-100/70 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-start gap-3">
          <div className="p-2.5 rounded-xl bg-white shadow-warm-sm text-sage-600 shrink-0">
            <Volume2 className="w-5 h-5" />
          </div>
          <div className="text-xs text-stone-600 leading-relaxed">
            <strong className="text-stone-800 block text-sm font-serif">Handy Local Architecture Adapter</strong>
            Designed around the open-source Handy specification: speech processing defaults to local client speech recognition without unauthorized remote audio streaming.
          </div>
        </div>

        <a
          href="https://github.com/cjpais/Handy"
          target="_blank"
          rel="noopener noreferrer"
          className="text-xs text-sage-700 hover:underline flex items-center gap-1 shrink-0 font-semibold"
        >
          <span>Handy Spec</span>
          <ExternalLink className="w-3.5 h-3.5" />
        </a>
      </div>
    </div>
  );
};
