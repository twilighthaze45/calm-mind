import React, { useState } from 'react';
import { 
  Bell, 
  Clock, 
  CheckCircle2, 
  AlertTriangle, 
  Mail, 
  Monitor, 
  Database
} from 'lucide-react';
import { useCommitments } from '../../context/CommitmentsContext';
import { useMindfulness } from '../../context/MindfulnessContext';

export const NotificationSettingsPage: React.FC = () => {
  const { preferences, updatePreferences } = useCommitments();
  const { showToast } = useMindfulness();

  const [browserPermission, setBrowserPermission] = useState<NotificationPermission>(() => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      return Notification.permission;
    }
    return 'default';
  });

  const requestBrowserPermission = async () => {
    if (typeof window !== 'undefined' && 'Notification' in window) {
      const res = await Notification.requestPermission();
      setBrowserPermission(res);
      if (res === 'granted') {
        updatePreferences({ browser_notifications_enabled: true });
        showToast('Browser notification permission granted! 🔔', 'success');
        try {
          new Notification('CommitMind Meeting Commitments', {
            body: 'Reminders will alert you 24 hours prior to deadline.',
            icon: '/favicon.ico',
          });
        } catch {
          // ignore
        }
      } else {
        updatePreferences({ browser_notifications_enabled: false });
        showToast('Browser notifications were not enabled', 'info');
      }
    } else {
      showToast('Notifications are not supported in this browser environment', 'info');
    }
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-4xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <Bell className="w-4 h-4" />
            <span>Durable Notification Engine</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-800">
            24-Hour Reminder & Notification Settings
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Configure how and when deadline notifications are delivered reliably.
          </p>
        </div>
      </div>

      {/* 24-Hour Advance Notice Guarantee Card */}
      <div className="calm-card p-6 sm:p-8 space-y-5">
        <div className="flex items-start justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 rounded-2xl bg-sage-100 text-sage-700">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-lg text-stone-800">
                Default 24-Hour Advance Notice
              </h3>
              <p className="text-xs text-stone-600">
                Formula: <code className="font-mono text-sage-800 font-bold">reminder_at = deadline_at - 24 hours</code>
              </p>
            </div>
          </div>
          <span className="px-3 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
            Active
          </span>
        </div>

        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
          Every confirmed commitment with a valid deadline automatically generates an exact 24-hour advance alert. When deadlines are edited, the reminder is automatically rescheduled. When a commitment is completed or rejected, the pending reminder is immediately cancelled.
        </p>

        {/* Short-Lead Commitment Disclosure Banner */}
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-xs text-amber-900 space-y-1">
          <div className="flex items-center gap-2 font-bold text-amber-800">
            <AlertTriangle className="w-4 h-4 text-amber-600" />
            <span>Commitments Created Under 24 Hours Before Deadline</span>
          </div>
          <p>
            If a commitment is created or confirmed less than 24 hours before its deadline, the system schedules an <strong>immediate next-available reminder</strong> (1 minute from creation) rather than skipping the notification.
          </p>
        </div>
      </div>

      {/* Delivery Channels Configuration */}
      <div className="calm-card p-6 sm:p-8 space-y-6">
        <h3 className="font-serif font-bold text-lg text-stone-800">
          Delivery Channels
        </h3>

        <div className="space-y-4">
          {/* Channel 1: In-App Center */}
          <div className="p-4 rounded-2xl bg-warm-50 border border-warm-200/80 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Monitor className="w-5 h-5 text-sage-700" />
              <div>
                <h4 className="text-sm font-semibold text-stone-800">In-App Notification Center & Toasts</h4>
                <p className="text-xs text-stone-600">Immediate badge alerts and toast notifications on dashboard.</p>
              </div>
            </div>
            <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
              Always Enabled
            </span>
          </div>

          {/* Channel 2: Browser Push Notifications */}
          <div className="p-4 rounded-2xl bg-warm-50 border border-warm-200/80 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-sky-700" />
              <div>
                <h4 className="text-sm font-semibold text-stone-800">Browser Desktop Notifications</h4>
                <p className="text-xs text-stone-600">
                  Status: <strong>{browserPermission}</strong>. Note: Browser notifications alone do not guarantee delivery when the browser is fully closed.
                </p>
              </div>
            </div>

            <button
              onClick={requestBrowserPermission}
              className={`px-4 py-2 rounded-xl text-xs font-semibold shadow-sm transition-all ${
                browserPermission === 'granted'
                  ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                  : 'bg-sage-600 hover:bg-sage-700 text-white'
              }`}
            >
              {browserPermission === 'granted' ? 'Permission Granted' : 'Enable Browser Push'}
            </button>
          </div>

          {/* Channel 3: Email Alerts */}
          <div className="p-4 rounded-2xl bg-warm-50 border border-warm-200/80 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-rose-700" />
                <div>
                  <h4 className="text-sm font-semibold text-stone-800">Email Delivery</h4>
                  <p className="text-xs text-stone-600">
                    Sends reminder to your configured email via server-side Resend or SendGrid secrets.
                  </p>
                </div>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={preferences.email_enabled}
                  onChange={(e) => updatePreferences({ email_enabled: e.target.checked })}
                  className="sr-only peer"
                />
                <div className="w-11 h-6 bg-warm-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-warm-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-sage-600"></div>
              </label>
            </div>

            {preferences.email_enabled && (
              <div className="pt-2">
                <input
                  type="email"
                  value={preferences.notification_email || ''}
                  onChange={(e) => updatePreferences({ notification_email: e.target.value })}
                  placeholder="Enter notification email address..."
                  className="w-full px-3.5 py-2 rounded-xl bg-white border border-warm-200 text-xs text-stone-800"
                />
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Durable Backend Worker Status */}
      <div className="calm-card p-6 sm:p-8 space-y-4">
        <div className="flex items-center gap-3">
          <Database className="w-5 h-5 text-sage-600" />
          <h3 className="font-serif font-bold text-lg text-stone-800">
            Durable Server-Side Scheduling Architecture
          </h3>
        </div>

        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
          CommitMind does not rely solely on volatile in-browser React timers. In production with Supabase, reminders are stored in the <code className="px-1.5 py-0.5 rounded bg-warm-200 text-stone-800 font-mono">commitment_reminders</code> table and processed via the secure stored function:
        </p>

        <div className="p-3.5 rounded-xl bg-warm-900 text-stone-100 font-mono text-xs overflow-x-auto select-all leading-relaxed">
          -- Execute every minute in Supabase SQL editor:<br />
          SELECT cron.schedule('process-due-reminders', '* * * * *', 'SELECT public.process_due_reminders(50);');
        </div>

        <div className="flex flex-wrap items-center gap-4 text-xs text-stone-600 pt-2">
          <span className="flex items-center gap-1.5 text-emerald-700 font-semibold">
            <CheckCircle2 className="w-4 h-4" /> Idempotency Keys Active
          </span>
          <span className="flex items-center gap-1.5 text-emerald-700 font-semibold">
            <CheckCircle2 className="w-4 h-4" /> Row-Level Lock (FOR UPDATE SKIP LOCKED)
          </span>
          <span className="flex items-center gap-1.5 text-emerald-700 font-semibold">
            <CheckCircle2 className="w-4 h-4" /> Zero Private Transcript Logging
          </span>
        </div>
      </div>
    </div>
  );
};
