import React, { useState } from 'react';
import { 
  Sparkles, 
  Users, 
  Layers, 
  ShieldCheck, 
  ChevronRight, 
  ChevronLeft, 
  Mail, 
  FileText, 
  Mic, 
  CheckCircle2, 
  Clock, 
  AlertTriangle, 
  Calendar,
  Lock,
  ArrowRight,
  Target
} from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';

interface Slide {
  id: number;
  title: string;
  tagline: string;
  category: string;
  content: React.ReactNode;
}

export const PitchDeckPage: React.FC = () => {
  const { setCurrentPage } = useMindfulness();
  const [activeSlide, setActiveSlide] = useState(0);

  const slides: Slide[] = [
    {
      id: 1,
      category: 'COMMITMENT INTELLIGENCE · HACKATHON MVP',
      title: 'CommitMind: The AI That Never Lets Important Commitments Slip',
      tagline: 'Turning scattered promises into clear, actionable responsibilities. Every promise deserves a follow-through.',
      content: (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl bg-warm-900 text-white shadow-xl border border-warm-800 space-y-4">
            <div className="flex items-center gap-2 text-sage-400 text-xs font-bold tracking-widest uppercase">
              <Sparkles className="w-4 h-4" />
              <span>Project Identity & Team</span>
            </div>
            <h3 className="font-serif text-3xl font-bold leading-tight">
              CommitMind
            </h3>
            <p className="text-stone-300 text-sm leading-relaxed">
              In fast-paced modern workflows, promises happen everywhere: in conversations, team meetings, email threads, and documents. CommitMind captures authorized source material, detects genuine commitments, and routes them through a human confirmation checkpoint into a smart calendar with durable 24-hour advance reminders.
            </p>
            <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs">
              <div>
                <span className="text-stone-400">Team: </span>
                <span className="font-bold text-white">KERNEL</span>
              </div>
              <div>
                <span className="text-stone-400">Members: </span>
                <span className="font-semibold text-sage-300">Adhyayan Chanchal, Shubham Agarwal, Kenisha, Shaurya</span>
              </div>
              <div>
                <span className="text-stone-400">Institution: </span>
                <span className="font-medium text-stone-200">Lloyd Institute of Engineering and Technology</span>
              </div>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 2,
      category: 'THE PROBLEM',
      title: 'Important Commitments Are Buried Everywhere',
      tagline: 'Unclear ownership, scattered information, and forgotten follow-ups create delays and missed expectations.',
      content: (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-5 rounded-2xl bg-white border border-warm-200 shadow-warm-sm space-y-3">
            <div className="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <Mail className="w-5 h-5" />
            </div>
            <p className="font-serif italic text-sm text-stone-800">
              "I'll send the report by Friday."
            </p>
            <span className="text-[11px] font-semibold text-stone-600 uppercase tracking-wide block">
              Lost in email thread
            </span>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-warm-200 shadow-warm-sm space-y-3">
            <div className="w-9 h-9 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <Users className="w-5 h-5" />
            </div>
            <p className="font-serif italic text-sm text-stone-800">
              "Let's follow up with the client next week."
            </p>
            <span className="text-[11px] font-semibold text-stone-600 uppercase tracking-wide block">
              Fades after the meeting
            </span>
          </div>
          <div className="p-5 rounded-2xl bg-white border border-warm-200 shadow-warm-sm space-y-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <FileText className="w-5 h-5" />
            </div>
            <p className="font-serif italic text-sm text-stone-800">
              "Please complete the task before the review."
            </p>
            <span className="text-[11px] font-semibold text-stone-600 uppercase tracking-wide block">
              Buried in document comments
            </span>
          </div>
        </div>
      )
    },
    {
      id: 3,
      category: 'THE GAP',
      title: 'Reminders Start Too Late',
      tagline: 'The commitment often begins before a task ever exists.',
      content: (
        <div className="space-y-4">
          <div className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-warm-200 shadow-warm-sm">
            <div className="w-8 h-8 rounded-full bg-sage-100 text-sage-800 font-bold flex items-center justify-center text-xs flex-shrink-0">
              01
            </div>
            <div>
              <h4 className="font-bold text-sm text-stone-800">Manual task creation</h4>
              <p className="text-xs text-stone-600 mt-1">
                Traditional reminders and task managers depend on someone noticing the promise, opening an app, and manually entering it.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-warm-200 shadow-warm-sm">
            <div className="w-8 h-8 rounded-full bg-sage-100 text-sage-800 font-bold flex items-center justify-center text-xs flex-shrink-0">
              02
            </div>
            <div>
              <h4 className="font-bold text-sm text-stone-800">Memory becomes the system</h4>
              <p className="text-xs text-stone-600 mt-1">
                People must remember what was promised, where it appeared, who said it, and by when.
              </p>
            </div>
          </div>
          <div className="flex items-start gap-4 p-4 rounded-2xl bg-white border border-warm-200 shadow-warm-sm">
            <div className="w-8 h-8 rounded-full bg-sage-100 text-sage-800 font-bold flex items-center justify-center text-xs flex-shrink-0">
              03
            </div>
            <div>
              <h4 className="font-bold text-sm text-stone-800">Automation still misses the origin</h4>
              <p className="text-xs text-stone-600 mt-1">
                Existing tools may automate reminders on existing tasks, but the commitment originates earlier—inside a live conversation or document.
              </p>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 4,
      category: 'THE PRODUCT',
      title: 'CommitMind Adds a Commitment Intelligence Layer',
      tagline: 'It turns authorized source material into reviewable, prioritized responsibilities.',
      content: (
        <div className="grid grid-cols-1 sm:grid-cols-5 gap-3 text-center">
          {[
            { step: '01', name: 'Ingest', desc: 'Authorized speech, emails, documents, and transcripts.' },
            { step: '02', name: 'Identify', desc: 'NLP & LLM distinguish genuine promises from hypotheticals.' },
            { step: '03', name: 'Extract', desc: 'Owner, action, deadline, source excerpt, confidence.' },
            { step: '04', name: 'Confirm', desc: 'Human-in-the-loop review verifies ambiguous items.' },
            { step: '05', name: 'Follow through', desc: 'Prioritized calendar schedule & durable 24h reminders.' },
          ].map((item) => (
            <div key={item.step} className="p-4 rounded-2xl bg-white border border-warm-200 shadow-warm-sm space-y-2">
              <span className="text-xs font-bold text-sage-600">{item.step}</span>
              <h4 className="font-bold text-sm text-stone-800">{item.name}</h4>
              <p className="text-[11px] text-stone-600 leading-snug">{item.desc}</p>
            </div>
          ))}
        </div>
      )
    },
    {
      id: 5,
      category: 'SYSTEM FLOW · PROPOSED',
      title: 'From Scattered Text to the Next Best Action',
      tagline: 'Every commitment keeps a path back to the source, with a human checkpoint before it becomes actionable.',
      content: (
        <div className="space-y-4">
          <div className="p-5 rounded-2xl bg-warm-900 text-white space-y-3">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-2 text-xs font-semibold">
              <div className="px-3 py-1.5 rounded-lg bg-white/10 w-full sm:w-auto text-center">
                1. Authorized Data
              </div>
              <ArrowRight className="w-4 h-4 text-sage-400 rotate-90 sm:rotate-0" />
              <div className="px-3 py-1.5 rounded-lg bg-white/10 w-full sm:w-auto text-center">
                2. Text Extraction
              </div>
              <ArrowRight className="w-4 h-4 text-sage-400 rotate-90 sm:rotate-0" />
              <div className="px-3 py-1.5 rounded-lg bg-white/10 w-full sm:w-auto text-center">
                3. NLP / LLM Detection
              </div>
              <ArrowRight className="w-4 h-4 text-sage-400 rotate-90 sm:rotate-0" />
              <div className="px-3 py-1.5 rounded-lg bg-sage-600 text-white font-bold w-full sm:w-auto text-center">
                4. Human Checkpoint
              </div>
            </div>
          </div>
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div className="text-xs">
              <span className="font-bold">Human confirmation checkpoint: </span>
              Uncertain owners or deadlines are flagged for review before action is created or reminders scheduled.
            </div>
          </div>
        </div>
      )
    },
    {
      id: 6,
      category: 'PROPOSED CAPABILITIES',
      title: 'Everything Needed to Keep a Promise Moving',
      tagline: 'Detect, extract, prioritize, remind, verify, advance, coordinate.',
      content: (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 rounded-xl bg-white border border-warm-200 space-y-1">
            <div className="font-bold text-stone-800 flex items-center gap-1.5"><Mic className="w-4 h-4 text-sage-600" /> Detect</div>
            <p className="text-stone-600 text-[11px]">Automatic commitment intent detection.</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-warm-200 space-y-1">
            <div className="font-bold text-stone-800 flex items-center gap-1.5"><Calendar className="w-4 h-4 text-sage-600" /> Extract</div>
            <p className="text-stone-600 text-[11px]">Deadline & owner resolution.</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-warm-200 space-y-1">
            <div className="font-bold text-stone-800 flex items-center gap-1.5"><Layers className="w-4 h-4 text-sage-600" /> Prioritize</div>
            <p className="text-stone-600 text-[11px]">Urgency-ranked action dashboard.</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-warm-200 space-y-1">
            <div className="font-bold text-stone-800 flex items-center gap-1.5"><Clock className="w-4 h-4 text-sage-600" /> Remind</div>
            <p className="text-stone-600 text-[11px]">Durable 24-hour advance notifications.</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-warm-200 space-y-1">
            <div className="font-bold text-stone-800 flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-sage-600" /> Verify</div>
            <p className="text-stone-600 text-[11px]">Source-linked transcript evidence.</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-warm-200 space-y-1">
            <div className="font-bold text-stone-800 flex items-center gap-1.5"><CheckCircle2 className="w-4 h-4 text-sage-600" /> Advance</div>
            <p className="text-stone-600 text-[11px]">Status tracking & follow-up prompts.</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-warm-200 space-y-1">
            <div className="font-bold text-stone-800 flex items-center gap-1.5"><Users className="w-4 h-4 text-sage-600" /> Coordinate</div>
            <p className="text-stone-600 text-[11px]">Team accountability with RLS.</p>
          </div>
          <div className="p-3.5 rounded-xl bg-white border border-warm-200 space-y-1">
            <div className="font-bold text-stone-800 flex items-center gap-1.5"><Lock className="w-4 h-4 text-sage-600" /> Privacy</div>
            <p className="text-stone-600 text-[11px]">Data minimization & wipe controls.</p>
          </div>
        </div>
      )
    },
    {
      id: 7,
      category: 'ILLUSTRATIVE SCENARIO',
      title: 'One Email Becomes a Clear Next Step',
      tagline: 'The value is not another inbox flag. It is a commitment a person can review, verify, and move forward.',
      content: (
        <div className="p-5 rounded-3xl bg-white border border-warm-200 shadow-warm-md space-y-4">
          <div className="flex items-center justify-between">
            <span className="px-3 py-1 rounded-full bg-amber-100 text-amber-800 text-[11px] font-bold uppercase tracking-wider">
              Pending · Human Checkpoint
            </span>
            <span className="text-xs text-stone-600 font-medium">Source: Original Email</span>
          </div>
          <div>
            <h4 className="font-serif text-lg font-bold text-stone-800">
              Send revised proposal
            </h4>
            <p className="text-xs font-mono bg-warm-50 p-2.5 rounded-xl border border-warm-200 text-stone-700 mt-2">
              Email Excerpt: "Could you send the revised proposal to Priya by Friday?"
            </p>
          </div>
          <div className="grid grid-cols-2 gap-4 text-xs pt-2 border-t border-warm-200">
            <div>
              <span className="text-stone-600 uppercase font-semibold text-[10px] block">Owner</span>
              <span className="font-bold text-stone-800">Recipient · subject to confirmation</span>
            </div>
            <div>
              <span className="text-stone-600 uppercase font-semibold text-[10px] block">Deadline</span>
              <span className="font-bold text-stone-800">Friday · exact date confirmed</span>
            </div>
          </div>
          <div className="p-3 rounded-xl bg-sage-50 text-sage-900 text-xs font-medium flex items-center gap-2">
            <Clock className="w-4 h-4 text-sage-600 flex-shrink-0" />
            <span>Reminder timeline: Confirm owner → Review proposal → Send before deadline</span>
          </div>
        </div>
      )
    },
    {
      id: 8,
      category: 'PROPOSED MVP STACK',
      title: 'Built for a Focused, Robust Demo',
      tagline: 'Modern, reliable, and grounded in production-ready architecture.',
      content: (
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-xs">
          <div className="p-3.5 rounded-2xl bg-white border border-warm-200">
            <span className="text-[10px] uppercase font-bold text-stone-600 block mb-1">Frontend</span>
            <p className="font-bold text-stone-800">React + TypeScript</p>
            <p className="text-[11px] text-stone-600 mt-1">Vite + Tailwind CSS</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-white border border-warm-200">
            <span className="text-[10px] uppercase font-bold text-stone-600 block mb-1">AI & Extraction</span>
            <p className="font-bold text-stone-800">LLM + Structured Output</p>
            <p className="text-[11px] text-stone-600 mt-1">Gemini / Speech API</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-white border border-warm-200">
            <span className="text-[10px] uppercase font-bold text-stone-600 block mb-1">Database & RLS</span>
            <p className="font-bold text-stone-800">PostgreSQL (Supabase)</p>
            <p className="text-[11px] text-stone-600 mt-1">Strict RLS & Triggers</p>
          </div>
          <div className="p-3.5 rounded-2xl bg-white border border-warm-200">
            <span className="text-[10px] uppercase font-bold text-stone-600 block mb-1">Notifications</span>
            <p className="font-bold text-stone-800">Durable 24h Reminders</p>
            <p className="text-[11px] text-stone-600 mt-1">pg_cron + Browser Push</p>
          </div>
        </div>
      )
    },
    {
      id: 9,
      category: 'DIFFERENTIATION',
      title: 'Tasks Record Work. CommitMind Understands the Promise Behind It.',
      tagline: 'Comparison of traditional tools vs. CommitMind capabilities.',
      content: (
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs bg-white rounded-2xl border border-warm-200 overflow-hidden">
            <thead className="bg-warm-100 text-stone-800 font-bold border-b border-warm-200">
              <tr>
                <th className="p-3">Capability</th>
                <th className="p-3">Manual Task Managers</th>
                <th className="p-3">Basic Reminders</th>
                <th className="p-3 bg-sage-100 text-sage-900">CommitMind</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-warm-100 text-stone-700">
              <tr>
                <td className="p-3 font-semibold">Origin</td>
                <td className="p-3 text-stone-600">Manually entered</td>
                <td className="p-3 text-stone-600">Time-based prompt</td>
                <td className="p-3 font-bold text-sage-800 bg-sage-50/50">Surfaced from source text</td>
              </tr>
              <tr>
                <td className="p-3 font-semibold">Traceability</td>
                <td className="p-3 text-stone-600">Separate from source</td>
                <td className="p-3 text-stone-600">Reminder context</td>
                <td className="p-3 font-bold text-sage-800 bg-sage-50/50">Source-linked evidence</td>
              </tr>
              <tr>
                <td className="p-3 font-semibold">Ownership</td>
                <td className="p-3 text-stone-600">Entered by a person</td>
                <td className="p-3 text-stone-600">Often assumed</td>
                <td className="p-3 font-bold text-sage-800 bg-sage-50/50">Extracted, flagged & confirmed</td>
              </tr>
              <tr>
                <td className="p-3 font-semibold">Priority</td>
                <td className="p-3 text-stone-600">User-managed</td>
                <td className="p-3 text-stone-600">Time-triggered</td>
                <td className="p-3 font-bold text-sage-800 bg-sage-50/50">Ranked by deadline & context</td>
              </tr>
            </tbody>
          </table>
        </div>
      )
    },
    {
      id: 10,
      category: 'TRUST BY DESIGN',
      title: 'Trust Is Part of the Product, Not a Later Feature.',
      tagline: 'Make every extracted commitment reviewable before it becomes someone’s responsibility.',
      content: (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
          <div className="p-4 rounded-2xl bg-white border border-warm-200 space-y-2">
            <h4 className="font-bold text-stone-800 flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-sage-600" />
              Explicit Authorization
            </h4>
            <p className="text-stone-600">
              Least-privilege access and mandatory consent confirmation before microphone recording.
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-white border border-warm-200 space-y-2">
            <h4 className="font-bold text-stone-800 flex items-center gap-2">
              <Lock className="w-4 h-4 text-sage-600" />
              Data Minimization
            </h4>
            <p className="text-stone-600">
              Configurable retention controls with instant "Stop & Delete" audio purge.
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-white border border-warm-200 space-y-2">
            <h4 className="font-bold text-stone-800 flex items-center gap-2">
              <Users className="w-4 h-4 text-sage-600" />
              Human-in-the-Loop
            </h4>
            <p className="text-stone-600">
              Users review and correct AI-extracted commitments before calendar placement.
            </p>
          </div>
          <div className="p-4 rounded-2xl bg-white border border-warm-200 space-y-2">
            <h4 className="font-bold text-stone-800 flex items-center gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              Uncertainty Flagging
            </h4>
            <p className="text-stone-600">
              Uncertain owners and deadlines are flagged, never silently assumed.
            </p>
          </div>
        </div>
      )
    }
  ];

  const current = slides[activeSlide];

  return (
    <div className="space-y-6 animate-fade-in max-w-5xl mx-auto pb-12">
      {/* Top Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Hackathon Presentation & Project Architecture</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-800">
            CommitMind Pitch Deck & Vision
          </h2>
          <p className="text-sm text-stone-600 mt-1">
            Team KERNEL · Lloyd Institute of Engineering and Technology
          </p>
        </div>

        <button
          onClick={() => setCurrentPage('commitments_dashboard')}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm transition-all self-start sm:self-auto"
        >
          <Target className="w-4 h-4" />
          <span>Go to CommitMind Suite</span>
        </button>
      </div>

      {/* Main Slide Card */}
      <div className="p-6 sm:p-8 rounded-3xl bg-warm-100/60 border border-warm-200/80 shadow-warm-md space-y-6">
        {/* Slide Header */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-stone-600 font-bold uppercase tracking-wider">
            <span>{current.category}</span>
            <span>Slide {current.id} of {slides.length}</span>
          </div>
          <h3 className="font-serif text-2xl sm:text-3xl font-bold text-stone-800">
            {current.title}
          </h3>
          <p className="text-sm text-stone-600">
            {current.tagline}
          </p>
        </div>

        {/* Slide Content */}
        <div className="pt-4 border-t border-warm-200/80">
          {current.content}
        </div>

        {/* Slide Controls & Carousel Pager */}
        <div className="pt-4 border-t border-warm-200/80 flex items-center justify-between">
          <button
            onClick={() => setActiveSlide((prev) => Math.max(0, prev - 1))}
            disabled={activeSlide === 0}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeSlide === 0 
                ? 'opacity-40 cursor-not-allowed bg-stone-100 text-stone-600'
                : 'bg-white text-stone-800 hover:bg-stone-50 border border-warm-200 shadow-sm'
            }`}
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous</span>
          </button>

          {/* Dots Indicator */}
          <div className="flex items-center gap-1.5">
            {slides.map((s, idx) => (
              <button
                key={s.id}
                onClick={() => setActiveSlide(idx)}
                className={`w-2 h-2 rounded-full transition-all ${
                  activeSlide === idx ? 'w-6 bg-sage-600' : 'bg-warm-300 hover:bg-warm-400'
                }`}
                title={`Jump to slide ${s.id}`}
              />
            ))}
          </div>

          <button
            onClick={() => setActiveSlide((prev) => Math.min(slides.length - 1, prev + 1))}
            disabled={activeSlide === slides.length - 1}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold transition-all ${
              activeSlide === slides.length - 1
                ? 'opacity-40 cursor-not-allowed bg-stone-100 text-stone-600'
                : 'bg-white text-stone-800 hover:bg-stone-50 border border-warm-200 shadow-sm'
            }`}
          >
            <span>Next</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
