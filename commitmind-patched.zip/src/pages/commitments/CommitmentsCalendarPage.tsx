import React, { useState } from 'react';
import { 
  Calendar as CalendarIcon, 
  ChevronLeft, 
  ChevronRight, 
  Clock, 
  Download, 
  Filter, 
  Quote, 
  CheckCircle2, 
  X, 
  Share2,
  UserCheck,
  Users,
  Video
} from 'lucide-react';
import { useCommitments } from '../../context/CommitmentsContext';
import { Commitment, CommitmentPriority, CommitmentScope, isMyCommitment } from '../../types';

type CalendarView = 'month' | 'week' | 'day' | 'list';

export const CommitmentsCalendarPage: React.FC = () => {
  const { 
    commitments, 
    downloadICS, 
    toggleCompleteCommitment, 
    updateCommitmentDeadline 
  } = useCommitments();

  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [viewMode, setViewMode] = useState<CalendarView>('month');
  const [selectedCommitment, setSelectedCommitment] = useState<Commitment | null>(null);

  // Filters & Scope
  const [scopeFilter, setScopeFilter] = useState<CommitmentScope>('all');
  const [filterOwner, setFilterOwner] = useState<string>('all');
  const [filterPriority, setFilterPriority] = useState<string>('all');
  const [filterStatus, setFilterStatus] = useState<string>('all');

  // Reschedule state
  const [isRescheduling, setIsRescheduling] = useState(false);
  const [newDeadlineInput, setNewDeadlineInput] = useState('');

  // Google Calendar Sync State
  const [showSyncModal, setShowSyncModal] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<any>(null);

  // Extract unique owners
  const allOwners = Array.from(new Set(commitments.map((c) => c.owner_name)));

  // Filtered commitments (only confirmed appear on active calendar)
  const activeConfirmedCommitments = commitments.filter((c) => {
    if (c.extraction_status !== 'confirmed') return false;

    // Scope filter (My commitments vs Colleagues' commitments)
    const isMine = isMyCommitment(c.owner_name);
    if (scopeFilter === 'mine' && !isMine) return false;
    if (scopeFilter === 'colleagues' && isMine) return false;

    if (filterOwner !== 'all' && c.owner_name !== filterOwner) return false;
    if (filterPriority !== 'all' && c.priority !== filterPriority) return false;
    if (filterStatus === 'pending' && c.completion_status !== 'pending') return false;
    if (filterStatus === 'completed' && c.completion_status !== 'completed') return false;
    if (filterStatus === 'overdue') {
      const isPast = c.deadline_at && new Date(c.deadline_at).getTime() < Date.now();
      if (!isPast || c.completion_status === 'completed') return false;
    }
    return true;
  });

  // Calculate scope totals for pills
  const totalConfirmed = commitments.filter((c) => c.extraction_status === 'confirmed').length;
  const myConfirmed = commitments.filter((c) => c.extraction_status === 'confirmed' && isMyCommitment(c.owner_name)).length;
  const colleaguesConfirmed = commitments.filter((c) => c.extraction_status === 'confirmed' && !isMyCommitment(c.owner_name)).length;

  // Month navigation helpers
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const handlePrev = () => {
    if (viewMode === 'month') setCurrentDate(new Date(year, month - 1, 1));
    else if (viewMode === 'week') setCurrentDate(new Date(currentDate.getTime() - 7 * 86400000));
    else setCurrentDate(new Date(currentDate.getTime() - 86400000));
  };

  const handleNext = () => {
    if (viewMode === 'month') setCurrentDate(new Date(year, month + 1, 1));
    else if (viewMode === 'week') setCurrentDate(new Date(currentDate.getTime() + 7 * 86400000));
    else setCurrentDate(new Date(currentDate.getTime() + 86400000));
  };

  const handleToday = () => {
    setCurrentDate(new Date());
  };

  // Build calendar month grid
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayOfWeek = new Date(year, month, 1).getDay(); // 0 is Sun

  const monthName = currentDate.toLocaleDateString([], { month: 'long', year: 'numeric' });

  const getPriorityColor = (p: CommitmentPriority) => {
    switch (p) {
      case 'urgent': return 'bg-rose-500 text-white';
      case 'high': return 'bg-amber-500 text-white';
      case 'medium': return 'bg-sage-600 text-white';
      default: return 'bg-stone-500 text-white';
    }
  };

  const handleSaveReschedule = () => {
    if (selectedCommitment && newDeadlineInput) {
      updateCommitmentDeadline(selectedCommitment.id, new Date(newDeadlineInput).toISOString());
      setSelectedCommitment({
        ...selectedCommitment,
        deadline_at: new Date(newDeadlineInput).toISOString(),
      });
      setIsRescheduling(false);
    }
  };

  return (
    <div className="space-y-6 animate-fade-in max-w-7xl mx-auto pb-12">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-700 text-xs font-semibold uppercase tracking-wider mb-1">
            <CalendarIcon className="w-4 h-4" />
            <span>Online Meeting Deadline Scheduler</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-900">
            Commitments Calendar
          </h2>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Track promises made by you and your colleagues during online meetings (Zoom, Google Meet, Teams).
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={() => setShowSyncModal(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-sage-700 hover:bg-sage-800 text-xs font-semibold text-white shadow-warm-sm transition-all"
            title="Google Calendar Integration & Sync Status"
          >
            <Share2 className="w-4 h-4" />
            <span>Google Calendar Sync</span>
          </button>

          <button
            onClick={downloadICS}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-white border border-warm-200 hover:bg-warm-100 text-xs font-semibold text-stone-700 shadow-warm-sm transition-all"
            title="Download iCalendar .ics file"
          >
            <Download className="w-4 h-4" />
            <span>Export .ics</span>
          </button>
        </div>
      </div>

      {/* Scope Filter Tabs: All vs My Commitments vs Colleagues' Commitments */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <button
          onClick={() => setScopeFilter('all')}
          className={`p-3.5 rounded-2xl border text-left transition-all ${
            scopeFilter === 'all'
              ? 'bg-white border-stone-800 shadow-warm-md ring-1 ring-stone-800'
              : 'bg-warm-50/60 border-warm-200 hover:bg-white text-stone-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-stone-600">
              All Meeting Commitments
            </span>
            <span className="text-xs font-bold bg-stone-100 text-stone-800 px-2 py-0.5 rounded-full">
              {totalConfirmed}
            </span>
          </div>
          <p className="text-sm font-bold text-stone-900 mt-1">Full Team Calendar</p>
          <span className="text-[11px] text-stone-500">All deliverables from online calls</span>
        </button>

        <button
          onClick={() => setScopeFilter('mine')}
          className={`p-3.5 rounded-2xl border text-left transition-all ${
            scopeFilter === 'mine'
              ? 'bg-emerald-50/90 border-emerald-600 shadow-warm-md ring-1 ring-emerald-600'
              : 'bg-warm-50/60 border-warm-200 hover:bg-white text-stone-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
              My Commitments
            </span>
            <span className="text-xs font-bold bg-emerald-100 text-emerald-900 px-2 py-0.5 rounded-full">
              {myConfirmed}
            </span>
          </div>
          <p className="text-sm font-bold text-stone-900 mt-1">Promises I Made</p>
          <span className="text-[11px] text-emerald-700">Deliverables I owe to the team</span>
        </button>

        <button
          onClick={() => setScopeFilter('colleagues')}
          className={`p-3.5 rounded-2xl border text-left transition-all ${
            scopeFilter === 'colleagues'
              ? 'bg-sky-50/90 border-sky-600 shadow-warm-md ring-1 ring-sky-600'
              : 'bg-warm-50/60 border-warm-200 hover:bg-white text-stone-700'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-sky-800 flex items-center gap-1.5">
              <Users className="w-3.5 h-3.5 text-sky-600" />
              Colleagues' Commitments
            </span>
            <span className="text-xs font-bold bg-sky-100 text-sky-900 px-2 py-0.5 rounded-full">
              {colleaguesConfirmed}
            </span>
          </div>
          <p className="text-sm font-bold text-stone-900 mt-1">Promises Made to Me</p>
          <span className="text-[11px] text-sky-700">Deliverables colleagues owe to me</span>
        </button>
      </div>

      {/* Control Bar: Navigation, Views, and Filters */}
      <div className="calm-card p-4 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        {/* Navigation & Month Title */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1">
            <button
              onClick={handlePrev}
              className="p-2 rounded-xl text-stone-700 hover:bg-warm-100 transition-colors"
              aria-label="Previous"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleToday}
              className="px-3 py-1.5 rounded-xl text-xs font-bold bg-warm-100 hover:bg-warm-200 text-stone-700 transition-colors"
            >
              Today
            </button>
            <button
              onClick={handleNext}
              className="p-2 rounded-xl text-stone-700 hover:bg-warm-100 transition-colors"
              aria-label="Next"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          <h3 className="font-serif font-bold text-base sm:text-lg text-stone-850 min-w-[180px]">
            {monthName}
          </h3>
        </div>

        {/* View Mode Switcher */}
        <div className="flex items-center gap-1 p-1 bg-warm-100 rounded-xl text-xs font-semibold self-start lg:self-auto">
          {(['month', 'week', 'day', 'list'] as CalendarView[]).map((mode) => (
            <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className={`px-3 py-1.5 rounded-lg capitalize transition-all ${
                viewMode === mode
                  ? 'bg-white text-stone-800 shadow-warm-sm font-bold'
                  : 'text-stone-600 hover:text-stone-800'
              }`}
            >
              {mode}
            </button>
          ))}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-2 text-xs">
          <div className="flex items-center gap-1 font-semibold text-stone-600">
            <Filter className="w-3.5 h-3.5" />
          </div>

          <select
            value={filterOwner}
            onChange={(e) => setFilterOwner(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-warm-50 border border-warm-200 text-stone-700"
          >
            <option value="all">All Meeting Speakers</option>
            {allOwners.map((owner) => (
              <option key={owner} value={owner}>
                {isMyCommitment(owner) ? `👤 ${owner} (You)` : `👥 ${owner}`}
              </option>
            ))}
          </select>

          <select
            value={filterPriority}
            onChange={(e) => setFilterPriority(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-warm-50 border border-warm-200 text-stone-700 capitalize"
          >
            <option value="all">All Priorities</option>
            <option value="urgent">Urgent</option>
            <option value="high">High</option>
            <option value="medium">Medium</option>
            <option value="low">Low</option>
          </select>

          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="px-2.5 py-1.5 rounded-lg bg-warm-50 border border-warm-200 text-stone-700"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="completed">Completed</option>
            <option value="overdue">Overdue</option>
          </select>
        </div>
      </div>

      {/* CALENDAR BODY */}
      {viewMode === 'month' && (
        <div className="calm-card p-4 sm:p-6 overflow-x-auto shadow-warm-md">
          <div className="min-w-[700px]">
            {/* Days of Week Header */}
            <div className="grid grid-cols-7 gap-2 mb-2 text-center text-xs font-bold uppercase tracking-wider text-stone-600">
              <span>Sun</span>
              <span>Mon</span>
              <span>Tue</span>
              <span>Wed</span>
              <span>Thu</span>
              <span>Fri</span>
              <span>Sat</span>
            </div>

            {/* Grid of Days */}
            <div className="grid grid-cols-7 gap-2">
              {/* Blank leading days */}
              {Array.from({ length: firstDayOfWeek }).map((_, idx) => (
                <div key={`blank-${idx}`} className="h-32 rounded-2xl bg-warm-50/40 border border-transparent" />
              ))}

              {/* Month Day Cells */}
              {Array.from({ length: daysInMonth }).map((_, idx) => {
                const dayNum = idx + 1;
                const cellDate = new Date(year, month, dayNum);
                const isToday =
                  cellDate.toDateString() === new Date().toDateString();

                // Find commitments on this day
                const dayCommitments = activeConfirmedCommitments.filter((c) => {
                  if (!c.deadline_at) return false;
                  const d = new Date(c.deadline_at);
                  return (
                    d.getFullYear() === year &&
                    d.getMonth() === month &&
                    d.getDate() === dayNum
                  );
                });

                return (
                  <div
                    key={dayNum}
                    className={`h-32 p-2 rounded-2xl border transition-all flex flex-col justify-between overflow-hidden ${
                      isToday
                        ? 'bg-sage-50/70 border-sage-400 ring-1 ring-sage-400/40'
                        : 'bg-white border-warm-200/80 hover:border-sage-300'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span
                        className={`text-xs font-bold w-6 h-6 rounded-full flex items-center justify-center ${
                          isToday
                            ? 'bg-sage-700 text-white'
                            : 'text-stone-750'
                        }`}
                      >
                        {dayNum}
                      </span>
                      {dayCommitments.length > 0 && (
                        <span className="text-[10px] text-stone-600 font-bold bg-warm-100 px-1.5 py-0.5 rounded-md">
                          {dayCommitments.length}
                        </span>
                      )}
                    </div>

                    {/* Commitments pills with distinct Mine vs Colleague styling */}
                    <div className="space-y-1 overflow-y-auto max-h-22 pr-0.5">
                      {dayCommitments.map((c) => {
                        const isPast = new Date(c.deadline_at!).getTime() < Date.now();
                        const isDone = c.completion_status === 'completed';
                        const isMine = isMyCommitment(c.owner_name);

                        return (
                          <div
                            key={c.id}
                            onClick={() => setSelectedCommitment(c)}
                            className={`px-1.5 py-1 rounded-lg text-[10px] font-semibold truncate cursor-pointer transition-transform hover:scale-102 flex items-center justify-between gap-1 shadow-xs border ${
                              isDone
                                ? 'bg-stone-100 text-stone-500 border-stone-200 line-through'
                                : isPast
                                ? 'bg-rose-100 text-rose-800 border-rose-300'
                                : isMine
                                ? 'bg-emerald-50 text-emerald-900 border-emerald-300 hover:bg-emerald-100'
                                : 'bg-sky-50 text-sky-900 border-sky-300 hover:bg-sky-100'
                            }`}
                            title={`${c.title} — ${isMine ? 'You promised' : `${c.owner_name} promised you`}`}
                          >
                            <span className="truncate flex items-center gap-1">
                              <span>{isMine ? '👤' : '👥'}</span>
                              <span className="truncate">{c.title}</span>
                            </span>
                            <span className="text-[9px] opacity-80 shrink-0 font-mono">
                              {new Date(c.deadline_at!).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* LIST VIEW / UPCOMING */}
      {(viewMode === 'list' || viewMode === 'week' || viewMode === 'day') && (
        <div className="calm-card p-6 space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-warm-200">
            <div>
              <h4 className="font-serif font-bold text-base text-stone-850">
                Scheduled Meeting Commitments ({activeConfirmedCommitments.length})
              </h4>
              <p className="text-xs text-stone-600">
                {scopeFilter === 'mine' 
                  ? 'Showing promises you committed to deliver' 
                  : scopeFilter === 'colleagues'
                  ? 'Showing promises your colleagues committed to deliver to you'
                  : 'Showing all team commitments made in online meetings'}
              </p>
            </div>
            <span className="text-xs text-stone-500">Chronological order</span>
          </div>

          <div className="space-y-3">
            {activeConfirmedCommitments.length === 0 ? (
              <div className="text-center py-10 bg-warm-50/50 rounded-2xl border border-dashed border-warm-200">
                <p className="text-sm font-semibold text-stone-700">No commitments match the active filter</p>
                <p className="text-xs text-stone-500 mt-1">Switch filter pills above or capture a new online meeting.</p>
              </div>
            ) : (
              activeConfirmedCommitments.map((c) => {
                const isPast = c.deadline_at && new Date(c.deadline_at).getTime() < Date.now();
                const isMine = isMyCommitment(c.owner_name);

                return (
                  <div
                    key={c.id}
                    onClick={() => setSelectedCommitment(c)}
                    className="p-4 rounded-2xl bg-warm-50/70 hover:bg-white border border-warm-200/80 cursor-pointer transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-warm-sm"
                  >
                    <div className="flex items-start gap-3">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          toggleCompleteCommitment(c.id);
                        }}
                        className="mt-0.5 p-1 rounded-lg text-stone-500 hover:text-emerald-600"
                      >
                        <CheckCircle2 className={`w-5 h-5 ${c.completion_status === 'completed' ? 'text-emerald-600' : ''}`} />
                      </button>
                      <div>
                        <div className="flex items-center gap-2">
                          <h5 className={`font-serif font-bold text-sm text-stone-850 ${c.completion_status === 'completed' ? 'line-through text-stone-500' : ''}`}>
                            {c.title}
                          </h5>

                          {/* Direction Badge */}
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                            isMine
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : 'bg-sky-100 text-sky-800 border border-sky-200'
                          }`}>
                            {isMine ? <UserCheck className="w-3 h-3" /> : <Users className="w-3 h-3" />}
                            {isMine ? 'My Promise' : `${c.owner_name}'s Promise`}
                          </span>

                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${getPriorityColor(c.priority)}`}>
                            {c.priority}
                          </span>
                        </div>
                        <p className="text-xs text-stone-600 mt-0.5 line-clamp-1">{c.action_description}</p>
                        <div className="flex items-center gap-3 text-[11px] text-stone-600 mt-1">
                          <span>Owner: <strong>{c.owner_name}</strong></span>
                          <span>•</span>
                          <span className={isPast && c.completion_status !== 'completed' ? 'text-rose-600 font-bold' : ''}>
                            Due: {c.deadline_at ? new Date(c.deadline_at).toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : 'Undated'}
                          </span>
                        </div>
                      </div>
                    </div>

                    <div className="text-xs text-sage-800 font-semibold self-end sm:self-center">
                      Inspect Meeting Evidence &rarr;
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* SIDE PANEL EVIDENCE DRAWER */}
      {selectedCommitment && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-end bg-stone-900/40 backdrop-blur-sm animate-fade-in"
          onClick={() => { setSelectedCommitment(null); setIsRescheduling(false); }}
        >
          <div 
            className="w-full max-w-lg bg-white h-full shadow-2xl p-6 sm:p-8 flex flex-col justify-between overflow-y-auto"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="space-y-6">
              {/* Drawer Top */}
              <div className="flex items-center justify-between pb-4 border-b border-warm-200">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-sage-800 bg-sage-100 px-3 py-1 rounded-full">
                    Commitment Detail
                  </span>
                  {isMyCommitment(selectedCommitment.owner_name) ? (
                    <span className="text-xs font-bold bg-emerald-100 text-emerald-800 px-2.5 py-1 rounded-full flex items-center gap-1 border border-emerald-200">
                      <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                      Promise You Made
                    </span>
                  ) : (
                    <span className="text-xs font-bold bg-sky-100 text-sky-800 px-2.5 py-1 rounded-full flex items-center gap-1 border border-sky-200">
                      <Users className="w-3.5 h-3.5 text-sky-600" />
                      Colleague Promised You
                    </span>
                  )}
                </div>
                <button
                  onClick={() => setSelectedCommitment(null)}
                  className="p-2 rounded-full text-stone-500 hover:text-stone-800 hover:bg-warm-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              {/* Title & Description */}
              <div>
                <h3 className="font-serif font-bold text-xl text-stone-900 mb-2">
                  {selectedCommitment.title}
                </h3>
                <p className="text-sm text-stone-700 leading-relaxed">
                  {selectedCommitment.action_description}
                </p>
              </div>

              {/* Online Meeting Origin Banner */}
              <div className="p-3.5 rounded-2xl bg-warm-100/70 border border-warm-200 flex items-center gap-3 text-xs text-stone-700">
                <Video className="w-5 h-5 text-sage-700 shrink-0" />
                <div>
                  <span className="font-bold text-stone-900 block">Captured in Online Meeting</span>
                  <span className="text-[11px] text-stone-600">
                    Extracted with speaker attribution & timeline resolution
                  </span>
                </div>
              </div>

              {/* Metadata Grid */}
              <div className="grid grid-cols-2 gap-3 p-4 rounded-2xl bg-warm-50 border border-warm-200 text-xs">
                <div>
                  <span className="text-stone-500 block">Responsible Person</span>
                  <strong className="text-stone-900 text-sm mt-0.5 block">{selectedCommitment.owner_name}</strong>
                  <span className="text-[10px] text-stone-500">({selectedCommitment.owner_speaker_label})</span>
                </div>

                <div>
                  <span className="text-stone-500 block">Priority & Status</span>
                  <div className="flex items-center gap-1.5 mt-1">
                    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${getPriorityColor(selectedCommitment.priority)}`}>
                      {selectedCommitment.priority}
                    </span>
                    <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-warm-200 text-stone-800 capitalize">
                      {selectedCommitment.completion_status}
                    </span>
                  </div>
                </div>

                <div className="col-span-2 pt-2 border-t border-warm-200/80">
                  <span className="text-stone-500 block">Confirmed Deadline ({selectedCommitment.timezone})</span>
                  <strong className="text-stone-900 text-sm mt-0.5 block">
                    {selectedCommitment.deadline_at
                      ? new Date(selectedCommitment.deadline_at).toLocaleDateString([], {
                          weekday: 'long',
                          month: 'long',
                          day: 'numeric',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })
                      : 'Undated'}
                  </strong>
                </div>
              </div>

              {/* Scheduled 24h Reminder Box */}
              <div className="p-4 rounded-2xl bg-sky-50 border border-sky-200 text-xs">
                <div className="flex items-center justify-between mb-1">
                  <span className="font-bold text-sky-950 flex items-center gap-1.5">
                    <Clock className="w-4 h-4 text-sky-700" />
                    <span>Durable 24-Hour Reminder</span>
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-sky-200 text-sky-900">
                    Active
                  </span>
                </div>
                <p className="text-sky-900 text-[11px] leading-relaxed">
                  Scheduled exactly 24 hours prior to deadline via background worker. Rescheduling the deadline automatically adjusts this reminder.
                </p>
              </div>

              {/* Original Speech Evidence Excerpt */}
              <div className="p-4 rounded-2xl bg-warm-50 border border-warm-200 space-y-1.5">
                <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-sage-850">
                  <Quote className="w-3.5 h-3.5 text-sage-700" />
                  <span>Original Meeting Transcript Quote</span>
                </div>
                <blockquote className="text-xs sm:text-sm text-stone-700 italic leading-relaxed">
                  &ldquo;{selectedCommitment.transcript_excerpt}&rdquo;
                </blockquote>
                {selectedCommitment.original_deadline_phrase && (
                  <p className="text-[11px] text-stone-600 pt-1">
                    Spoken phrase: <strong className="text-stone-900">&ldquo;{selectedCommitment.original_deadline_phrase}&rdquo;</strong>
                  </p>
                )}
              </div>

              {/* Reschedule inline widget */}
              {isRescheduling && (
                <div className="p-4 rounded-2xl bg-warm-100 border border-warm-200 space-y-2 text-xs">
                  <span className="font-bold text-stone-900">Reschedule Target Deadline:</span>
                  <input
                    type="datetime-local"
                    value={newDeadlineInput}
                    onChange={(e) => setNewDeadlineInput(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-white border border-warm-200 text-xs text-stone-800"
                  />
                  <div className="flex gap-2 justify-end pt-1">
                    <button
                      onClick={() => setIsRescheduling(false)}
                      className="px-3 py-1.5 rounded-lg border border-warm-200 text-stone-600"
                    >
                      Cancel
                    </button>
                    <button
                      onClick={handleSaveReschedule}
                      className="px-3 py-1.5 rounded-lg bg-sage-700 text-white font-semibold"
                    >
                      Update & Reschedule 24h Reminder
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Drawer Actions */}
            <div className="pt-6 border-t border-warm-200 flex flex-wrap gap-2.5 justify-between">
              <button
                onClick={() => {
                  toggleCompleteCommitment(selectedCommitment.id);
                  setSelectedCommitment({
                    ...selectedCommitment,
                    completion_status: selectedCommitment.completion_status === 'completed' ? 'pending' : 'completed',
                  });
                }}
                className={`flex items-center gap-1.5 px-4 py-2.5 rounded-xl text-xs font-semibold shadow-sm transition-all ${
                  selectedCommitment.completion_status === 'completed'
                    ? 'bg-warm-200 text-stone-800'
                    : 'bg-emerald-600 hover:bg-emerald-700 text-white'
                }`}
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>{selectedCommitment.completion_status === 'completed' ? 'Reopen Commitment' : 'Mark Completed'}</span>
              </button>

              <button
                onClick={() => {
                  setIsRescheduling(true);
                  setNewDeadlineInput(selectedCommitment.deadline_at ? selectedCommitment.deadline_at.slice(0, 16) : '');
                }}
                className="px-4 py-2.5 rounded-xl border border-warm-200 hover:bg-warm-100 text-stone-700 text-xs font-semibold"
              >
                Reschedule
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Google Calendar Sync Modal */}
      {showSyncModal && (
        <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-warm-xl border border-warm-200 space-y-6 animate-scale-up">
            <div className="flex items-center justify-between pb-3 border-b border-warm-200">
              <div className="flex items-center gap-2 text-sage-800">
                <Share2 className="w-5 h-5" />
                <h3 className="text-lg font-serif font-bold text-stone-900">
                  Google Calendar OAuth 2.0 Integration
                </h3>
              </div>
              <button
                onClick={() => { setShowSyncModal(false); setSyncResult(null); }}
                className="p-1.5 rounded-xl hover:bg-warm-100 text-stone-500"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs sm:text-sm text-stone-600">
              <p>
                CommitMind integrates with Google Calendar via official OAuth 2.0. We request only the minimal calendar scopes required to publish confirmed meeting commitments.
              </p>

              <div className="p-4 rounded-2xl bg-warm-50 border border-warm-200 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-semibold text-stone-850">Integration Status</span>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-amber-100 text-amber-800">
                    Awaiting OAuth Authorization
                  </span>
                </div>
                <p className="text-xs text-stone-500">
                  Internal commitments calendar is fully active and persistent. External two-way Google Calendar synchronization activates when client credentials and user authorization are supplied.
                </p>
              </div>

              {syncResult && (
                <div className={`p-4 rounded-2xl border text-xs ${
                  syncResult.success 
                    ? 'bg-emerald-50 border-emerald-200 text-emerald-800' 
                    : 'bg-rose-50 border-rose-200 text-rose-800'
                }`}>
                  <strong className="block font-semibold mb-1">
                    {syncResult.success ? 'Sync Successful' : 'Sync Notice (Accurate Error Reporting)'}
                  </strong>
                  <span>{syncResult.error || syncResult.message}</span>
                </div>
              )}

              <div className="space-y-2">
                <strong className="block text-stone-900 font-semibold">How to Enable Google Calendar:</strong>
                <ol className="list-decimal pl-4 space-y-1 text-xs text-stone-600">
                  <li>Set <code className="bg-warm-100 px-1 py-0.5 rounded font-mono">GOOGLE_CLIENT_ID</code> and secret in your server environment.</li>
                  <li>Users authenticate with Google to grant calendar write access.</li>
                  <li>Confirmed commitments automatically sync with matching UTC timestamps.</li>
                </ol>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-end gap-3 pt-2 border-t border-warm-200">
              <button
                type="button"
                onClick={async () => {
                  setIsSyncing(true);
                  try {
                    const res = await fetch('/api/calendar/google-sync', {
                      method: 'POST',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({ access_token: '' }),
                    });
                    const data = await res.json();
                    setSyncResult(data);
                  } catch {
                    setSyncResult({ success: false, error: 'Could not connect to backend server /api/calendar/google-sync' });
                  } finally {
                    setIsSyncing(false);
                  }
                }}
                disabled={isSyncing}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-sage-700 hover:bg-sage-800 text-white font-semibold text-xs transition-all shadow-warm-sm"
              >
                {isSyncing ? 'Verifying Sync Status...' : 'Test Connection & Sync'}
              </button>

              <button
                type="button"
                onClick={() => { setShowSyncModal(false); setSyncResult(null); }}
                className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-warm-200 hover:bg-warm-100 text-stone-700 font-semibold text-xs"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
