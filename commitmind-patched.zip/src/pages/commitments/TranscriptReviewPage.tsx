import React, { useState } from 'react';
import { 
  FileText, 
  CheckCircle2, 
  XCircle, 
  Trash2, 
  Edit3, 
  Clock, 
  User, 
  Quote, 
  ArrowRight,
  CheckCheck,
  AlertTriangle,
  UserCheck,
  Users
} from 'lucide-react';
import { useCommitments } from '../../context/CommitmentsContext';
import { useMindfulness } from '../../context/MindfulnessContext';
import { isMyCommitment } from '../../types';

export const TranscriptReviewPage: React.FC = () => {
  const { 
    commitments, 
    sessions, 
    confirmCommitment, 
    rejectCommitment, 
    deleteCommitment, 
    updateCommitmentDeadline,
    updateCommitmentAttribution 
  } = useCommitments();
  const { setCurrentPage, showToast } = useMindfulness();

  const [editingCommitmentId, setEditingCommitmentId] = useState<string | null>(null);
  const [editedDeadline, setEditedDeadline] = useState<string>('');
  const [editingOwnerId, setEditingOwnerId] = useState<string | null>(null);
  const [editedOwner, setEditedOwner] = useState<string>('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);

  const latestSession = sessions[0];
  const proposedCommitments = commitments.filter((c) => c.extraction_status === 'proposed');
  const confirmedCommitments = commitments.filter((c) => c.extraction_status === 'confirmed');

  const handleBulkConfirm = () => {
    selectedIds.forEach((id) => confirmCommitment(id));
    setSelectedIds([]);
    showToast(`Confirmed ${selectedIds.length} commitments! Placed on calendar with 24h reminders 📅`, 'success');
  };

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const handleSaveDeadlineEdit = (id: string) => {
    if (!editedDeadline) return;
    updateCommitmentDeadline(id, new Date(editedDeadline).toISOString());
    setEditingCommitmentId(null);
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-5xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <CheckCircle2 className="w-4 h-4" />
            <span>Human-in-the-Loop Verification</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-800">
            Commitment Review & Attribution
          </h2>
          <p className="text-sm text-stone-600 mt-1">
            Verify detected actions, assign owners, and confirm calendar scheduling.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {proposedCommitments.length > 0 && selectedIds.length > 0 && (
            <button
              onClick={handleBulkConfirm}
              className="flex items-center gap-2 px-4 py-2 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm transition-all"
            >
              <CheckCheck className="w-4 h-4" />
              <span>Confirm Selected ({selectedIds.length})</span>
            </button>
          )}

          <button
            onClick={() => setCurrentPage('commitments_calendar')}
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-warm-100 hover:bg-warm-200 text-stone-700 text-xs font-semibold border border-warm-200"
          >
            <span>View Calendar</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Latest Session Transcript Excerpt Bar */}
      {latestSession && latestSession.raw_transcript && (
        <div className="calm-card p-5 bg-gradient-to-r from-warm-50 via-white to-warm-50">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-sage-700 flex items-center gap-1.5">
              <FileText className="w-3.5 h-3.5" /> Source Session: {latestSession.title}
            </span>
            <span className="text-[11px] text-stone-600">
              {new Date(latestSession.started_at).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
            </span>
          </div>
          <div className="p-3.5 rounded-xl bg-warm-50 border border-warm-200 text-xs text-stone-700 font-mono whitespace-pre-wrap max-h-36 overflow-y-auto leading-relaxed">
            {latestSession.raw_transcript}
          </div>
        </div>
      )}

      {/* Proposed Commitments Section */}
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="font-serif font-bold text-lg text-stone-800 flex items-center gap-2">
            <span>Proposed Commitments</span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-sans font-bold">
              {proposedCommitments.length} Pending
            </span>
          </h3>

          {proposedCommitments.length > 0 && (
            <button
              onClick={() => {
                if (selectedIds.length === proposedCommitments.length) setSelectedIds([]);
                else setSelectedIds(proposedCommitments.map((c) => c.id));
              }}
              className="text-xs text-sage-700 font-semibold hover:underline"
            >
              {selectedIds.length === proposedCommitments.length ? 'Deselect All' : 'Select All'}
            </button>
          )}
        </div>

        {proposedCommitments.length > 0 ? (
          <div className="space-y-4">
            {proposedCommitments.map((c) => {
              const isSelected = selectedIds.includes(c.id);
              const isEditing = editingCommitmentId === c.id;

              return (
                <div
                  key={c.id}
                  className={`calm-card p-6 border transition-all ${
                    isSelected ? 'ring-2 ring-sage-500 border-sage-500 bg-sage-50/20' : ''
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 mb-4">
                    <div className="flex items-start gap-3">
                      <input
                        type="checkbox"
                        checked={isSelected}
                        onChange={() => toggleSelect(c.id)}
                        className="mt-1 rounded accent-sage-600 w-4 h-4 cursor-pointer"
                      />
                      <div>
                        <div className="flex flex-wrap items-center gap-2 mb-1">
                          <h4 className="font-serif font-bold text-base text-stone-900">
                            {c.title}
                          </h4>
                          <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold flex items-center gap-1 ${
                            isMyCommitment(c.owner_name)
                              ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                              : 'bg-sky-100 text-sky-800 border border-sky-200'
                          }`}>
                            {isMyCommitment(c.owner_name) ? <UserCheck className="w-3 h-3" /> : <Users className="w-3 h-3" />}
                            {isMyCommitment(c.owner_name) ? 'My Commitment' : `From ${c.owner_name}`}
                          </span>
                          <span className="text-[10px] px-2.5 py-0.5 rounded-full bg-amber-100 text-amber-800 font-bold border border-amber-200">
                            Confidence: {Math.round(c.confidence_score * 100)}%
                          </span>
                          {c.source_type && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-warm-200 text-stone-700 font-semibold uppercase">
                              {c.source_type}
                            </span>
                          )}
                          {c.is_flagged_uncertain && (
                            <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-200/90 text-amber-900 font-bold flex items-center gap-1 border border-amber-300">
                              <AlertTriangle className="w-3 h-3 text-amber-800" />
                              Human Checkpoint Required
                            </span>
                          )}
                        </div>
                        <p className="text-xs sm:text-sm text-stone-600">
                          {c.action_description}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 self-end sm:self-start">
                      <button
                        onClick={() => confirmCommitment(c.id)}
                        className="px-3.5 py-1.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm transition-all"
                        title="Confirm commitment & schedule 24h reminder"
                      >
                        Confirm
                      </button>

                      <button
                        onClick={() => rejectCommitment(c.id)}
                        className="p-2 rounded-xl text-stone-600 hover:bg-rose-50 hover:text-rose-700 transition-colors"
                        title="Reject proposal"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>

                      <button
                        onClick={() => deleteCommitment(c.id)}
                        className="p-2 rounded-xl text-stone-600 hover:bg-warm-100 transition-colors"
                        title="Delete"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>

                  {/* Transcript Evidence Card */}
                  <div className="p-3.5 rounded-xl bg-warm-50/90 border border-warm-200/80 mb-4">
                    <div className="flex items-center gap-1.5 text-[11px] font-bold text-sage-800 uppercase tracking-wider mb-1">
                      <Quote className="w-3.5 h-3.5 text-sage-600" />
                      <span>Original Speech Evidence</span>
                    </div>
                    <blockquote className="text-xs text-stone-700 italic">
                      &ldquo;{c.transcript_excerpt}&rdquo;
                    </blockquote>
                  </div>

                  {/* Owner & Deadline Row */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-3 border-t border-warm-200/60 text-xs">
                    <div className="flex items-center justify-between gap-2 text-stone-700">
                      <div className="flex items-center gap-2">
                        <User className="w-3.5 h-3.5 text-stone-600" />
                        <span>Owner: <strong>{c.owner_name}</strong></span>
                        <span className="text-[10px] text-stone-600">({c.owner_speaker_label})</span>
                      </div>
                      <button
                        onClick={() => {
                          setEditingOwnerId(c.id);
                          setEditedOwner(c.owner_name);
                        }}
                        className="text-sage-700 hover:underline flex items-center gap-1 text-[11px] font-semibold"
                        title="Correct speaker attribution"
                      >
                        <Edit3 className="w-3 h-3" /> Reassign
                      </button>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-stone-700">
                        <Clock className="w-3.5 h-3.5 text-stone-600" />
                        <span>Deadline:</span>
                        {c.deadline_at ? (
                          <strong className="text-sage-700">
                            {new Date(c.deadline_at).toLocaleDateString([], {
                              month: 'short',
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit',
                            })}
                          </strong>
                        ) : (
                          <span className="text-amber-700 italic">Undated</span>
                        )}
                      </div>

                      <button
                        onClick={() => {
                          setEditingCommitmentId(c.id);
                          setEditedDeadline(c.deadline_at ? c.deadline_at.slice(0, 16) : '');
                        }}
                        className="text-sage-700 hover:underline flex items-center gap-1 text-[11px] font-semibold"
                      >
                        <Edit3 className="w-3 h-3" /> Edit Deadline
                      </button>
                    </div>
                  </div>

                  {/* Inline Attribution Edit Form */}
                  {editingOwnerId === c.id && (
                    <div className="mt-3 p-3 rounded-xl bg-warm-100 border border-warm-200 flex flex-wrap items-center gap-3">
                      <span className="text-xs font-semibold text-stone-700">Assign Responsible Person:</span>
                      <input
                        type="text"
                        value={editedOwner}
                        onChange={(e) => setEditedOwner(e.target.value)}
                        placeholder="e.g. Amit, Rahul, Adhyayan"
                        className="px-3 py-1.5 rounded-lg bg-white border border-warm-200 text-xs text-stone-800"
                      />
                      <button
                        onClick={() => {
                          if (editedOwner.trim()) {
                            updateCommitmentAttribution(c.id, editedOwner.trim());
                            setEditingOwnerId(null);
                          }
                        }}
                        className="px-3 py-1.5 rounded-lg bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold"
                      >
                        Save Owner
                      </button>
                      <button
                        onClick={() => setEditingOwnerId(null)}
                        className="px-2 py-1.5 rounded-lg text-xs text-stone-600 hover:bg-warm-200"
                      >
                        Cancel
                      </button>
                    </div>
                  )}

                  {/* Inline Deadline Edit Form */}
                  {isEditing && (
                    <div className="mt-3 p-3 rounded-xl bg-warm-100 border border-warm-200 flex flex-wrap items-center gap-3">
                      <span className="text-xs font-semibold text-stone-700">Set Exact Deadline:</span>
                      <input
                        type="datetime-local"
                        value={editedDeadline}
                        onChange={(e) => setEditedDeadline(e.target.value)}
                        className="px-3 py-1.5 rounded-lg bg-white border border-warm-200 text-xs text-stone-800"
                      />
                      <button
                        onClick={() => handleSaveDeadlineEdit(c.id)}
                        className="px-3 py-1.5 rounded-lg bg-sage-600 text-white text-xs font-semibold"
                      >
                        Save
                      </button>
                      <button
                        onClick={() => setEditingCommitmentId(null)}
                        className="px-3 py-1.5 rounded-lg border border-warm-200 text-xs text-stone-600"
                      >
                        Cancel
                      </button>
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="calm-card p-8 text-center text-stone-600">
            <CheckCircle2 className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
            <p className="text-sm font-semibold">No pending proposals awaiting verification.</p>
            <p className="text-xs mt-1">All extracted commitments have been reviewed and confirmed.</p>
          </div>
        )}
      </div>

      {/* Confirmed Commitments Snapshot */}
      {confirmedCommitments.length > 0 && (
        <div className="pt-4 border-t border-warm-200">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-serif font-bold text-base text-stone-800">
              Confirmed on Calendar ({confirmedCommitments.length})
            </h3>
            <button
              onClick={() => setCurrentPage('commitments_calendar')}
              className="text-xs text-sage-700 font-semibold hover:underline"
            >
              Open Full Calendar &rarr;
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {confirmedCommitments.slice(0, 4).map((c) => (
              <div key={c.id} className="p-3.5 rounded-2xl bg-white border border-warm-200/80 flex items-center justify-between text-xs">
                <div>
                  <h5 className="font-semibold text-stone-800 line-clamp-1">{c.title}</h5>
                  <p className="text-[11px] text-stone-600 mt-0.5">
                    {c.owner_name} • {c.deadline_at ? new Date(c.deadline_at).toLocaleDateString([], { month: 'short', day: 'numeric' }) : 'Undated'}
                  </p>
                </div>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-bold">
                  Active
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
