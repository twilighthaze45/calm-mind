import { useState } from 'react';
import { Sparkles, Clock, Play, Headphones, CheckCircle2, Filter, X } from 'lucide-react';
import { useMindfulness } from '../context/MindfulnessContext';
import { MindfulnessExercise } from '../types';
import { soundscape } from '../services/audio';

const EXERCISES: MindfulnessExercise[] = [
  {
    id: 'e-1',
    title: 'Morning Awakening & Grounding',
    category: 'meditation',
    duration_minutes: 5,
    description: 'Awaken your senses gently. Establish an anchor in the breath to meet the day with quiet resilience.',
    instructor: 'Elena Vance',
    ambient_sound: 'rain',
    featured: true,
  },
  {
    id: 'e-2',
    title: 'Releasing Afternoon Tension',
    category: 'breathwork',
    duration_minutes: 8,
    description: 'Midday nervous system reset. Release accumulated shoulder strain and mental fatigue.',
    instructor: 'Marcus Chen',
    ambient_sound: 'forest',
  },
  {
    id: 'e-3',
    title: 'Deep Slumber & Body Scan',
    category: 'sleep',
    duration_minutes: 15,
    description: 'A comforting guided journey progressively easing attention away from thinking and into restorative sleep.',
    instructor: 'Dr. Sarah Lin',
    ambient_sound: 'waves',
    featured: true,
  },
  {
    id: 'e-4',
    title: 'Rainforest Rainfall Soundscape',
    category: 'soundscape',
    duration_minutes: 20,
    description: 'Gentle procedural rainfall designed to mask distracting ambient noise and induce alpha brain waves.',
    ambient_sound: 'rain',
  },
  {
    id: 'e-5',
    title: 'Ocean Surf & Breath Synchronization',
    category: 'soundscape',
    duration_minutes: 12,
    description: 'Rhythmic ocean swells rolling gently upon pebble beaches, naturally pacing deep breaths.',
    ambient_sound: 'waves',
  },
  {
    id: 'e-6',
    title: 'Deep Focus & Single-Point Attention',
    category: 'focus',
    duration_minutes: 10,
    description: 'Cultivate sustained focus through gentle noticing whenever the mind wanders away.',
    instructor: 'Elena Vance',
    ambient_sound: 'bowl',
  },
];

export const LibraryPage: React.FC = () => {
  const { recordMindfulMinutes, showToast } = useMindfulness();
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [activeSession, setActiveSession] = useState<MindfulnessExercise | null>(null);

  const categories = ['all', 'meditation', 'breathwork', 'sleep', 'soundscape', 'focus'];

  const filteredExercises = selectedCategory === 'all'
    ? EXERCISES
    : EXERCISES.filter((e) => e.category === selectedCategory);

  const startSession = (exercise: MindfulnessExercise) => {
    setActiveSession(exercise);

    // Start synthesized ambient audio
    if (exercise.ambient_sound === 'rain') soundscape.startAmbient('rain');
    else if (exercise.ambient_sound === 'waves') soundscape.startAmbient('waves');
    else if (exercise.ambient_sound === 'forest') soundscape.startAmbient('forest');
    else soundscape.playSingingBowl(261.63);

    showToast(`Started: ${exercise.title}`, 'info');
  };

  const stopSession = (completed = false) => {
    soundscape.stopAmbient();
    if (completed && activeSession) {
      recordMindfulMinutes(activeSession.duration_minutes);
      showToast(`Completed ${activeSession.duration_minutes} mindful minutes 🌿`, 'success');
    }
    setActiveSession(null);
  };

  return (
    <div className="space-y-8 animate-fade-in max-w-6xl mx-auto pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-4 h-4" />
            <span>Curated Sanctuary</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-800">
            Mindfulness & Meditation Library
          </h2>
          <p className="text-sm text-stone-600 mt-1">
            Guided meditations, restful soundscapes, and restorative breath journeys.
          </p>
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 text-xs">
        <span className="flex items-center gap-1 font-semibold text-stone-600 pl-1 mr-2">
          <Filter className="w-3.5 h-3.5" /> Category:
        </span>
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-3.5 py-1.5 rounded-full font-medium capitalize whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-sage-600 text-white shadow-sm'
                : 'bg-warm-100 text-stone-600 hover:bg-warm-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Exercise Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredExercises.map((exercise) => (
          <div
            key={exercise.id}
            className="calm-card-interactive p-6 flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between mb-3">
                <span className="text-[11px] font-bold uppercase tracking-wider text-sage-800 bg-sage-100 px-2.5 py-0.5 rounded-full capitalize">
                  {exercise.category}
                </span>
                <span className="flex items-center gap-1 text-xs font-medium text-stone-600">
                  <Clock className="w-3.5 h-3.5" />
                  <span>{exercise.duration_minutes} min</span>
                </span>
              </div>

              <h3 className="font-serif font-bold text-lg text-stone-800 mb-2 group-hover:text-sage-700 transition-colors">
                {exercise.title}
              </h3>

              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed mb-4">
                {exercise.description}
              </p>
            </div>

            <div className="pt-4 border-t border-warm-200/60 flex items-center justify-between">
              <span className="text-xs text-stone-600 italic">
                {exercise.instructor ? `With ${exercise.instructor}` : 'Ambient Soundscape'}
              </span>

              <button
                onClick={() => startSession(exercise)}
                className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm transition-all active:scale-95"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                <span>Begin</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Active Session Player Modal */}
      {activeSession && (
        <div 
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/50 backdrop-blur-md animate-fade-in"
          role="dialog"
          aria-modal="true"
        >
          <div className="w-full max-w-md bg-white rounded-3xl shadow-warm-lg border border-warm-200 p-6 sm:p-8 text-center relative">
            <button
              onClick={() => stopSession(false)}
              className="absolute top-5 right-5 p-2 rounded-full text-stone-600 hover:text-stone-700 hover:bg-warm-100 transition-colors"
              aria-label="Close session"
            >
              <X className="w-5 h-5" />
            </button>

            <span className="text-xs font-bold uppercase tracking-wider text-sage-700 bg-sage-100 px-3 py-1 rounded-full mb-3 inline-block capitalize">
              {activeSession.category}
            </span>

            <h3 className="font-serif font-bold text-xl sm:text-2xl text-stone-800 mb-2">
              {activeSession.title}
            </h3>

            <p className="text-xs sm:text-sm text-stone-600 mb-6">
              {activeSession.description}
            </p>

            {/* Glowing Sound Orb */}
            <div className="w-32 h-32 mx-auto rounded-full bg-gradient-to-tr from-sage-200 to-emerald-200 border-2 border-sage-400 flex items-center justify-center shadow-sage-glow animate-subtle-pulse mb-6">
              <Headphones className="w-10 h-10 text-sage-700" />
            </div>

            <p className="text-xs text-stone-600 mb-6 italic">
              Procedural audio playing smoothly in your browser. Relax and close your eyes.
            </p>

            {/* Controls */}
            <div className="flex items-center justify-center gap-3">
              <button
                onClick={() => stopSession(false)}
                className="px-4 py-2.5 rounded-xl border border-warm-200 text-stone-700 hover:bg-warm-100 text-xs font-medium"
              >
                Cancel Session
              </button>

              <button
                onClick={() => stopSession(true)}
                className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Finish & Record Time</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
