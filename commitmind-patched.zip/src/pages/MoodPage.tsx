import { useState } from 'react';
import { Smile, Filter, Plus, Calendar, Tag } from 'lucide-react';
import { useMindfulness } from '../context/MindfulnessContext';
import { MoodValence } from '../types';

export const MoodPage: React.FC = () => {
  const { moods, setIsQuickCheckInOpen } = useMindfulness();
  const [filterValence, setFilterValence] = useState<string>('all');

  const filteredMoods = filterValence === 'all'
    ? moods
    : moods.filter((m) => m.valence === filterValence);

  const getEmoji = (valence: MoodValence) => {
    switch (valence) {
      case 'peaceful': return '🕊️';
      case 'grateful': return '🌸';
      case 'content': return '🍃';
      case 'neutral': return '⚖️';
      case 'restless': return '🌊';
      case 'anxious': return '☁️';
      case 'tired': return '🌙';
      case 'overwhelmed': return '🌪️';
      default: return '✨';
    }
  };

  const valenceCounts = moods.reduce<Record<string, number>>((acc, curr) => {
    acc[curr.valence] = (acc[curr.valence] || 0) + 1;
    return acc;
  }, {});

  const avgCalmScore = moods.length
    ? (moods.reduce((sum, m) => sum + m.score, 0) / moods.length).toFixed(1)
    : '0';

  return (
    <div className="space-y-8 animate-fade-in max-w-6xl mx-auto pb-12">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-warm-200">
        <div>
          <div className="flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <Smile className="w-4 h-4" />
            <span>Emotional Awareness</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-serif font-bold text-stone-800">
            Mood Tracker & Emotional Weather
          </h2>
          <p className="text-sm text-stone-600 mt-1">
            Observe shifts in energy and serenity without expectation or judgment.
          </p>
        </div>

        <button
          onClick={() => setIsQuickCheckInOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-sm font-semibold shadow-sm hover:shadow-md transition-all self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Log New Mood</span>
        </button>
      </div>

      {/* Overview Analytics Bar */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="calm-card p-5">
          <p className="text-xs font-bold uppercase tracking-wider text-stone-600 mb-1">
            Average Calm Score
          </p>
          <p className="text-3xl font-serif font-bold text-sage-700">
            {avgCalmScore} <span className="text-sm font-normal text-stone-600">/ 10</span>
          </p>
          <p className="text-xs text-stone-600 mt-1">
            Across {moods.length} recorded moments
          </p>
        </div>

        <div className="calm-card p-5">
          <p className="text-xs font-bold uppercase tracking-wider text-stone-600 mb-1">
            Predominant Emotion
          </p>
          <p className="text-2xl font-serif font-bold text-stone-800 capitalize">
            {moods[0]?.label || 'Peaceful'}
          </p>
          <p className="text-xs text-stone-600 mt-1">
            Latest recorded state
          </p>
        </div>

        <div className="calm-card p-5">
          <p className="text-xs font-bold uppercase tracking-wider text-stone-600 mb-1">
            Reflection Frequency
          </p>
          <p className="text-2xl font-serif font-bold text-stone-800">
            Daily Cadence
          </p>
          <p className="text-xs text-stone-600 mt-1">
            Cultivating daily self-observation
          </p>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 text-xs">
        <span className="flex items-center gap-1 font-semibold text-stone-600 pl-1 mr-2">
          <Filter className="w-3.5 h-3.5" /> Filter:
        </span>
        <button
          onClick={() => setFilterValence('all')}
          className={`px-3 py-1.5 rounded-full font-medium transition-all ${
            filterValence === 'all'
              ? 'bg-sage-600 text-white shadow-sm'
              : 'bg-warm-100 text-stone-600 hover:bg-warm-200'
          }`}
        >
          All ({moods.length})
        </button>
        {Object.entries(valenceCounts).map(([valence, count]) => (
          <button
            key={valence}
            onClick={() => setFilterValence(valence)}
            className={`px-3 py-1.5 rounded-full font-medium capitalize transition-all ${
              filterValence === valence
                ? 'bg-sage-600 text-white shadow-sm'
                : 'bg-warm-100 text-stone-600 hover:bg-warm-200'
            }`}
          >
            {valence} ({count})
          </button>
        ))}
      </div>

      {/* Mood Entries Timeline / Grid */}
      <div className="space-y-4">
        {filteredMoods.length > 0 ? (
          filteredMoods.map((entry) => (
            <div
              key={entry.id}
              className="calm-card p-5 sm:p-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
            >
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-2xl bg-warm-100 flex items-center justify-center text-2xl shrink-0 shadow-warm-sm">
                  {getEmoji(entry.valence)}
                </div>
                <div>
                  <div className="flex items-center gap-3">
                    <h3 className="font-serif font-bold text-base text-stone-800 capitalize">
                      {entry.label}
                    </h3>
                    <span className="px-2.5 py-0.5 rounded-full bg-sage-100 text-sage-800 text-xs font-bold">
                      Calm: {entry.score}/10
                    </span>
                  </div>

                  <p className="text-xs text-stone-600 flex items-center gap-1.5 mt-1">
                    <Calendar className="w-3 h-3" />
                    <span>
                      {new Date(entry.created_at).toLocaleDateString([], {
                        weekday: 'short',
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </span>
                  </p>

                  {entry.notes && (
                    <p className="text-sm text-stone-700 italic mt-2.5 bg-warm-50/80 p-3 rounded-xl border border-warm-200/50">
                      &ldquo;{entry.notes}&rdquo;
                    </p>
                  )}

                  {entry.tags.length > 0 && (
                    <div className="flex flex-wrap items-center gap-1.5 mt-3">
                      <Tag className="w-3 h-3 text-stone-600" />
                      {entry.tags.map((tag) => (
                        <span
                          key={tag}
                          className="text-[11px] px-2.5 py-0.5 rounded-lg bg-warm-100 text-stone-600 font-medium"
                        >
                          {tag}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))
        ) : (
          <div className="calm-card p-12 text-center">
            <Smile className="w-10 h-10 text-stone-600 mx-auto mb-3" />
            <h4 className="text-base font-semibold text-stone-800">No matching mood entries</h4>
            <p className="text-sm text-stone-600 mt-1 mb-4">
              Clear your filter or log a mindful check-in now.
            </p>
            <button
              onClick={() => setIsQuickCheckInOpen(true)}
              className="px-4 py-2 rounded-xl bg-sage-600 text-white text-xs font-semibold"
            >
              Log Check-in
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
