import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { 
  MeetingSession, 
  Commitment, 
  CommitmentReminder, 
  UserNotificationPreferences,
  AppWorkspaceMode,
  isMyCommitment
} from '../types';
import { commitmentStore } from '../services/commitmentStorage';
import { useMindfulness } from './MindfulnessContext';

interface CommitmentsContextType {
  workspaceMode: AppWorkspaceMode;
  setWorkspaceMode: (mode: AppWorkspaceMode) => void;
  sessions: MeetingSession[];
  commitments: Commitment[];
  reminders: CommitmentReminder[];
  preferences: UserNotificationPreferences;
  addSession: (session: Omit<MeetingSession, 'id' | 'created_at'>) => MeetingSession;
  addCommitment: (c: Omit<Commitment, 'id' | 'created_at' | 'updated_at'>) => Commitment;
  confirmCommitment: (id: string) => void;
  rejectCommitment: (id: string) => void;
  toggleCompleteCommitment: (id: string) => void;
  updateCommitmentDeadline: (id: string, newDeadlineIso: string) => void;
  updateCommitmentAttribution: (id: string, newOwner: string) => void;
  deleteCommitment: (id: string) => void;
  updatePreferences: (prefs: Partial<UserNotificationPreferences>) => void;
  downloadICS: () => void;
  dueTodayCount: number;
  dueThisWeekCount: number;
  overdueCount: number;
  upcomingRemindersCount: number;
  myCommitmentsCount: number;
  colleaguesCommitmentsCount: number;
}

const CommitmentsContext = createContext<CommitmentsContextType | undefined>(undefined);

export const CommitmentsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const { showToast } = useMindfulness();
  const [workspaceMode, setWorkspaceMode] = useState<AppWorkspaceMode>('commitments');
  const [sessions, setSessions] = useState<MeetingSession[]>(() => commitmentStore.getSessions());
  const [commitments, setCommitments] = useState<Commitment[]>(() => commitmentStore.getCommitments());
  const [reminders, setReminders] = useState<CommitmentReminder[]>(() => commitmentStore.getReminders());
  const [preferences, setPreferences] = useState<UserNotificationPreferences>(() => commitmentStore.getPreferences());

  const refreshState = () => {
    setSessions(commitmentStore.getSessions());
    setCommitments(commitmentStore.getCommitments());
    setReminders(commitmentStore.getReminders());
    setPreferences(commitmentStore.getPreferences());
  };

  const addSession = (sessionData: Omit<MeetingSession, 'id' | 'created_at'>) => {
    const created = commitmentStore.addSession(sessionData);
    refreshState();
    showToast(`Session "${created.title}" saved with consent verification ✅`, 'success');
    return created;
  };

  const addCommitment = (cData: Omit<Commitment, 'id' | 'created_at' | 'updated_at'>) => {
    const created = commitmentStore.addCommitment(cData);
    refreshState();
    showToast(`Commitment "${created.title}" created ✨`, 'success');
    return created;
  };

  const confirmCommitment = (id: string) => {
    commitmentStore.updateCommitment(id, { extraction_status: 'confirmed' });
    refreshState();
    showToast('Commitment confirmed and placed on calendar (24h reminder scheduled) 📅', 'success');
  };

  const rejectCommitment = (id: string) => {
    commitmentStore.updateCommitment(id, { extraction_status: 'rejected' });
    refreshState();
    showToast('Proposal rejected and suppressed', 'info');
  };

  const toggleCompleteCommitment = (id: string) => {
    const target = commitments.find((c) => c.id === id);
    if (!target) return;
    const isCompleted = target.completion_status === 'completed';
    const nextStatus = isCompleted ? 'pending' : 'completed';
    commitmentStore.updateCommitment(id, {
      completion_status: nextStatus,
      completed_at: isCompleted ? null : new Date().toISOString(),
    });
    refreshState();
    if (!isCompleted) {
      showToast('Commitment marked completed! Pending reminder cancelled 🎯', 'success');
    } else {
      showToast('Commitment reopened as pending', 'info');
    }
  };

  const updateCommitmentDeadline = (id: string, newDeadlineIso: string) => {
    commitmentStore.updateCommitment(id, { deadline_at: newDeadlineIso });
    refreshState();
    showToast('Deadline updated and 24h reminder rescheduled ⏰', 'success');
  };

  const updateCommitmentAttribution = (id: string, newOwner: string) => {
    commitmentStore.updateCommitment(id, { owner_name: newOwner.trim() });
    refreshState();
    showToast(`Speaker attribution updated to ${newOwner.trim()} 👤`, 'success');
  };

  const deleteCommitment = (id: string) => {
    commitmentStore.deleteCommitment(id);
    refreshState();
    showToast('Commitment deleted', 'info');
  };

  const updatePreferences = (updates: Partial<UserNotificationPreferences>) => {
    const current = commitmentStore.getPreferences();
    const updated = { ...current, ...updates, updated_at: new Date().toISOString() };
    commitmentStore.savePreferences(updated);
    setPreferences(updated);
    showToast('Notification preferences updated 🔔', 'success');
  };

  const downloadICS = () => {
    const confirmed = commitments.filter((c) => c.extraction_status === 'confirmed');
    const icsContent = commitmentStore.exportToICS(confirmed);
    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `commitments-${new Date().toISOString().split('T')[0]}.ics`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast('Exported commitments to standard .ics calendar file 📅', 'success');
  };

  // Metrics
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
  const endOfToday = startOfToday + 24 * 60 * 60 * 1000;
  const endOfWeek = startOfToday + 7 * 24 * 60 * 60 * 1000;

  const activeConfirmed = commitments.filter(
    (c) => c.extraction_status === 'confirmed' && c.completion_status !== 'completed' && c.deadline_at
  );

  const dueTodayCount = activeConfirmed.filter((c) => {
    const t = new Date(c.deadline_at!).getTime();
    return t >= startOfToday && t <= endOfToday;
  }).length;

  const dueThisWeekCount = activeConfirmed.filter((c) => {
    const t = new Date(c.deadline_at!).getTime();
    return t > endOfToday && t <= endOfWeek;
  }).length;

  const overdueCount = activeConfirmed.filter((c) => {
    const t = new Date(c.deadline_at!).getTime();
    return t < now.getTime();
  }).length;

  const upcomingRemindersCount = reminders.filter((r) => r.status === 'pending').length;

  const myCommitmentsCount = activeConfirmed.filter((c) => isMyCommitment(c.owner_name)).length;
  const colleaguesCommitmentsCount = activeConfirmed.filter((c) => !isMyCommitment(c.owner_name)).length;

  // Sync state on mount
  useEffect(() => {
    refreshState();
  }, []);

  return (
    <CommitmentsContext.Provider
      value={{
        workspaceMode,
        setWorkspaceMode,
        sessions,
        commitments,
        reminders,
        preferences,
        addSession,
        addCommitment,
        confirmCommitment,
        rejectCommitment,
        toggleCompleteCommitment,
        updateCommitmentDeadline,
        updateCommitmentAttribution,
        deleteCommitment,
        updatePreferences,
        downloadICS,
        dueTodayCount,
        dueThisWeekCount,
        overdueCount,
        upcomingRemindersCount,
        myCommitmentsCount,
        colleaguesCommitmentsCount,
      }}
    >
      {children}
    </CommitmentsContext.Provider>
  );
};

export const useCommitments = (): CommitmentsContextType => {
  const context = useContext(CommitmentsContext);
  if (!context) {
    throw new Error('useCommitments must be used within a CommitmentsProvider');
  }
  return context;
};
