/**
 * Web Audio API Calming Sound Synthesizer
 * Generates natural ambient soundscapes (gentle rain, ocean waves, singing bowl chime, pink noise)
 * completely client-side without external asset dependencies.
 */

class SoundscapeEngine {
  private ctx: AudioContext | null = null;
  private activeNode: AudioNode | null = null;
  private activeType: string | null = null;
  private gainNode: GainNode | null = null;

  private initContext() {
    if (!this.ctx) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  // Play a soft singing bowl harmonic tone
  playSingingBowl(freq = 261.63) { // Middle C / 261Hz
    this.initContext();
    if (!this.ctx) return;

    const osc = this.ctx.createOscillator();
    const subOsc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, this.ctx.currentTime);

    subOsc.type = 'sine';
    subOsc.frequency.setValueAtTime(freq * 2.76, this.ctx.currentTime); // natural overtone

    const now = this.ctx.currentTime;
    gain.gain.setValueAtTime(0, now);
    gain.gain.linearRampToValueAtTime(0.2, now + 0.1);
    gain.gain.exponentialRampToValueAtTime(0.0001, now + 4.5);

    osc.connect(gain);
    subOsc.connect(gain);
    gain.connect(this.ctx.destination);

    osc.start(now);
    subOsc.start(now);
    osc.stop(now + 4.6);
    subOsc.stop(now + 4.6);
  }

  // Play ambient rain / pink noise generator
  startAmbient(type: 'rain' | 'waves' | 'brown-noise' | 'forest') {
    this.stopAmbient();
    this.initContext();
    if (!this.ctx) return;

    const bufferSize = this.ctx.sampleRate * 2;
    const noiseBuffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const output = noiseBuffer.getChannelData(0);

    // Generate brown/pink calming noise
    let lastOut = 0.0;
    for (let i = 0; i < bufferSize; i++) {
      const white = Math.random() * 2 - 1;
      output[i] = (lastOut + 0.02 * white) / 1.02;
      lastOut = output[i];
      output[i] *= 3.5; // gain compensation
    }

    const whiteNoise = this.ctx.createBufferSource();
    whiteNoise.buffer = noiseBuffer;
    whiteNoise.loop = true;

    // Filter to warm calming frequencies
    const filter = this.ctx.createBiquadFilter();
    if (type === 'rain') {
      filter.type = 'lowpass';
      filter.frequency.value = 850;
    } else if (type === 'waves') {
      filter.type = 'bandpass';
      filter.frequency.value = 400;
      filter.Q.value = 1.0;
    } else {
      filter.type = 'lowpass';
      filter.frequency.value = 500;
    }

    this.gainNode = this.ctx.createGain();
    this.gainNode.gain.setValueAtTime(0.01, this.ctx.currentTime);
    this.gainNode.gain.linearRampToValueAtTime(0.12, this.ctx.currentTime + 1.5);

    whiteNoise.connect(filter);
    filter.connect(this.gainNode);
    this.gainNode.connect(this.ctx.destination);

    whiteNoise.start();
    this.activeNode = whiteNoise;
    this.activeType = type;
  }

  stopAmbient() {
    if (this.gainNode && this.ctx) {
      try {
        this.gainNode.gain.linearRampToValueAtTime(0.0001, this.ctx.currentTime + 0.5);
      } catch {
        // ignore
      }
    }
    setTimeout(() => {
      if (this.activeNode) {
        try {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          (this.activeNode as any).stop();
        } catch {
          // ignore
        }
        this.activeNode = null;
        this.activeType = null;
      }
    }, 600);
  }

  isPlaying(type: string): boolean {
    return this.activeType === type;
  }

  getActiveType(): string | null {
    return this.activeType;
  }
}

export const soundscape = new SoundscapeEngine();
