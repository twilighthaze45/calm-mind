import { 
  MeetingSession, 
  Commitment, 
  CommitmentReminder, 
  UserNotificationPreferences 
} from '../types';

const SESSIONS_KEY = 'calmmind_sessions';
const COMMITMENTS_KEY = 'calmmind_commitments';
const REMINDERS_KEY = 'calmmind_reminders';
const PREFS_KEY = 'calmmind_notification_prefs';

// Helper to compute ISO dates relative to now
const relativeDate = (days: number, hours = 17, minutes = 0): string => {
  const d = new Date();
  d.setDate(d.getDate() + days);
  d.setHours(hours, minutes, 0, 0);
  return d.toISOString();
};

const INITIAL_SESSIONS: MeetingSession[] = [
  {
    id: 's-101',
    user_id: 'usr-default',
    title: 'Sprint Planning & Product Alignment',
    session_type: 'meeting',
    consent_confirmed: true,
    participants: ['Alice (Lead)', 'Bob (Design)', 'Carol (Backend)'],
    audio_retention_policy: 'do_not_store',
    started_at: new Date(Date.now() - 3600000 * 2).toISOString(),
    ended_at: new Date(Date.now() - 3600000 * 1.5).toISOString(),
    duration_seconds: 1820,
    raw_transcript: `Speaker 1: Welcome everyone. Let's align on this sprint's key deliverables.
Speaker 2: I'll finish the responsive frontend layouts by tomorrow afternoon.
Speaker 1: Great. I'll send the finalized quarterly report to the stakeholders by Friday at 5 PM.
Speaker 3: We will review the security audit findings before the team meeting next Monday.
Speaker 2: Maybe we could also rewrite the audio engine?
Speaker 1: Let's hold off on that for now; it's just an idea.`,
    status: 'completed',
    created_at: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: 's-102',
    user_id: 'usr-default',
    title: 'Client Review & Feedback Session',
    session_type: 'live_mic',
    consent_confirmed: true,
    participants: ['David (Client)', 'Self'],
    audio_retention_policy: 'delete_after_processing',
    started_at: new Date(Date.now() - 3600000 * 26).toISOString(),
    ended_at: new Date(Date.now() - 3600000 * 25).toISOString(),
    duration_seconds: 940,
    raw_transcript: `Speaker 1: I'll share the revised proposal with your team next Monday by noon.
Speaker 2: Perfect, we will review the terms as soon as you send it.`,
    status: 'completed',
    created_at: new Date(Date.now() - 3600000 * 26).toISOString(),
  },
];

const INITIAL_COMMITMENTS: Commitment[] = [
  {
    id: 'c-201',
    user_id: 'usr-default',
    session_id: 's-101',
    title: 'Finish responsive frontend layouts',
    action_description: 'Complete all responsive UI components, mobile drawer, and test on viewport widths.',
    owner_speaker_label: 'Speaker 2',
    owner_name: 'Bob (Design)',
    transcript_excerpt: "I'll finish the responsive frontend layouts by tomorrow afternoon.",
    source_timestamp: '00:04:12',
    deadline_at: relativeDate(1, 15, 0), // Tomorrow 3:00 PM
    deadline_type: 'datetime',
    original_deadline_phrase: 'by tomorrow afternoon',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    priority: 'high',
    confidence_score: 0.94,
    extraction_status: 'confirmed',
    completion_status: 'pending',
    deduplication_hash: 'hash-bob-frontend-tomorrow',
    created_at: new Date(Date.now() - 3600000 * 2).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: 'c-202',
    user_id: 'usr-default',
    session_id: 's-101',
    title: 'Send finalized quarterly report to stakeholders',
    action_description: 'Compile executive metrics and email PDF summary to leadership.',
    owner_speaker_label: 'Speaker 1',
    owner_name: 'Alice (Lead)',
    transcript_excerpt: "I'll send the finalized quarterly report to the stakeholders by Friday at 5 PM.",
    source_timestamp: '00:08:45',
    deadline_at: relativeDate(4, 17, 0), // 4 days away
    deadline_type: 'datetime',
    original_deadline_phrase: 'by Friday at 5 PM',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    priority: 'high',
    confidence_score: 0.96,
    extraction_status: 'confirmed',
    completion_status: 'pending',
    deduplication_hash: 'hash-alice-report-friday',
    created_at: new Date(Date.now() - 3600000 * 2).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: 'c-203',
    user_id: 'usr-default',
    session_id: 's-101',
    title: 'Review security audit findings before meeting',
    action_description: 'Examine CVE report and prepare remediation tickets.',
    owner_speaker_label: 'Speaker 3',
    owner_name: 'Carol (Backend)',
    transcript_excerpt: "We will review the security audit findings before the team meeting next Monday.",
    source_timestamp: '00:14:20',
    deadline_at: relativeDate(7, 10, 0), // Next Monday
    deadline_type: 'datetime',
    original_deadline_phrase: 'before the team meeting next Monday',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    priority: 'medium',
    confidence_score: 0.88,
    extraction_status: 'proposed', // Awaiting confirmation!
    completion_status: 'pending',
    deduplication_hash: 'hash-carol-sec-audit',
    created_at: new Date(Date.now() - 3600000 * 2).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
  {
    id: 'c-204',
    user_id: 'usr-default',
    session_id: 's-102',
    title: 'Share revised proposal with client team',
    action_description: 'Send PDF contract revision with agreed scope clauses.',
    owner_speaker_label: 'Speaker 1',
    owner_name: 'Self',
    transcript_excerpt: "I'll share the revised proposal with your team next Monday by noon.",
    source_timestamp: '00:03:10',
    deadline_at: relativeDate(7, 12, 0),
    deadline_type: 'datetime',
    original_deadline_phrase: 'next Monday by noon',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    priority: 'high',
    confidence_score: 0.95,
    extraction_status: 'confirmed',
    completion_status: 'pending',
    deduplication_hash: 'hash-self-proposal-monday',
    created_at: new Date(Date.now() - 3600000 * 26).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 26).toISOString(),
  },
  {
    id: 'c-205',
    user_id: 'usr-default',
    title: 'Send revised proposal to Priya',
    action_description: 'Review the proposal and send it before the deadline.',
    owner_speaker_label: 'Recipient',
    owner_name: 'Recipient (Self) · subject to confirmation',
    transcript_excerpt: 'Could you send the revised proposal to Priya by Friday?',
    source_timestamp: 'Email Received: 09:30 AM',
    source_type: 'email',
    deadline_at: relativeDate(4, 17, 0), // Friday 5:00 PM
    deadline_type: 'datetime',
    original_deadline_phrase: 'by Friday',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    priority: 'high',
    confidence_score: 0.89,
    is_flagged_uncertain: true, // Human checkpoint from Slide 5 & 7
    extraction_status: 'proposed', // Awaiting human confirmation checkpoint
    completion_status: 'pending',
    deduplication_hash: 'hash-priya-email-proposal',
    created_at: new Date(Date.now() - 3600000 * 3).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 3).toISOString(),
  },
  {
    id: 'c-206',
    user_id: 'usr-default',
    title: 'Complete task before the review',
    action_description: 'Finalize QA checklists and audit notes before formal stakeholder review.',
    owner_speaker_label: 'Speaker 1',
    owner_name: 'Kenisha (QA)',
    transcript_excerpt: 'Please complete the task before the review.',
    source_timestamp: 'Document Audit #14',
    source_type: 'document',
    deadline_at: relativeDate(2, 11, 0), // In 2 days at 11 AM
    deadline_type: 'datetime',
    original_deadline_phrase: 'before the review',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    priority: 'medium',
    confidence_score: 0.92,
    is_flagged_uncertain: false,
    extraction_status: 'confirmed',
    completion_status: 'pending',
    deduplication_hash: 'hash-kenisha-task-review',
    created_at: new Date(Date.now() - 3600000 * 5).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 5).toISOString(),
  },
  {
    id: 'c-207',
    user_id: 'usr-default',
    title: 'Share meeting minutes and client deliverables',
    action_description: 'Distribute summary notes and action items from the morning Zoom call.',
    owner_speaker_label: 'Speaker 1',
    owner_name: 'Self',
    transcript_excerpt: "I will circulate the meeting minutes and deliverables by this evening.",
    source_timestamp: '00:22:15',
    source_type: 'meeting',
    deadline_at: relativeDate(0, 18, 0), // Today 6:00 PM
    deadline_type: 'datetime',
    original_deadline_phrase: 'by this evening',
    timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
    priority: 'high',
    confidence_score: 0.97,
    extraction_status: 'confirmed',
    completion_status: 'pending',
    deduplication_hash: 'hash-self-minutes-today',
    created_at: new Date(Date.now() - 3600000 * 2).toISOString(),
    updated_at: new Date(Date.now() - 3600000 * 2).toISOString(),
  },
];

const calculate24hReminder = (deadlineIso: string): string => {
  const deadline = new Date(deadlineIso);
  const reminder = new Date(deadline.getTime() - 24 * 60 * 60 * 1000);
  // If reminder is already in the past, schedule 1 min from now
  if (reminder.getTime() <= Date.now()) {
    return new Date(Date.now() + 60 * 1000).toISOString();
  }
  return reminder.toISOString();
};

const INITIAL_REMINDERS: CommitmentReminder[] = INITIAL_COMMITMENTS
  .filter((c) => c.extraction_status === 'confirmed' && c.deadline_at)
  .map((c) => ({
    id: 'rem-' + c.id,
    user_id: c.user_id,
    commitment_id: c.id,
    reminder_at: calculate24hReminder(c.deadline_at!),
    delivery_channel: 'in_app',
    status: 'pending',
    idempotency_key: `${c.user_id}_${c.id}_${c.deadline_at}`,
    retry_count: 0,
    created_at: c.created_at,
    updated_at: c.updated_at,
  }));

const DEFAULT_PREFERENCES: UserNotificationPreferences = {
  user_id: 'usr-default',
  in_app_enabled: true,
  browser_notifications_enabled: false,
  email_enabled: false,
  advance_notice_hours: 24,
  timezone: Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC',
  created_at: new Date().toISOString(),
  updated_at: new Date().toISOString(),
};

export const commitmentStore = {
  getSessions(): MeetingSession[] {
    try {
      const data = localStorage.getItem(SESSIONS_KEY);
      return data ? JSON.parse(data) : INITIAL_SESSIONS;
    } catch {
      return INITIAL_SESSIONS;
    }
  },

  saveSessions(sessions: MeetingSession[]): void {
    localStorage.setItem(SESSIONS_KEY, JSON.stringify(sessions));
  },

  addSession(session: Omit<MeetingSession, 'id' | 'created_at'>): MeetingSession {
    const sessions = this.getSessions();
    const newSession: MeetingSession = {
      ...session,
      id: 's-' + Date.now(),
      created_at: new Date().toISOString(),
    };
    this.saveSessions([newSession, ...sessions]);
    return newSession;
  },

  getCommitments(): Commitment[] {
    try {
      const data = localStorage.getItem(COMMITMENTS_KEY);
      return data ? JSON.parse(data) : INITIAL_COMMITMENTS;
    } catch {
      return INITIAL_COMMITMENTS;
    }
  },

  saveCommitments(commitments: Commitment[]): void {
    localStorage.setItem(COMMITMENTS_KEY, JSON.stringify(commitments));
  },

  addCommitment(commitment: Omit<Commitment, 'id' | 'created_at' | 'updated_at'>): Commitment {
    const commitments = this.getCommitments();
    const now = new Date().toISOString();
    const newCommitment: Commitment = {
      ...commitment,
      id: 'c-' + Date.now(),
      created_at: now,
      updated_at: now,
    };
    
    // Automatically schedule reminder if confirmed with deadline
    if (newCommitment.extraction_status === 'confirmed' && newCommitment.deadline_at) {
      this.syncReminderForCommitment(newCommitment);
    }

    this.saveCommitments([newCommitment, ...commitments]);
    return newCommitment;
  },

  updateCommitment(id: string, updates: Partial<Commitment>): Commitment | null {
    const commitments = this.getCommitments();
    const index = commitments.findIndex((c) => c.id === id);
    if (index === -1) return null;

    const existing = commitments[index];
    const updated: Commitment = {
      ...existing,
      ...updates,
      updated_at: new Date().toISOString(),
    };

    // If deadline changed or status confirmed, resync 24-hr reminder
    if (updates.deadline_at !== undefined || updates.extraction_status !== undefined || updates.completion_status !== undefined) {
      this.syncReminderForCommitment(updated);
    }

    commitments[index] = updated;
    this.saveCommitments(commitments);
    return updated;
  },

  deleteCommitment(id: string): void {
    const commitments = this.getCommitments().filter((c) => c.id !== id);
    this.saveCommitments(commitments);
    // Cancel any pending reminders
    const reminders = this.getReminders().filter((r) => r.commitment_id !== id);
    this.saveReminders(reminders);
  },

  getReminders(): CommitmentReminder[] {
    try {
      const data = localStorage.getItem(REMINDERS_KEY);
      return data ? JSON.parse(data) : INITIAL_REMINDERS;
    } catch {
      return INITIAL_REMINDERS;
    }
  },

  saveReminders(reminders: CommitmentReminder[]): void {
    localStorage.setItem(REMINDERS_KEY, JSON.stringify(reminders));
  },

  syncReminderForCommitment(commitment: Commitment): void {
    const reminders = this.getReminders();
    
    // If completed, cancelled, or rejected, cancel pending reminders
    if (
      commitment.completion_status === 'completed' || 
      commitment.completion_status === 'cancelled' ||
      commitment.extraction_status === 'rejected'
    ) {
      const updated = reminders.map((r) => 
        r.commitment_id === commitment.id && r.status === 'pending'
          ? { ...r, status: 'cancelled' as const, updated_at: new Date().toISOString() }
          : r
      );
      this.saveReminders(updated);
      return;
    }

    // If confirmed and has deadline, schedule 24h prior
    if (commitment.extraction_status === 'confirmed' && commitment.deadline_at) {
      const reminderTime = calculate24hReminder(commitment.deadline_at);
      const idempotencyKey = `${commitment.user_id}_${commitment.id}_${commitment.deadline_at}`;

      // Check if reminder already exists
      const existingIdx = reminders.findIndex((r) => r.commitment_id === commitment.id);
      if (existingIdx !== -1) {
        reminders[existingIdx] = {
          ...reminders[existingIdx],
          reminder_at: reminderTime,
          idempotency_key: idempotencyKey,
          status: 'pending',
          updated_at: new Date().toISOString(),
        };
      } else {
        reminders.unshift({
          id: 'rem-' + Date.now(),
          user_id: commitment.user_id,
          commitment_id: commitment.id,
          reminder_at: reminderTime,
          delivery_channel: 'in_app',
          status: 'pending',
          idempotency_key: idempotencyKey,
          retry_count: 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        });
      }
      this.saveReminders(reminders);
    }
  },

  getPreferences(): UserNotificationPreferences {
    try {
      const data = localStorage.getItem(PREFS_KEY);
      return data ? JSON.parse(data) : DEFAULT_PREFERENCES;
    } catch {
      return DEFAULT_PREFERENCES;
    }
  },

  savePreferences(prefs: UserNotificationPreferences): void {
    localStorage.setItem(PREFS_KEY, JSON.stringify(prefs));
  },

  // Generates a standard .ics format string for exporting to Google Calendar / Apple Calendar
  exportToICS(commitments: Commitment[]): string {
    const lines = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//CommitMind//Commitment Intelligence//EN',
      'CALSCALE:GREGORIAN',
      'METHOD:PUBLISH',
    ];

    const formatICSDate = (dateStr: string): string => {
      const d = new Date(dateStr);
      return d.toISOString().replace(/[-:]/g, '').split('.')[0] + 'Z';
    };

    commitments.forEach((c) => {
      if (!c.deadline_at) return;
      const start = formatICSDate(c.deadline_at);
      // End date 1 hour after start
      const endDate = new Date(new Date(c.deadline_at).getTime() + 60 * 60 * 1000);
      const end = formatICSDate(endDate.toISOString());

      lines.push(
        'BEGIN:VEVENT',
        `UID:${c.id}@commitmind.app`,
        `DTSTAMP:${formatICSDate(c.created_at)}`,
        `DTSTART:${start}`,
        `DTEND:${end}`,
        `SUMMARY:[Commitment] ${c.title} (${c.owner_name})`,
        `DESCRIPTION:Action: ${c.action_description}\\nOwner: ${c.owner_name}\\nEvidence: "${c.transcript_excerpt}"`,
        `PRIORITY:${c.priority === 'urgent' ? '1' : c.priority === 'high' ? '2' : '5'}`,
        `STATUS:${c.completion_status === 'completed' ? 'COMPLETED' : 'CONFIRMED'}`,
        'END:VEVENT'
      );
    });

    lines.push('END:VCALENDAR');
    return lines.join('\r\n');
  },
};
