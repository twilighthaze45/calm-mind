// =====================================================================
// COMMITMIND — AI-POWERED ONLINE MEETING COMMITMENT INTELLIGENCE
// =====================================================================

export type Page = 
  | 'commitments_dashboard'
  | 'live_capture'
  | 'transcript_review'
  | 'commitments_list'
  | 'commitments_calendar'
  | 'notifications_settings'
  | 'pitch_deck'
  | 'dashboard'
  | 'mood'
  | 'journal'
  | 'breathe'
  | 'library'
  | 'progress'
  | 'settings';

export type AppWorkspaceMode = 'commitments' | 'mindfulness';

export type CommitmentScope = 'all' | 'mine' | 'colleagues';

/**
 * Determines whether a commitment was made by the current user ("Self")
 * or made by a colleague to the user/team.
 */
export function isMyCommitment(ownerName?: string | null): boolean {
  if (!ownerName) return false;
  const norm = ownerName.trim().toLowerCase();
  return (
    norm === 'self' ||
    norm === 'you' ||
    norm === 'me' ||
    norm === 'i' ||
    norm.includes('(self)') ||
    norm === 'user' ||
    norm.startsWith('self') ||
    norm.includes('recipient (self)')
  );
}

// ---------------------------------------------------------------------
// Mindfulness Types
// ---------------------------------------------------------------------
export type MoodValence = 'peaceful' | 'grateful' | 'content' | 'neutral' | 'restless' | 'anxious' | 'tired' | 'overwhelmed';

export interface MoodEntry {
  id: string;
  created_at: string;
  valence: MoodValence;
  label: string;
  score: number; // 1 to 10
  tags: string[];
  notes?: string;
}

export interface JournalEntry {
  id: string;
  created_at: string;
  title: string;
  content: string;
  audio_url?: string;
  audio_duration_seconds?: number;
  transcription_method?: 'voice' | 'manual';
  prompt_used?: string;
  mood_tag?: MoodValence;
  tags: string[];
}

export interface BreathingSession {
  id: string;
  created_at: string;
  pattern: 'box' | 'relax' | 'calm';
  duration_seconds: number;
  completed_cycles: number;
}

export interface MindfulnessExercise {
  id: string;
  title: string;
  category: 'meditation' | 'breathwork' | 'sleep' | 'soundscape' | 'focus';
  duration_minutes: number;
  description: string;
  instructor?: string;
  ambient_sound?: 'rain' | 'waves' | 'forest' | 'bowl' | 'stream';
  featured?: boolean;
}

export interface UserStats {
  streak_days: number;
  total_mindful_minutes: number;
  total_breathing_sessions: number;
  total_journal_entries: number;
  last_active_date: string;
}

export interface DailyIntention {
  quote: string;
  author: string;
  intention: string;
}

// ---------------------------------------------------------------------
// Commitment Intelligence & Capture Types (Phase B+)
// ---------------------------------------------------------------------
export type SessionType = 'live_mic' | 'meeting' | 'audio_import' | 'transcript_paste' | 'email' | 'document';
export type AudioRetentionPolicy = 'do_not_store' | 'delete_after_processing' | 'retain_30_days';
export type SessionStatus = 'recording' | 'processing' | 'completed' | 'failed';

export interface MeetingSession {
  id: string;
  user_id: string;
  title: string;
  session_type: SessionType;
  consent_confirmed: boolean;
  participants: string[];
  audio_url?: string;
  audio_retention_policy: AudioRetentionPolicy;
  started_at: string;
  ended_at?: string;
  duration_seconds: number;
  raw_transcript?: string;
  status: SessionStatus;
  created_at: string;
}

export interface TranscriptSegment {
  id: string;
  session_id: string;
  user_id: string;
  speaker_label: string; // e.g. "Speaker 1"
  speaker_name?: string;  // e.g. "Alice" (explicit user association only)
  start_time_ms: number;
  end_time_ms: number;
  text: string;
  confidence?: number;
  is_flagged_uncertain?: boolean;
  created_at: string;
}

export type CommitmentPriority = 'low' | 'medium' | 'high' | 'urgent';
export type CommitmentExtractionStatus = 'proposed' | 'confirmed' | 'rejected';
export type CommitmentCompletionStatus = 'pending' | 'in_progress' | 'completed' | 'cancelled';
export type CommitmentDeadlineType = 'datetime' | 'date_only' | 'undated';

export interface Commitment {
  id: string;
  user_id: string;
  session_id?: string;
  segment_id?: string;
  title: string;
  action_description: string;
  owner_speaker_label: string;
  owner_name: string;
  transcript_excerpt: string;
  source_timestamp?: string;
  source_type?: SessionType;
  deadline_at?: string | null; // ISO 8601 UTC
  deadline_type: CommitmentDeadlineType;
  original_deadline_phrase?: string;
  timezone: string;
  priority: CommitmentPriority;
  confidence_score: number; // 0.0 - 1.0
  is_flagged_uncertain?: boolean; // Human review checkpoint (Slide 5 & 10)
  extraction_status: CommitmentExtractionStatus;
  completion_status: CommitmentCompletionStatus;
  completed_at?: string | null;
  deduplication_hash?: string;
  notes?: string;
  created_at: string;
  updated_at: string;
}

export type ReminderDeliveryChannel = 'in_app' | 'browser_notification' | 'email';
export type ReminderStatus = 'pending' | 'sent' | 'failed' | 'cancelled';

export interface CommitmentReminder {
  id: string;
  user_id: string;
  commitment_id: string;
  reminder_at: string; // ISO 8601 UTC (exactly 24h before deadline or immediate if <24h)
  delivery_channel: ReminderDeliveryChannel;
  status: ReminderStatus;
  idempotency_key: string;
  retry_count: number;
  last_error?: string;
  sent_at?: string;
  created_at: string;
  updated_at: string;
}

export interface UserNotificationPreferences {
  user_id: string;
  in_app_enabled: boolean;
  browser_notifications_enabled: boolean;
  email_enabled: boolean;
  notification_email?: string;
  advance_notice_hours: number; // default 24
  timezone: string;
  quiet_hours_start?: string;
  quiet_hours_end?: string;
  created_at: string;
  updated_at: string;
}

// Provider-independent transcription service interface
export interface ITranscriptionService {
  readonly isSupported: boolean;
  start(): Promise<void>;
  stop(): Promise<string>;
  onTranscriptChunk?: (chunk: string) => void;
  onError?: (error: Error) => void;
}
