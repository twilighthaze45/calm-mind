import React from 'react';
import { 
  LayoutDashboard, 
  Mic, 
  Calendar, 
  CheckSquare, 
  FileCheck,
  Bell 
} from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';
import { useCommitments } from '../../context/CommitmentsContext';
import { Page } from '../../types';

export const MobileNav: React.FC = () => {
  const { currentPage, setCurrentPage } = useMindfulness();
  const { dueTodayCount } = useCommitments();

  const COMMITMENT_NAV = [
    { id: 'commitments_dashboard' as Page, label: 'Dashboard', icon: LayoutDashboard },
    { id: 'live_capture' as Page, label: 'Capture', icon: Mic },
    { id: 'transcript_review' as Page, label: 'Review', icon: FileCheck },
    { 
      id: 'commitments_calendar' as Page, 
      label: 'Calendar', 
      icon: Calendar,
      badge: dueTodayCount > 0 ? `${dueTodayCount}` : undefined
    },
    { id: 'commitments_list' as Page, label: 'Ledger', icon: CheckSquare },
    { id: 'notifications_settings' as Page, label: 'Alerts', icon: Bell },
  ];

  return (
    <nav 
      aria-label="Mobile Navigation"
      className="md:hidden fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-lg border-t border-warm-200/90 px-2 py-1.5 z-30 flex items-center justify-around shadow-warm-lg"
    >
      {COMMITMENT_NAV.map((item) => {
        const Icon = item.icon;
        const isActive = currentPage === item.id;
        return (
          <button
            key={item.id}
            onClick={() => setCurrentPage(item.id)}
            className={`relative flex flex-col items-center justify-center p-1 rounded-xl transition-all ${
              isActive ? 'text-sage-800 font-bold' : 'text-stone-600 hover:text-stone-900'
            }`}
          >
            <div 
              className={`p-1 rounded-lg transition-transform ${
                isActive ? 'bg-sage-100 scale-110' : ''
              }`}
            >
              <Icon className="w-5 h-5" />
            </div>
            <span className="text-[10px] mt-0.5 tracking-tight">
              {item.label}
            </span>
            {item.badge && (
              <span className="absolute top-0 right-1 w-4 h-4 bg-rose-500 text-white text-[9px] font-bold rounded-full flex items-center justify-center">
                {item.badge}
              </span>
            )}
          </button>
        );
      })}
    </nav>
  );
};
