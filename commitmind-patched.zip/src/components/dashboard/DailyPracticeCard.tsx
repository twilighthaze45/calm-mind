import { Clock, Play, Headphones } from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';
import { soundscape } from '../../services/audio';

export const DailyPracticeCard: React.FC = () => {
  const { setCurrentPage, recordMindfulMinutes, showToast } = useMindfulness();

  const handleStartPractice = () => {
    soundscape.playSingingBowl(293.66); // D note harmonic
    soundscape.startAmbient('rain');
    recordMindfulMinutes(10);
    showToast('Starting 10-Minute Grounding Body Scan with gentle rain 🌧️', 'success');
  };

  return (
    <div className="calm-card p-6 flex flex-col justify-between bg-gradient-to-br from-white via-white to-sage-50/50">
      <div>
        <div className="flex items-center justify-between mb-3">
          <span className="text-[11px] font-bold uppercase tracking-wider text-sage-700 bg-sage-100/90 px-2.5 py-1 rounded-full">
            Recommended For You
          </span>
          <div className="flex items-center gap-1 text-xs text-stone-600 font-medium">
            <Clock className="w-3.5 h-3.5" />
            <span>10 min</span>
          </div>
        </div>

        <h3 className="font-serif font-bold text-lg text-stone-800 mb-1.5">
          Morning Body Scan & Grounding
        </h3>
        <p className="text-xs sm:text-sm text-stone-600 leading-relaxed mb-4">
          Gently move attention through the physical body. Cultivate presence, soften stored tension in the shoulders, and meet the day with steady awareness.
        </p>

        <div className="flex items-center gap-2 mb-4 text-xs text-stone-600">
          <Headphones className="w-3.5 h-3.5 text-sage-600" />
          <span>Includes procedural rain soundscape & guided bell</span>
        </div>
      </div>

      <div className="pt-4 border-t border-warm-200/60 flex items-center justify-between gap-3">
        <button
          onClick={() => setCurrentPage('library')}
          className="text-xs font-semibold text-stone-600 hover:text-stone-800 transition-colors"
        >
          Explore All Practices
        </button>
        <button
          onClick={handleStartPractice}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-xs font-semibold shadow-sm hover:shadow-md transition-all active:scale-95"
        >
          <Play className="w-3.5 h-3.5 fill-white" />
          <span>Start Practice</span>
        </button>
      </div>
    </div>
  );
};
