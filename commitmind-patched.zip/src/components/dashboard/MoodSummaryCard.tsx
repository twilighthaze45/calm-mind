import React from 'react';
import { Smile, Plus, ArrowRight, Calendar } from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';

export const MoodSummaryCard: React.FC = () => {
  const { moods, setIsQuickCheckInOpen, setCurrentPage } = useMindfulness();

  const latestMood = moods[0];

  const getEmoji = (valence: string) => {
    switch (valence) {
      case 'peaceful': return '🕊️';
      case 'grateful': return '🌸';
      case 'content': return '🍃';
      case 'neutral': return '⚖️';
      case 'restless': return '🌊';
      case 'anxious': return '☁️';
      case 'tired': return '🌙';
      case 'overwhelmed': return '🌪️';
      default: return '✨';
    }
  };

  return (
    <div className="calm-card p-6 flex flex-col justify-between">
      <div>
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-rose-100/80 text-rose-700">
              <Smile className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-serif font-bold text-stone-800 text-base">
                Mood & Emotional Balance
              </h3>
              <p className="text-xs text-stone-600">Daily awareness check</p>
            </div>
          </div>

          <button
            onClick={() => setCurrentPage('mood')}
            className="text-xs font-semibold text-sage-600 hover:text-sage-800 flex items-center gap-1 group"
          >
            <span>Trends</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-0.5 transition-transform" />
          </button>
        </div>

        {/* Latest Logged State */}
        {latestMood ? (
          <div className="p-4 rounded-2xl bg-warm-50 border border-warm-200/80 mb-4">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2.5">
                <span className="text-2xl">{getEmoji(latestMood.valence)}</span>
                <div>
                  <h4 className="text-sm font-semibold text-stone-800 capitalize">
                    {latestMood.label}
                  </h4>
                  <div className="flex items-center gap-1.5 text-[11px] text-stone-600">
                    <Calendar className="w-3 h-3" />
                    <span>
                      {new Date(latestMood.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>
                </div>
              </div>
              <div className="px-2.5 py-1 rounded-full bg-white border border-warm-200 text-xs font-bold text-sage-700 shadow-warm-sm">
                {latestMood.score}/10
              </div>
            </div>

            {latestMood.notes && (
              <p className="text-xs text-stone-600 line-clamp-2 italic pt-2 border-t border-warm-200/60">
                &ldquo;{latestMood.notes}&rdquo;
              </p>
            )}

            {latestMood.tags.length > 0 && (
              <div className="flex flex-wrap gap-1 mt-2.5">
                {latestMood.tags.slice(0, 3).map((tag) => (
                  <span
                    key={tag}
                    className="text-[10px] px-2 py-0.5 rounded-full bg-warm-200/60 text-stone-600 font-medium"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            )}
          </div>
        ) : (
          <div className="p-6 rounded-2xl bg-warm-50 border border-warm-200/80 text-center mb-4">
            <p className="text-sm text-stone-600 mb-2">No mood logged yet today</p>
            <p className="text-xs text-stone-600">Take a quiet moment to observe how you feel.</p>
          </div>
        )}
      </div>

      {/* Action Footer */}
      <div className="pt-3 border-t border-warm-200/60 flex items-center justify-between">
        <span className="text-xs text-stone-600">
          {moods.length} recorded moments
        </span>
        <button
          onClick={() => setIsQuickCheckInOpen(true)}
          className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-warm-100 hover:bg-sage-100 text-sage-800 text-xs font-semibold transition-all border border-warm-200 hover:border-sage-300"
        >
          <Plus className="w-3.5 h-3.5 text-sage-600" />
          <span>Check-in Now</span>
        </button>
      </div>
    </div>
  );
};
