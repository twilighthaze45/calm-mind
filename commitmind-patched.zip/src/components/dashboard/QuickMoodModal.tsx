import React, { useState } from 'react';
import { X, Sparkles, Check } from 'lucide-react';
import { useMindfulness } from '../../context/MindfulnessContext';
import { MoodValence } from '../../types';

interface MoodOption {
  valence: MoodValence;
  label: string;
  emoji: string;
  color: string;
  bg: string;
}

const MOOD_OPTIONS: MoodOption[] = [
  { valence: 'peaceful', label: 'Peaceful', emoji: '🕊️', color: 'text-emerald-700', bg: 'bg-emerald-50 hover:bg-emerald-100/80 border-emerald-200' },
  { valence: 'grateful', label: 'Grateful', emoji: '🌸', color: 'text-rose-700', bg: 'bg-rose-50 hover:bg-rose-100/80 border-rose-200' },
  { valence: 'content', label: 'Content', emoji: '🍃', color: 'text-sage-700', bg: 'bg-sage-50 hover:bg-sage-100/80 border-sage-200' },
  { valence: 'neutral', label: 'Balanced', emoji: '⚖️', color: 'text-stone-700', bg: 'bg-stone-50 hover:bg-stone-100/80 border-stone-200' },
  { valence: 'restless', label: 'Restless', emoji: '🌊', color: 'text-amber-700', bg: 'bg-amber-50 hover:bg-amber-100/80 border-amber-200' },
  { valence: 'anxious', label: 'Anxious', emoji: '☁️', color: 'text-sky-700', bg: 'bg-sky-50 hover:bg-sky-100/80 border-sky-200' },
  { valence: 'tired', label: 'Tired', emoji: '🌙', color: 'text-indigo-700', bg: 'bg-indigo-50 hover:bg-indigo-100/80 border-indigo-200' },
  { valence: 'overwhelmed', label: 'Overwhelmed', emoji: '🌪️', color: 'text-purple-700', bg: 'bg-purple-50 hover:bg-purple-100/80 border-purple-200' },
];

const QUICK_TAGS = ['Sleep', 'Morning Tea', 'Work', 'Walking', 'Meditation', 'Family', 'Nature', 'Exercise', 'Reading'];

export const QuickMoodModal: React.FC = () => {
  const { isQuickCheckInOpen, setIsQuickCheckInOpen, addMood } = useMindfulness();
  const [selectedValence, setSelectedValence] = useState<MoodValence>('peaceful');
  const [score, setScore] = useState<number>(8);
  const [selectedTags, setSelectedTags] = useState<string[]>(['Morning Tea']);
  const [notes, setNotes] = useState('');

  if (!isQuickCheckInOpen) return null;

  const handleToggleTag = (tag: string) => {
    setSelectedTags((prev) =>
      prev.includes(tag) ? prev.filter((t) => t !== tag) : [...prev, tag]
    );
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const chosenOption = MOOD_OPTIONS.find((m) => m.valence === selectedValence);
    addMood({
      valence: selectedValence,
      label: chosenOption ? chosenOption.label : 'Peaceful',
      score,
      tags: selectedTags,
      notes: notes.trim() || undefined,
    });
    setIsQuickCheckInOpen(false);
    setNotes('');
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-sm animate-fade-in"
      onClick={() => setIsQuickCheckInOpen(false)}
      role="dialog"
      aria-modal="true"
      aria-labelledby="mood-modal-title"
    >
      <div 
        className="w-full max-w-lg bg-white rounded-3xl shadow-warm-lg border border-warm-200 p-6 sm:p-7 relative max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          onClick={() => setIsQuickCheckInOpen(false)}
          className="absolute top-5 right-5 p-2 rounded-full text-stone-600 hover:text-stone-700 hover:bg-warm-100 transition-colors"
          aria-label="Close dialog"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="mb-6">
          <div className="flex items-center gap-2 text-sage-600 text-xs font-semibold uppercase tracking-wider mb-1">
            <Sparkles className="w-3.5 h-3.5" /> Mindful Check-in
          </div>
          <h3 id="mood-modal-title" className="text-xl sm:text-2xl font-serif font-bold text-stone-800">
            How is your inner weather right now?
          </h3>
          <p className="text-xs sm:text-sm text-stone-600 mt-1">
            Notice how you feel without judgement. Every emotion is welcome here.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Valence Selector */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-2.5">
              Select Emotion
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {MOOD_OPTIONS.map((opt) => {
                const isSelected = selectedValence === opt.valence;
                return (
                  <button
                    key={opt.valence}
                    type="button"
                    onClick={() => setSelectedValence(opt.valence)}
                    className={`p-3 rounded-2xl border text-left flex flex-col justify-between transition-all ${
                      isSelected
                        ? `${opt.bg} border-sage-500 ring-2 ring-sage-400/40 shadow-sm scale-102`
                        : 'bg-warm-50/70 border-warm-200/80 hover:bg-white text-stone-700'
                    }`}
                  >
                    <span className="text-2xl mb-1">{opt.emoji}</span>
                    <span className={`text-xs font-semibold ${opt.color}`}>
                      {opt.label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Calm & Serenity Scale */}
          <div>
            <div className="flex justify-between items-center mb-1.5">
              <label htmlFor="calm-scale" className="text-xs font-bold uppercase tracking-wider text-stone-600">
                Calmness Level: <span className="text-sage-700 font-bold text-sm">{score}/10</span>
              </label>
              <span className="text-xs text-stone-600">
                {score >= 8 ? 'Deep Peace' : score >= 5 ? 'Balanced' : 'Needs Care'}
              </span>
            </div>
            <input
              id="calm-scale"
              type="range"
              min="1"
              max="10"
              value={score}
              onChange={(e) => setScore(Number(e.target.value))}
              className="w-full accent-sage-600 cursor-pointer h-2 bg-warm-200 rounded-lg"
            />
          </div>

          {/* Context Tags */}
          <div>
            <label className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-2">
              What was supporting or present?
            </label>
            <div className="flex flex-wrap gap-1.5">
              {QUICK_TAGS.map((tag) => {
                const isTagActive = selectedTags.includes(tag);
                return (
                  <button
                    key={tag}
                    type="button"
                    onClick={() => handleToggleTag(tag)}
                    className={`px-3 py-1.5 rounded-full text-xs font-medium transition-all flex items-center gap-1.5 ${
                      isTagActive
                        ? 'bg-sage-600 text-white shadow-sm'
                        : 'bg-warm-100 text-stone-600 hover:bg-warm-200/80'
                    }`}
                  >
                    {isTagActive && <Check className="w-3 h-3" />}
                    <span>{tag}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Mindful Notes */}
          <div>
            <label htmlFor="mood-notes" className="block text-xs font-bold uppercase tracking-wider text-stone-600 mb-1.5">
              Brief Reflection (Optional)
            </label>
            <textarea
              id="mood-notes"
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="A few words on what you notice in your body or mind..."
              className="w-full px-3.5 py-2.5 rounded-2xl bg-warm-50 border border-warm-200 text-stone-800 placeholder-stone-600 text-sm focus:bg-white transition-colors resize-none"
            />
          </div>

          {/* Action Buttons */}
          <div className="flex items-center justify-end gap-3 pt-2">
            <button
              type="button"
              onClick={() => setIsQuickCheckInOpen(false)}
              className="px-4 py-2.5 rounded-xl text-stone-600 hover:text-stone-800 text-sm font-medium hover:bg-warm-100 transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 rounded-xl bg-sage-600 hover:bg-sage-700 text-white text-sm font-semibold shadow-sm hover:shadow-md transition-all active:scale-95"
            >
              Save Check-in
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
