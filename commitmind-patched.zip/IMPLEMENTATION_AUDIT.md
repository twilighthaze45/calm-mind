# CommitMind implementation audit

## Changes in this patch
- Removed the frontend fallback that silently replaced failed audio transcription with a fabricated sample meeting transcript.
- Removed the backend fallback that returned fabricated transcript text when Gemini was missing or failed.
- Audio transcription now returns a clear error. Configure `GEMINI_API_KEY` or paste a transcript manually.
- The app no longer presents a sample transcript as if it came from the user's recording.

## Important findings from the uploaded code
1. **Frontend/backend stores are separate.** The main UI stores commitments in browser `localStorage` (`src/services/commitmentStorage.ts`), while backend endpoints use JSON-on-disk stores (`server/services/commitmentStore.ts` and `server/services/reminderScheduler.ts`). Confirmation and edits in the frontend do not consistently invoke backend confirmation/rescheduling endpoints. This needs a deliberate data-flow decision before multi-device use.
2. **Reminder delivery is simulated.** `server/services/reminderScheduler.ts` records due jobs as delivered in logs but does not actually send browser push notifications or email. Its heartbeat runs only while the backend process is alive.
3. **Google Calendar OAuth sync is not fully implemented.** The route checks configuration and token presence but does not call the Google Calendar API to create/update events.
4. **Supabase configuration/schema exists, but the main commitment UI currently uses `localStorage`.** Do not assume Supabase is the live persistence layer until the frontend and backend are explicitly wired to it.
5. **Sample/demo data is preloaded on first use.** Review this before real users enter actual meeting data so demo records are not confused with real commitments.

## Run locally
- Install dependencies with `npm ci`.
- Copy `.env.example` to `.env` and configure `GEMINI_API_KEY` for real AI extraction and audio transcription.
- Start the backend in one terminal with `npm run server`.
- Start Vite in another terminal with `npm run dev`.
- Keep the backend running for `/api/*` routes. Verify that `vite.config.ts` proxies `/api` to `http://localhost:3001`.

## Verification note
A full build/test pass could not be confirmed in this environment because dependency installation did not complete cleanly. Run `npm ci`, `npm run build`, and `npm test` locally before deployment.
