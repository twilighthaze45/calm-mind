# CommitMind — Full-Stack Source Manifest & Production Deployment Guide

**Platform:** CommitMind — Online Meeting Commitment Intelligence & Smart Calendar  
**Authors:** Team KERNEL (Adhyayan Chanchal, Shubham Agarwal, Kenisha, Shaurya) · Lloyd Institute of Engineering and Technology  
**Version:** 2.0.0 (Production Ready)  
**Status:** Verified Clean Build · 15/15 Automated Acceptance Tests Passing

---

## 1. Full-Stack Directory Architecture

```
skillbridge/
├── Dockerfile                             # Multi-stage production container build
├── .dockerignore                          # Build artifact & secret filter
├── render.yaml                            # Automated deployment blueprint for Render.com
├── vercel.json                            # Rewrites & SPA routing for Vercel
├── package.json                           # Dependencies, build, test & start scripts
├── tsconfig.json                          # TypeScript compiler configuration
├── vite.config.ts                         # Vite bundler configuration & proxy
├── tailwind.config.js                     # Tailored warm/sage/sky color design system
├── index.html                             # Single Page Application HTML root
├── .env.example                           # Documented production environment variables
│
├── server/                                # BACKEND: Node.js Express REST API & Workers
│   ├── index.ts                           # Express app, CORS, routes, static asset server
│   ├── routes/
│   │   ├── extract.ts                     # POST /api/extract (Gemini 2.5 Flash commitment extraction)
│   │   ├── transcribe.ts                  # POST /api/transcribe (Audio upload + Gemini multimodal STT)
│   │   ├── commitments.ts                 # GET/POST/PATCH/DELETE /api/commitments + Stop & Delete
│   │   ├── reminders.ts                   # GET /api/reminders + manual trigger endpoint
│   │   ├── calendar.ts                    # GET /api/calendar/ics + /api/calendar/google-sync
│   │   └── audit.ts                       # GET /api/audit (Immutable privacy & extraction logs)
│   └── services/
│       ├── deadlineResolver.ts            # Historical deadline anchor algorithm (Strict anchor resolution)
│       ├── geminiExtraction.ts            # Gemini 2.5 Flash caller with strict Zod structured output
│       ├── audioTranscription.ts          # Multer audio handler + Gemini speech diarization
│       ├── reminderScheduler.ts           # 24h & Day-Of background heartbeat worker & idempotency keys
│       ├── commitmentStore.ts             # In-memory + JSON persistence engine & deduplication
│       └── auditLogger.ts                 # Append-only SHA-256 audit trail
│
├── src/                                   # FRONTEND: React 18 + TypeScript + Tailwind CSS
│   ├── main.tsx                           # Application entry point
│   ├── App.tsx                            # Root application component with Context Providers
│   ├── index.css                          # Custom CSS design system, animations & utilities
│   ├── types/
│   │   └── index.ts                       # Complete TypeScript domain contracts & isMyCommitment helper
│   ├── context/
│   │   ├── CommitmentsContext.tsx         # Global commitment state, counts (mine vs colleagues)
│   │   └── MindfulnessContext.tsx         # Route state, Supabase readiness, UI toasts
│   ├── components/
│   │   └── layout/
│   │       ├── AppLayout.tsx              # Application shell & active page switcher
│   │       ├── Sidebar.tsx                # Desktop nav, My Promises vs Colleagues card
│   │       ├── Header.tsx                 # Workspace header, scope counters, Capture Meeting CTA
│   │       └── MobileNav.tsx              # Mobile bottom navigation
│   ├── pages/commitments/
│   │   ├── CommitmentsDashboardPage.tsx   # Dashboard with My Promises vs Colleagues Hero cards
│   │   ├── CommitmentsCalendarPage.tsx    # Smart Calendar with Scope Tabs (All, Mine, Colleagues)
│   │   ├── CommitmentsListPage.tsx        # Commitment Ledger with direction tags & search filters
│   │   ├── LiveCapturePage.tsx            # Online Meeting Audio & Transcript Ingest (Meet, Zoom, Teams)
│   │   ├── TranscriptReviewPage.tsx       # Human-in-the-Loop review & attribution checkpoint
│   │   ├── NotificationSettingsPage.tsx   # 24h Reminder rules & Supabase pg_cron documentation
│   │   └── PitchDeckPage.tsx              # Architecture documentation & Hackathon pitch deck
│   └── services/
│       ├── aiExtraction.ts                # Client API adapter to backend /api/extract
│       ├── commitmentStorage.ts           # Local storage fallback & ICS calendar generator
│       ├── transcription.ts               # Provider-independent browser SpeechRecognition adapter
│       └── supabase.ts                    # Supabase client initializer & connection verifier
│
├── supabase/migrations/                   # DATABASE: PostgreSQL & Row Level Security
│   ├── 20261026_commitmind_full_schema.sql # 11 relational tables, RLS policies, audit logs
│   └── 20261026_commitments_schema.sql    # Core commitment schema & pg_cron reminder worker
│
└── tests/                                 # AUTOMATED VERIFICATION: Vitest Test Suite
    └── commitment_intelligence.test.ts    # 15 end-to-end acceptance tests
```

---

## 2. Production Deployment Options

### Option 1: Single Unified Container / Server (Recommended)
*Deploys the entire full-stack app (React SPA + Express API) as a single service on **Render**, **Railway**, **Fly.io**, or any **Docker VPS**.*

1. **Build and Test Locally:**
   ```bash
   npm run build
   npm test
   ```
2. **Start the Production Server:**
   ```bash
   npm run start
   ```
   *Express automatically detects `dist/` and serves the frontend on `http://localhost:3001` alongside all `/api/*` endpoints.*

3. **Deploy with Docker:**
   ```bash
   docker build -t commitmind:latest .
   docker run -p 3001:3001 --env-file .env commitmind:latest
   ```

4. **Deploy on Render.com:**
   - Link your GitHub repository.
   - Select **Web Service** or use the included `render.yaml`.
   - Build Command: `npm install && npm run build`
   - Start Command: `npm run start`
   - Add environment variables from `.env.example`.

---

### Option 2: Decoupled Deployment
*Frontend on **Vercel** or **Netlify**; Backend API on **Railway** or **Render**.*

1. **Backend Deployment (Render / Railway):**
   - Root directory: `./`
   - Start Command: `npm run server`
   - Copy your live backend URL (e.g., `https://commitmind-api.onrender.com`).

2. **Frontend Deployment (Vercel):**
   - Link repository to Vercel.
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - In `vercel.json`, replace `YOUR_BACKEND_SERVER_URL` with your live backend API URL.

---

### Option 3: Supabase Database Migration
1. Log in to your [Supabase Dashboard](https://supabase.com).
2. Open the **SQL Editor**.
3. Copy and run the contents of `supabase/migrations/20261026_commitmind_full_schema.sql`.
4. Copy your `Project URL` and `anon public key` into your deployment environment variables as `VITE_SUPABASE_URL` and `VITE_SUPABASE_PUBLISHABLE_KEY`.
